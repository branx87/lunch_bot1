import sqlite3
import logging
from config import CONFIG, TIMEZONE
from datetime import datetime

logger = logging.getLogger(__name__)


class Database:
    def __init__(self):
        self.conn = sqlite3.connect('lunch_bot.db', check_same_thread=False, isolation_level=None)
        self.cursor = self.conn.cursor()
        self._init_db()

    def execute(self, query, params=()):
        """Безопасное выполнение запроса с обработкой транзакций"""
        try:
            self.cursor.execute("BEGIN")
            self.cursor.execute(query, params)
            result = self.cursor.fetchall()
            self.conn.commit()
            return result
        except sqlite3.Error as e:
            self.conn.rollback()
            logger.error(f"Ошибка выполнения SQL: {e} | Query: {query} | Params: {params}")
            raise

    def _init_db(self):
        """Создание таблиц и индексов при первом запуске"""
        try:
            # Сначала выставляем PRAGMA вне транзакции
            self.conn.execute("PRAGMA journal_mode=WAL")
            self.conn.execute("PRAGMA synchronous=NORMAL")
            self.conn.execute("PRAGMA busy_timeout=5000")

            # Теперь создаём таблицы (в отдельной транзакции)
            with self.conn:
                # Таблица пользователей
                self.cursor.execute('''
                    CREATE TABLE IF NOT EXISTS users (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        telegram_id INTEGER UNIQUE NOT NULL,
                        full_name TEXT,
                        phone TEXT,
                        location TEXT,
                        is_verified BOOLEAN DEFAULT FALSE,
                        username TEXT,
                        is_deleted BOOLEAN DEFAULT FALSE
                    )
                ''')

                # Таблица заказов
                self.cursor.execute('''
                    CREATE TABLE IF NOT EXISTS orders (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        user_id INTEGER,
                        order_date TEXT,
                        order_time TEXT,
                        quantity INTEGER,
                        is_preliminary BOOLEAN DEFAULT FALSE,
                        is_cancelled BOOLEAN DEFAULT FALSE,
                        FOREIGN KEY(user_id) REFERENCES users(id)
                    )
                ''')

                # Таблица сообщений
                self.cursor.execute('''
                    CREATE TABLE IF NOT EXISTS admin_messages (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        sent_at TEXT DEFAULT CURRENT_TIMESTAMP,
                        admin_id INTEGER,
                        user_id INTEGER,
                        message_text TEXT NOT NULL,
                        is_broadcast BOOLEAN DEFAULT FALSE,
                        FOREIGN KEY(admin_id) REFERENCES users(telegram_id),
                        FOREIGN KEY(user_id) REFERENCES users(telegram_id)
                    )
                ''')

            # Создаем индексы (в отдельной транзакции)
            with self.conn:
                self.cursor.execute("CREATE INDEX IF NOT EXISTS idx_orders_user_id ON orders(user_id)")
                self.cursor.execute("CREATE INDEX IF NOT EXISTS idx_orders_date ON orders(order_date)")
                self.cursor.execute("CREATE INDEX IF NOT EXISTS idx_orders_cancelled ON orders(is_cancelled)")

            logger.info("✅ Все таблицы и индексы созданы корректно")

        except sqlite3.OperationalError as e:
            logger.error(f"❌ Ошибка создания таблиц: {e}")
            raise
        except Exception as e:
            logger.critical(f"⚠️ Критическая ошибка при инициализации БД: {e}")
            raise
            
# Глобальный экземпляр базы данных
db = Database()
