import asyncio
import signal
import platform
import logging
import sys
from bot_core import LunchBot
from handlers import setup_handlers
from config import CONFIG

# Настройка логгера и кодировки
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("bot.log", encoding='utf-8'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

if sys.platform == 'win32':
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    sys.stderr.reconfigure(encoding='utf-8', errors='replace')

async def shutdown(bot):
    logger.info("🛑 Завершение работы бота...")
    await bot.stop()

async def main():
    logger.info("Запуск бота...")
    logger.info(f"Admin IDs: {CONFIG['admin_ids']}")
    logger.info(f"Token: {CONFIG['token'][:5]}...")

    bot = LunchBot()
    setup_handlers(bot.application)
    
    try:
        await bot.run()
    except asyncio.CancelledError:
        await shutdown(bot)
    except Exception as e:
        logger.error(f"Ошибка: {str(e)}", exc_info=True)
    finally:
        logger.info("✅ Работа бота завершена")

if __name__ == "__main__":
    try:
        if platform.system() == 'Windows':
            asyncio.run(main())
        else:
            # Для Unix-систем
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            
            for sig in (signal.SIGTERM, signal.SIGINT):
                loop.add_signal_handler(
                    sig,
                    lambda: asyncio.create_task(shutdown())
            )
            try:
                loop.run_until_complete(main())
            finally:
                loop.close()
    except KeyboardInterrupt:
        logger.info("\n🛑 Принудительное завершение")
    except Exception as e:
        logger.error(f"❌ Критическая ошибка: {str(e)}", exc_info=True)