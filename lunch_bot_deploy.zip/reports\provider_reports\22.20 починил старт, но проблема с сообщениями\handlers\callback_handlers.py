import logging
from telegram import Update, ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardRemove
from datetime import datetime, timedelta
from config import CONFIG, LOCATIONS, TIMEZONE, MENU, ADMIN_IDS
from db import db
from telegram.ext import CommandHandler, MessageHandler, CallbackQueryHandler, ConversationHandler, filters, ContextTypes
from .states import MAIN_MENU
from .common import show_main_menu
from utils import can_modify_order, is_order_cancelled
from utils import format_menu
import sqlite3
from .menu_handlers import view_orders

logger = logging.getLogger(__name__)

async def handle_order_callback(query, now, user, context):
    """Оформление заказа без смены интерфейса"""
    try:
        _, day_offset_str = query.data.split("_", 1)
        day_offset = int(day_offset_str)
        target_date = (now + timedelta(days=day_offset)).date()

        # Проверяем возможность заказа
        if not can_modify_order(target_date):
            await query.answer("ℹ️ Приём заказов завершён", show_alert=True)
            return

        # Получаем ID пользователя
        db.cursor.execute("SELECT id FROM users WHERE telegram_id = ?", (user.id,))
        user_record = db.cursor.fetchone()
        if not user_record:
            await query.answer("❌ Пользователь не найден")
            return
        user_db_id = user_record[0]

        # Проверяем, есть ли уже такой заказ
        db.cursor.execute("""
            SELECT quantity 
            FROM orders 
            WHERE user_id = ?
              AND order_date = ?
              AND is_cancelled = FALSE
        """, (user_db_id, target_date.isoformat()))
        existing_order = db.cursor.fetchone()

        if existing_order:
            qty = existing_order[0]
            await query.answer(f"ℹ️ У вас уже {qty} порции на этот день")
            return

        # Создаём новый заказ
        with db.conn:
            db.cursor.execute("""
                INSERT INTO orders (user_id, order_date, order_time, quantity, is_preliminary)
                VALUES (?, ?, ?, 1, ?)
            """, (
                user_db_id,
                target_date.isoformat(),
                now.strftime("%H:%M:%S"),
                day_offset > 0
            ))

        # Обновляем интерфейс
        await refresh_day_view(query, day_offset, user_db_id, now, is_order=True)

    except Exception as e:
        logger.error(f"Ошибка при оформлении заказа: {e}")
        await query.answer("⚠️ Ошибка оформления", show_alert=True)

async def handle_change_callback(query, now, user, context):
    """Изменение количества порций в рамках одного дня"""
    try:
        _, day_offset_str = query.data.split("_", 1)
        day_offset = int(day_offset_str)
        target_date = (now + timedelta(days=day_offset)).date()

        if not can_modify_order(target_date):
            await query.answer("ℹ️ Изменение невозможно после 9:30", show_alert=True)
            return

        # Получаем ID пользователя
        db.cursor.execute("SELECT id FROM users WHERE telegram_id = ?", (user.id,))
        user_record = db.cursor.fetchone()
        if not user_record:
            await query.answer("❌ Пользователь не найден")
            return
        user_db_id = user_record[0]

        # Получаем текущее количество
        db.cursor.execute("""
            SELECT quantity 
            FROM orders 
            WHERE user_id = ?
              AND order_date = ?
              AND is_cancelled = FALSE
        """, (user_db_id, target_date.isoformat()))
        result = db.cursor.fetchone()
        if not result:
            await query.answer("❌ Заказ не найден")
            return

        current_quantity = result[0]
        max_portions = 3

        new_quantity = min(current_quantity + 1, max_portions)
        if new_quantity == max_portions:
            await query.answer("ℹ️ Это максимальное количество порций")

        with db.conn:
            db.cursor.execute("""
                UPDATE orders
                SET quantity = ?,
                    order_time = ?
                WHERE user_id = ?
                  AND order_date = ?
                  AND is_cancelled = FALSE
            """, (
                new_quantity,
                now.strftime("%H:%M:%S"),
                user_db_id,
                target_date.isoformat()
            ))

        await refresh_day_view(query, day_offset, user_db_id, now)

    except Exception as e:
        logger.error(f"Ошибка изменения количества: {e}")
        await query.answer("⚠️ Ошибка изменения", show_alert=True)
        
async def handle_quantity_change(query, now, user, context):
    """Увеличение/уменьшение порций с автоматическим удалением заказа при 0"""
    try:
        action, day_offset_str = query.data.split("_", 1)
        day_offset = int(day_offset_str)
        target_date = (now + timedelta(days=day_offset)).date()

        # Проверяем, можно ли изменять
        if not can_modify_order(target_date):
            await query.answer("ℹ️ Изменение невозможно после 9:30", show_alert=True)
            return

        # Получаем ID пользователя
        db.cursor.execute("SELECT id FROM users WHERE telegram_id = ?", (user.id,))
        user_record = db.cursor.fetchone()
        if not user_record:
            await query.answer("❌ Пользователь не найден")
            return
        user_db_id = user_record[0]

        # Получаем текущее количество
        db.cursor.execute("""
            SELECT quantity 
            FROM orders 
            WHERE user_id = ?
              AND order_date = ?
              AND is_cancelled = FALSE
        """, (user_db_id, target_date.isoformat()))
        result = db.cursor.fetchone()
        if not result:
            await query.answer("❌ Заказ не найден")
            return

        current_quantity = result[0]
        max_portions = 3

        # Логика изменения
        if action == "increase":
            if current_quantity < max_portions:
                new_quantity = current_quantity + 1
                if new_quantity == max_portions:
                    await query.answer("ℹ️ Это максимальное количество порций (3)")
            else:
                await query.answer("ℹ️ Это максимум порций", show_alert=True)
                return
        elif action == "decrease":
            if current_quantity > 1:
                new_quantity = current_quantity - 1
            else:
                # Отменяем заказ, если 1 порция
                with db.conn:
                    db.cursor.execute("""
                        UPDATE orders
                        SET is_cancelled = TRUE,
                            order_time = ?
                        WHERE user_id = ?
                          AND order_date = ?
                          AND is_cancelled = FALSE
                    """, (now.strftime("%H:%M:%S"), user_db_id, target_date.isoformat()))

                days_ru = ["Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", "Воскресенье"]
                day_name = days_ru[target_date.weekday()]

                await query.edit_message_text(
                    text=f"❌ Заказ на {day_name} отменён",
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("✅ Заказать", callback_data=f"order_{day_offset}")]
                    ])
                )
                return
        else:
            await query.answer("⚠️ Неизвестное действие")
            return

        # Обновляем количество
        with db.conn:
            db.cursor.execute("""
                UPDATE orders
                SET quantity = ?,
                    order_time = ?
                WHERE user_id = ?
                  AND order_date = ?
                  AND is_cancelled = FALSE
            """, (new_quantity, now.strftime("%H:%M:%S"), user_db_id, target_date.isoformat()))

        # Формируем новое сообщение
        days_ru = ["Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", "Воскресенье"]
        day_name = days_ru[target_date.weekday()]

        keyboard = []

        if new_quantity < max_portions:
            keyboard.append([InlineKeyboardButton("➕ Увеличить", callback_data=f"increase_{day_offset}")])
        else:
            keyboard.append([InlineKeyboardButton("ℹ️ Максимум порций", callback_data="noop")])

        if new_quantity > 1:
            keyboard.append([InlineKeyboardButton("➖ Уменьшить", callback_data=f"decrease_{day_offset}")])

        keyboard.append([InlineKeyboardButton("❌ Отменить заказ", callback_data=f"cancel_{day_offset}")])

        await query.edit_message_text(
            text=f"🍽 Количество порций обновлено:\n📅 {day_name}\n"
                 f" Сейчас: {new_quantity} порции",
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode="Markdown"
        )

        await query.answer(f"✅ Теперь {new_quantity} порции")

    except Exception as e:
        logger.error(f"Ошибка при изменении количества: {e}")
        try:
            await query.edit_message_text("⚠️ Ошибка изменения")
        except Exception as inner_e:
            logger.error(f"Ошибка при редактировании сообщения: {inner_e}")

# --- Callback для отмены заказа ---
async def handle_cancel_callback(query, now, user, context):
    """Отмена заказа в рамках одного дня"""
    try:
        _, date_part = query.data.split("_", 1)

        if '-' in date_part:
            order_date = datetime.strptime(date_part, "%Y-%m-%d").date()
            day_offset = (order_date - now.date()).days
        elif date_part.isdigit():
            day_offset = int(date_part)
            order_date = (now + timedelta(days=day_offset)).date()
        else:
            raise ValueError("Неверный формат даты")

        if not can_modify_order(order_date):
            await query.answer("ℹ️ Отмена невозможна после 9:30", show_alert=True)
            return

        db.cursor.execute("SELECT id FROM users WHERE telegram_id = ?", (user.id,))
        user_record = db.cursor.fetchone()
        if not user_record:
            await query.answer("❌ Пользователь не найден")
            return
        user_db_id = user_record[0]

        with db.conn:
            db.cursor.execute("""
                UPDATE orders
                SET is_cancelled = TRUE,
                    order_time = ?
                WHERE user_id = ?
                  AND order_date = ?
                  AND is_cancelled = FALSE
            """, (now.strftime("%H:%M:%S"), user_db_id, order_date.isoformat()))

        # Обновляем интерфейс
        await refresh_day_view(query, day_offset, user_db_id, now)

    except Exception as e:
        logger.error(f"Ошибка при отмене заказа: {e}")
        await query.answer("⚠️ Ошибка отмены", show_alert=True)

async def refresh_orders_view(query, context, user_id, now, days_ru):
    """Обновляет список заказов после изменения количества"""
    try:
        db.cursor.execute("""
            SELECT o.order_date, o.quantity, o.is_preliminary
            FROM orders o
            JOIN users u ON o.user_id = u.id
            WHERE u.telegram_id = ?
              AND o.is_cancelled = FALSE
              AND o.order_date >= ?
            ORDER BY o.order_date
        """, (user_id, now.date().isoformat()))

        active_orders = db.cursor.fetchall()

        if not active_orders:
            await query.edit_message_text("ℹ️ У вас нет активных заказов.")
            return await show_main_menu(query.message, user_id)

        response = "📦 Ваши активные заказы:\n"
        keyboard = []

        for order in active_orders:
            order_date = datetime.strptime(order[0], "%Y-%m-%d").date()
            day_name = days_ru[order_date.weekday()]
            date_str = order_date.strftime('%d.%m')
            qty = order[1]
            status = " (предварительный)" if order[2] else ""

            response += f"📅 {day_name} ({date_str}) - {qty} порций{status}\n"
            keyboard.append([
                InlineKeyboardButton(f"✏️ Изменить {date_str}", callback_data=f"change_{order_date.strftime('%Y-%m-%d')}"),
                InlineKeyboardButton(f"✕ Отменить {date_str}", callback_data=f"cancel_{order_date.strftime('%Y-%m-%d')}")
            ])

        keyboard.append([InlineKeyboardButton("✔ В главное меню", callback_data="back_to_menu")])

        await query.edit_message_text(
            response,
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode="Markdown"
        )

    except Exception as e:
        logger.error(f"Ошибка обновления списка: {e}")
        await query.edit_message_text("⚠️ Ошибка загрузки заказов")

async def refresh_day_view(query, day_offset, user_db_id, now, is_order=False):
    """Обновляет только одно меню дня после заказа/изменения/отмены"""
    try:
        days_ru = ["Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", "Воскресенье"]
        target_date = now.date() + timedelta(days=day_offset)
        day_name = days_ru[target_date.weekday()]
        menu = MENU.get(day_name)

        if not menu:
            await query.edit_message_text("❌ Меню не определено")
            return

        message = format_menu(menu, day_name, is_tomorrow=day_offset > 0)

        # Получаем текущее состояние
        db.cursor.execute("""
            SELECT quantity 
            FROM orders 
            WHERE user_id = ?
              AND order_date = ?
              AND is_cancelled = FALSE
        """, (user_db_id, target_date.isoformat()))
        order = db.cursor.fetchone()

        # Формируем текст и кнопки
        keyboard = []
        if order:
            qty = order[0]
            message += f"\n\n✅ {'Предзаказ' if day_offset > 0 else 'Заказ'}: {qty} порции"
            can_modify = can_modify_order(target_date)

            if can_modify:
                keyboard.append([InlineKeyboardButton("✏️ Изменить количество", callback_data=f"change_{day_offset}")])
            keyboard.append([InlineKeyboardButton("❌ Отменить заказ", callback_data=f"cancel_{day_offset}")])
        else:
            can_modify = can_modify_order(target_date)
            if can_modify:
                keyboard.append([InlineKeyboardButton("✅ Заказать", callback_data=f"order_{day_offset}")])
            else:
                keyboard.append([InlineKeyboardButton("⏳ Приём заказов завершён", callback_data="noop")])

        await query.edit_message_text(
            text=message,
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode="Markdown"
        )

    except Exception as e:
        logger.error(f"Ошибка при обновлении дня: {e}")
        await query.edit_message_text("⚠️ Ошибка интерфейса")

async def callback_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()  # Подтверждаем нажатие

    try:
        now = datetime.now(TIMEZONE)
        user = update.effective_user

        if query.data.startswith("cancel_"):
            await handle_cancel_callback(query, now, user, context)
        elif query.data.startswith("change_"):
            await handle_change_callback(query, now, user, context)
        elif query.data.startswith("order_"):
            await handle_order_callback(query, now, user, context)
        elif query.data == "back_to_menu":
            await show_main_menu(query.message, user.id)
        else:
            logger.warning(f"Неизвестный callback: {query.data}")
            await query.edit_message_text("⚠️ Неизвестная команда")

    except Exception as e:
        logger.error(f"Ошибка в callback_handler: {e}", exc_info=True)
        try:
            await query.edit_message_text("⚠️ Серверная ошибка")
        except Exception as inner_e:
            logger.error(f"Ошибка при отправке сообщения: {inner_e}")
    
async def handle_cancel_order(query, order_date_str):
    if not can_modify_order(order_date_str):  # Используем ВАШУ проверку
        await query.answer("ℹ️ Отмена заказа невозможна после 9:30", show_alert=True)
        return
    
    """Обработка отмены заказа по конкретной дате"""
    user_id = query.from_user.id
    order_date = datetime.strptime(order_date_str, "%Y-%m-%d").date()
    now = datetime.now(TIMEZONE)
    
    if not can_modify_order(order_date):
        await query.answer("ℹ️ Отмена невозможна (после 9:30)", show_alert=True)
        return False

    db.cursor.execute(
        "DELETE FROM orders WHERE user_id = "
        "(SELECT id FROM users WHERE telegram_id = ?) AND order_date = ?",
        (user_id, order_date_str)
    )
    db.conn.commit()
    
    return db.cursor.rowcount > 0
