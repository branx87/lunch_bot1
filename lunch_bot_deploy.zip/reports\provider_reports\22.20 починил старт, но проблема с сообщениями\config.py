import os
import openpyxl
import pytz
import logging

logger = logging.getLogger(__name__)

# Общие настройки
TIMEZONE = pytz.timezone('Europe/Moscow')
CONFIG_FILE = "config.xlsx"
LOCATIONS = ["Офис", "ПЦ 1", "ПЦ 2", "Склад"]

# Меню на неделю
MENU = {
    "Понедельник": {
        "first": "Борщ",
        "main": "Тефтели с картофельным пюре",
        "salad": "Салат оливье"   
    },
    "Вторник": {
        "first": "Суп гороховый",
        "main": "Куриный гуляш со спагетти",
        "salad": "Салат витаминный"
    },
    "Среда": {
        "first": "Суп лапша",
        "main": "Филе под шапкой с гречкой",
        "salad": "Салат крабовый"
    },
    "Четверг": {
        "first": "Суп харчо",
        "main": "Куриный гуляш с макаронами",
        "salad": "Винегрет"
    },
    "Пятница": {
        "first": "Щи",
        "main": "Голубцы с картофельным пюре",
        "salad": "Салат столичный"
    },
    "Суббота": None,
    "Воскресенье": None
}

def load_config():
    try:
        if not os.path.exists(CONFIG_FILE):
            raise FileNotFoundError(f"Файл конфигурации {CONFIG_FILE} не найден")
        
        wb = openpyxl.load_workbook(CONFIG_FILE)
        ws = wb.active
        
        token = ws['A2'].value
        if not token:
            raise ValueError("Токен бота не указан в ячейке A2")
        
        admin_ids = [int(cell.value) for cell in ws['B'][1:] if cell.value is not None]
        provider_ids = [int(cell.value) for cell in ws['C'][1:] if cell.value is not None]
        accounting_ids = [int(cell.value) for cell in ws['D'][1:] if cell.value is not None]
        
        staff_names = set()
        for row in ws.iter_rows(min_row=2, max_col=7, values_only=True):
            if row[6]:
                name = ' '.join(str(row[6]).strip().split()).lower()
                staff_names.add(name)
                
                parts = name.split()
                if len(parts) >= 2:
                    reversed_name = f"{parts[1]} {parts[0]}"
                    if len(parts) > 2:
                        reversed_name += " " + " ".join(parts[2:])
                    staff_names.add(reversed_name)
        
        return {
            'token': token,
            'admin_ids': admin_ids,
            'provider_ids': provider_ids,
            'accounting_ids': accounting_ids,
            'staff_names': staff_names,
            'menu': MENU
        }
    except Exception as e:
        logger.error(f"Ошибка загрузки конфигурации: {e}")
        raise

# Загружаем конфигурацию при старте
try:
    CONFIG = load_config()
    TOKEN = CONFIG['token']
    ADMIN_IDS = CONFIG['admin_ids']
    PROVIDER_IDS = CONFIG['provider_ids']
    ACCOUNTING_IDS = CONFIG['accounting_ids']
    STAFF_NAMES = CONFIG['staff_names']
    MENU = CONFIG['menu']
except Exception as e:
    logger.error(f"Не удалось загрузить конфигурацию: {e}")
    exit(1)
