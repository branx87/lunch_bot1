from datetime import datetime, timedelta
from telegram import Update
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    CallbackQueryHandler,
    ConversationHandler,
    filters,
    ContextTypes
)

# Импорты локальных модулей
from .common import show_main_menu
from .base_handlers import (
    start,
    error_handler,
    test_connection,
    main_menu,
    handle_text_message,
    handle_registered_user
)
from .registration_handlers import (
    get_phone,
    get_full_name,
    get_location
)
from .menu_handlers import (
    show_today_menu,
    show_week_menu,
    view_orders,
    monthly_stats,
    handle_order_confirmation,
    order_action,
    monthly_stats_selected
)
from .callback_handlers import (
    callback_handler,
    handle_order_callback,
    handle_change_callback,
    handle_cancel_callback
)
from .admin_handlers import (
    handle_admin_choice,
    select_user,
    handle_message_text,
    handle_broadcast,
    handle_admin_message_text,
    send_personal_message
)
from .report_handlers import select_month_range

# Состояния диалога
from .states import (
    PHONE,
    FULL_NAME,
    LOCATION,
    MAIN_MENU,
    ORDER_ACTION,
    ADMIN_MESSAGE,
    AWAIT_ADMIN_MESSAGE,
    ORDER_CONFIRMATION,
    SELECT_MONTH_RANGE,
    SELECT_USER,
    AWAIT_MESSAGE_TEXT,
    BROADCAST_MESSAGE,
    AWAIT_ADMIN_MESSAGE
)

# Константы для новых состояний
SELECT_MONTH_RANGE_STATS = 'select_month_range_stats'

def setup_handlers(application: Application):
    """Настройка всех обработчиков команд и состояний бота"""

    # 1. Добавляем тестовую команду
    application.add_handler(CommandHandler("test", test_connection))

    # 2. ConversationHandler
    conv_handler = ConversationHandler(
        entry_points=[
            CommandHandler('start', start),
            MessageHandler(filters.Regex("^Статистика за месяц$"), monthly_stats),
            MessageHandler(filters.Regex("^Написать администратору$"), handle_admin_message_text),  # Для начала диалога
            MessageHandler(filters.Regex("^✉️ Написать пользователю$"), select_user),
            MessageHandler(filters.Regex("^📢 Сделать рассылку$"), handle_broadcast),
            MessageHandler(filters.Regex("^Админ-панель$"), handle_admin_choice),
        ],
        states={
            SELECT_MONTH_RANGE_STATS: [
                MessageHandler(
                    filters.Regex("^(Текущий месяц|Прошлый месяц|Вернуться в главное меню)$"),
                    monthly_stats_selected
                )
            ],
            PHONE: [MessageHandler(filters.CONTACT, get_phone)],
            FULL_NAME: [MessageHandler(filters.TEXT & ~filters.COMMAND, get_full_name)],
            LOCATION: [MessageHandler(filters.TEXT & ~filters.COMMAND, get_location)],
            MAIN_MENU: [MessageHandler(filters.TEXT & ~filters.COMMAND, main_menu)],
            ORDER_ACTION: [CallbackQueryHandler(callback_handler)],
            ADMIN_MESSAGE: [MessageHandler(filters.TEXT & ~filters.COMMAND, handle_admin_choice)],
            ORDER_CONFIRMATION: [MessageHandler(filters.TEXT & ~filters.COMMAND, handle_order_confirmation)],
            SELECT_MONTH_RANGE: [
                MessageHandler(filters.Regex(r'^(Текущий месяц|Прошлый месяц)$'), select_month_range),
                MessageHandler(filters.Regex(r'^Вернуться в главное меню$'), show_main_menu)
            ],
            SELECT_USER: [MessageHandler(filters.TEXT & ~filters.COMMAND, select_user)],
            AWAIT_MESSAGE_TEXT: [MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message_text)],
            BROADCAST_MESSAGE: [MessageHandler(filters.TEXT & ~filters.COMMAND, handle_broadcast)],
            AWAIT_ADMIN_MESSAGE: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, handle_admin_message_text)
            ]
        },
        fallbacks=[
            CommandHandler('start', start),
            MessageHandler(
                filters.TEXT & ~filters.COMMAND,
                lambda update, context: show_main_menu(update, update.effective_user.id)
            ),
            MessageHandler(filters.Regex("^Отмена$"), lambda u, c: ConversationHandler.END),
        ],
        per_chat=True,
        per_user=True,
        allow_reentry=True
    )

    application.add_handler(conv_handler)

    # 3. Обработчик для зарегистрированных пользователей
    application.add_handler(MessageHandler(
        filters.TEXT & ~filters.COMMAND & filters.Regex(
            r'^(Меню на сегодня|Меню на неделю|Просмотреть заказы|Статистика за месяц|'
            r'Написать администратору|💰 Бухгалтерский отчет|📦 Отчет поставщика|'
            r'📊 Отчет за день|📅 Отчет за месяц|Обновить меню|Вернуться в главное меню)$'
        ),
        handle_registered_user
    ))

    # 4. CallbackQueryHandler
    application.add_handler(CallbackQueryHandler(callback_handler))

    # 5. Обработчик всех текстовых сообщений (кроме команд)
    application.add_handler(
        MessageHandler(
            filters.TEXT & ~filters.COMMAND,
            handle_text_message
        )
    )

    # 6. Обработчик ошибок
    application.add_error_handler(error_handler)
