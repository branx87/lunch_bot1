import logging
from datetime import datetime, timedelta
from .base_handlers import show_main_menu
from telegram import Update, ReplyKeyboardMarkup, ReplyKeyboardRemove
from telegram.ext import ContextTypes, ConversationHandler
from config import CONFIG, ADMIN_IDS  # Добавляем импорт
from .states import ADMIN_MESSAGE, SELECT_USER, AWAIT_MESSAGE_TEXT, BROADCAST_MESSAGE, FULL_NAME, MAIN_MENU, SELECT_MONTH_RANGE
from keyboards import create_main_menu_keyboard, create_admin_keyboard, create_month_selection_keyboard
import asyncio
from db import db
from admin import export_accounting_report

logger = logging.getLogger(__name__)

async def start_admin_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Пользователь начинает писать сообщение админу"""
    await update.message.reply_text(
        "📝 Введите ваше сообщение для администратора:",
        reply_markup=ReplyKeyboardMarkup([["❌ Отмена"]], resize_keyboard=True)
    )
    return AWAIT_ADMIN_MESSAGE

async def handle_admin_message_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка текста сообщения от пользователя и отправка админам"""
    user = update.effective_user
    message_text = update.message.text.strip()

    if message_text.lower() == "отмена":
        await update.message.reply_text("❌ Сообщение отменено", reply_markup=create_main_menu_keyboard(user.id))
        return ConversationHandler.END

    # Сохраняем сообщение в БД
    db.cursor.execute("""
        INSERT INTO admin_messages (admin_id, user_id, message_text)
        VALUES (?, ?, ?)
    """, (None, user.id, message_text))
    db.conn.commit()

    # Отправляем всем админам
    success_count = 0
    for admin_id in CONFIG.get('admin_ids', []):
        try:
            await update.message.forward(admin_id)
            success_count += 1
        except Exception as e:
            logger.error(f"Ошибка при пересылке админу {admin_id}: {e}")

    await update.message.reply_text(
        f"✅ Сообщение отправлено {success_count}/{len(CONFIG['admin_ids'])} админам",
        reply_markup=create_main_menu_keyboard(user.id)
    )

    return ConversationHandler.END

# 3. Отправка личного сообщения
async def send_personal_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Отправка сообщения конкретному пользователю от администратора"""
    try:
        text = update.message.text.strip()
        
        if text.lower() == "отмена":
            await update.message.reply_text(
                "❌ Отправка отменена",
                reply_markup=create_admin_keyboard()
            )
            return ADMIN_MESSAGE

        recipient = context.user_data.get('recipient')
        is_username = context.user_data.get('is_username')

        if not recipient:
            raise ValueError("Не выбран получатель")

        # Поиск пользователя
        if is_username:
            db.cursor.execute(
                "SELECT telegram_id FROM users WHERE username = ?",
                (recipient,)
            )
        else:
            db.cursor.execute(
                "SELECT telegram_id FROM users WHERE telegram_id = ?",
                (recipient,)
            )

        user_record = db.cursor.fetchone()
        if not user_record:
            raise ValueError("Пользователь не найден в базе")

        # Отправка сообщения
        telegram_id = user_record[0]
        await context.bot.send_message(
            chat_id=telegram_id,
            text=f"✉️ Сообщение от администратора:\n\n{text}"
        )

        # Уведомление админа
        await update.message.reply_text(
            f"✅ Сообщение отправлено {'@' + recipient if is_username else recipient}",
            reply_markup=create_admin_keyboard()
        )

        # Очистка данных
        context.user_data.pop('recipient', None)
        context.user_data.pop('is_username', None)

        return ADMIN_MESSAGE

    except Exception as e:
        logger.error(f"Ошибка отправки: {e}", exc_info=True)
        await update.message.reply_text(
            f"❌ Ошибка при отправке: {str(e)}\nПопробуйте начать заново.",
            reply_markup=create_admin_keyboard()
        )
        return ADMIN_MESSAGE
    
# 4. Обработчик рассылки
async def handle_broadcast(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Рассылка всем пользователям от админа"""
    text = update.message.text.strip()
    if text.lower() == "отмена":
        await update.message.reply_text("❌ Рассылка отменена", reply_markup=create_admin_keyboard())
        return ADMIN_MESSAGE

    db.cursor.execute("SELECT telegram_id FROM users WHERE is_verified = TRUE")
    users = db.cursor.fetchall()
    success = 0

    for user_row in users:
        try:
            await context.bot.send_message(chat_id=user_row[0], text=text)
            success += 1
            await asyncio.sleep(0.1)  # Избегаем флуда
        except Exception as e:
            logger.warning(f"Не удалось отправить {user_row[0]}: {e}")

    await update.message.reply_text(f"✅ Рассылка завершена\nУспешно: {success}/{len(users)}", reply_markup=create_admin_keyboard())
    return ADMIN_MESSAGE
    
# 2. Обработчик выбора пользователя
async def select_user(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Выбор пользователя для отправки сообщения от админа"""
    user_input = update.message.text.strip()
    
    if user_input.lower() == "отмена":
        await update.message.reply_text("❌ Отправка отменена", reply_markup=create_admin_keyboard())
        return ADMIN_MESSAGE
    
    # Проверяем, является ли ввод числом (ID) или юзернеймом (@username)
    try:
        recipient_id = int(user_input)
        context.user_data.update({'recipient': recipient_id, 'is_username': False})
        await update.message.reply_text("Введите сообщение:", reply_markup=ReplyKeyboardRemove())
        return AWAIT_MESSAGE_TEXT
    except ValueError:
        if user_input.startswith('@'):
            username = user_input[1:]
            context.user_data.update({'recipient': username, 'is_username': True})
            await update.message.reply_text("Введите сообщение:", reply_markup=ReplyKeyboardRemove())
            return AWAIT_MESSAGE_TEXT
        else:
            await update.message.reply_text("❌ Введите корректный ID или @username")
            return SELECT_USER
    
async def handle_message_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Отправка сообщения выбранному пользователю"""
    text = update.message.text.strip()

    if text.lower() == "отмена":
        await update.message.reply_text("❌ Сообщение отменено", reply_markup=create_admin_keyboard())
        return ADMIN_MESSAGE

    recipient = context.user_data.get('recipient')
    is_username = context.user_data.get('is_username', False)

    if not recipient:
        await update.message.reply_text("❌ Не указан получатель")
        return SELECT_USER

    try:
        if is_username:
            db.cursor.execute("SELECT telegram_id FROM users WHERE username = ?", (recipient,))
        else:
            db.cursor.execute("SELECT telegram_id FROM users WHERE telegram_id = ?", (recipient,))

        result = db.cursor.fetchone()
        if not result:
            raise ValueError("Пользователь не найден")

        telegram_id = result[0]
        await context.bot.send_message(chat_id=telegram_id, text=f"📩 Сообщение от администратора:\n\n{text}")

        # Сохраняем в БД
        db.cursor.execute("""
            INSERT INTO admin_messages (admin_id, user_id, message_text)
            VALUES (?, ?, ?)
        """, (update.effective_user.id, telegram_id, text))
        db.conn.commit()

        await update.message.reply_text(
            f"✅ Сообщение отправлено {'@' + recipient if is_username else recipient}",
            reply_markup=create_admin_keyboard()
        )
        context.user_data.pop('recipient', None)
        context.user_data.pop('is_username', None)
        return ADMIN_MESSAGE

    except Exception as e:
        logger.error(f"Ошибка отправки: {e}")
        await update.message.reply_text(f"❌ Ошибка: {e}\nПопробуйте начать заново.", reply_markup=create_admin_keyboard())
        return ADMIN_MESSAGE
    
# 1. Обработчик меню администратора
async def handle_admin_choice(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка выбора в админ-меню"""
    text = update.message.text.strip().lower()
    user = update.effective_user

    # Проверка прав администратора
    if user.id not in CONFIG.get('admin_ids', []) and user.id not in CONFIG.get('accounting_ids', []):
        await update.message.reply_text("❌ У вас нет прав для выполнения этой команды.")
        return ADMIN_MESSAGE

    if text == "написать пользователю":
        await update.message.reply_text(
            "Введите ID пользователя или @username:",
            reply_markup=ReplyKeyboardMarkup([["Отмена"]], resize_keyboard=True)
        )
        return SELECT_USER

    elif text == "сделать рассылку":
        await update.message.reply_text(
            "Введите сообщение для рассылки:",
            reply_markup=ReplyKeyboardMarkup([["Отмена"]], resize_keyboard=True)
        )
        return BROADCAST_MESSAGE

    elif text == "отмена":
        await update.message.reply_text(
            "Действие отменено",
            reply_markup=create_admin_keyboard()
        )
        return ADMIN_MESSAGE

    elif text in ["📊 отчет за день", "отчет за день"]:
        if user.id in CONFIG.get('admin_ids', []) or user.id in CONFIG.get('accounting_ids', []):
            await export_accounting_report(update, context)  # Бухгалтерский отчет
        else:
            await update.message.reply_text("❌ У вас нет прав для просмотра отчетов")
        return ADMIN_MESSAGE

    elif text in ["📅 отчет за месяц", "отчет за месяц"]:
        if user.id in CONFIG.get('admin_ids', []) or user.id in CONFIG.get('accounting_ids', []):
            await update.message.reply_text(
                "Выберите период:",
                reply_markup=create_month_selection_keyboard()
            )
            return SELECT_MONTH_RANGE
        else:
            await update.message.reply_text("❌ У вас нет прав для просмотра отчетов")
        return ADMIN_MESSAGE

    # Неизвестная команда
    await update.message.reply_text(
        "Неизвестная команда. Пожалуйста, используйте кнопки меню.",
        reply_markup=create_admin_keyboard()
    )
    return ADMIN_MESSAGE
