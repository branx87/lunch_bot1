import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardMarkup, KeyboardButton
from telegram.ext import ContextTypes
from datetime import datetime, timedelta, date
from config import CONFIG, LOCATIONS, TIMEZONE, MENU, ADMIN_IDS
from db import db
from utils import (
    is_employee,
    get_menu_for_day,
    format_menu,
    check_registration,
    handle_unregistered,
    can_modify_order,
    is_order_time_expired,
    is_order_cancelled
)
from .states import MAIN_MENU, ORDER_ACTION, SELECT_MONTH_RANGE_STATS
from .common import show_main_menu

logger = logging.getLogger(__name__)

async def show_today_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await check_registration(update, context):
        return await handle_unregistered(update, context)
    
    user_id = update.effective_user.id
    now = datetime.now(TIMEZONE)
    days_ru = ["Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", "Воскресенье"]
    day_name = days_ru[now.weekday()]
    menu = MENU.get(day_name)
    
    if not menu:
        await update.message.reply_text(f"⏳ Сегодня ({day_name}) выходной! Меню не предусмотрено.")
        return await show_main_menu(update, user_id)
    
    message = format_menu(menu, day_name)
    
    # Проверяем есть ли активный заказ
    db.cursor.execute(
        "SELECT quantity FROM orders WHERE user_id = "
        "(SELECT id FROM users WHERE telegram_id = ?) AND order_date = ? AND is_cancelled = FALSE",
        (user_id, now.date().isoformat())
    )
    has_active_order = db.cursor.fetchone() is not None
    
    can_modify = can_modify_order(now.date())
    
    if has_active_order:
        if can_modify:
            keyboard = [
                [InlineKeyboardButton("✏️ Изменить количество", callback_data="change_0")],
                [InlineKeyboardButton("❌ Отменить заказ", callback_data="cancel_0")]
            ]
        else:
            keyboard = [
                [InlineKeyboardButton("ℹ️ Заказ оформлен (изменение невозможно)", callback_data="noop")]
            ]
    else:
        if can_modify:
            keyboard = [
                [InlineKeyboardButton("✅ Заказать", callback_data="order_0")]
            ]
        else:
            keyboard = [
                [InlineKeyboardButton("⏳ Прием заказов завершен", callback_data="info")]
            ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text(message, reply_markup=reply_markup)
    return await show_main_menu(update, user_id)

async def show_week_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Показывает меню на неделю с возможностью заказа и изменения"""
    try:
        user = update.effective_user
        now = datetime.now(TIMEZONE)
        days_ru = ["Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", "Воскресенье"]
        user_id = user.id

        for i in range(7):
            day_date = now.date() + timedelta(days=i)
            day_name = days_ru[day_date.weekday()]

            # Пропускаем выходные
            if day_date.weekday() >= 5:
                continue

            menu = MENU.get(day_name)
            if not menu:
                continue

            menu_text = format_menu(menu, day_name, is_tomorrow=(i > 0))

            # Проверяем, есть ли заказ
            db.cursor.execute("""
                SELECT quantity 
                FROM orders 
                WHERE user_id = (
                    SELECT id FROM users 
                    WHERE telegram_id = ?
                )
                AND order_date = ?
                AND is_cancelled = FALSE
            """, (user_id, day_date.isoformat()))
            order = db.cursor.fetchone()

            # Формируем клавиатуру
            if order:
                qty = order[0]
                menu_text += f"\n✅ {'Предзаказ' if i > 0 else 'Заказ'}: {qty} порции"

                keyboard = [
                    [InlineKeyboardButton("✏️ Изменить", callback_data=f"change_{i}")],
                    [InlineKeyboardButton("❌ Отменить", callback_data=f"cancel_{i}")]
                ]
            else:
                keyboard = [
                    [InlineKeyboardButton("✅ Заказать", callback_data=f"order_{i}")]
                ]

            await update.message.reply_text(
                menu_text,
                reply_markup=InlineKeyboardMarkup(keyboard),
                parse_mode="Markdown"
            )

    except Exception as e:
        logger.error(f"Ошибка в show_week_menu: {e}")
        await update.message.reply_text("⚠️ Ошибка загрузки меню")

async def show_day_menu(update: Update, context: ContextTypes.DEFAULT_TYPE, day_offset=0):
    """Показывает меню на указанный день с возможностью заказа"""
    try:
        user = update.effective_user
        now = datetime.now(TIMEZONE)
        days_ru = ["Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", "Воскресенье"]
        target_date = now.date() + timedelta(days=day_offset)
        day_name = days_ru[target_date.weekday()]
        is_tomorrow = day_offset == 1
        is_today = day_offset == 0
        menu = MENU.get(day_name)

        # Если выходной
        if not menu:
            await update.message.reply_text(f"⏳ На {day_name} ({target_date.strftime('%d.%m')}) выходной!")
            return

        message = format_menu(menu, day_name, is_tomorrow=is_tomorrow)

        # Получаем ID пользователя из БД
        db.cursor.execute("SELECT id FROM users WHERE telegram_id = ?", (user.id,))
        user_record = db.cursor.fetchone()
        if not user_record:
            await update.message.reply_text("❌ Пользователь не найден")
            return
        user_db_id = user_record[0]

        # Получаем текущий заказ
        db.cursor.execute("""
            SELECT quantity 
            FROM orders 
            WHERE user_id = ?
              AND order_date = ?
              AND is_cancelled = FALSE
        """, (user_db_id, target_date.isoformat()))
        order = db.cursor.fetchone()

        # Добавляем информацию о заказе
        keyboard = []

        if order:
            qty = order[0]
            message += f"\n\n✅ {'Предзаказ' if day_offset > 0 else 'Заказ'}: {qty} порции"

            can_modify = can_modify_order(target_date)
            if can_modify:
                keyboard.append([InlineKeyboardButton("✏️ Изменить количество", callback_data=f"change_{day_offset}")])
            keyboard.append([
                InlineKeyboardButton("❌ Отменить заказ", callback_data=f"cancel_{day_offset}")
            ])
        else:
            can_modify = can_modify_order(target_date)
            if can_modify:
                keyboard.append([InlineKeyboardButton("✅ Заказать", callback_data=f"order_{day_offset}")])
            else:
                keyboard.append([InlineKeyboardButton("⏳ Приём заказов завершён", callback_data="noop")])

        await update.message.reply_text(
            message,
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode="Markdown"
        )

    except Exception as e:
        logger.error(f"Ошибка в show_day_menu: {e}")
        await update.message.reply_text("⚠️ Ошибка загрузки меню")

# --- Просмотр заказов ---
async def view_orders(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Показывает только будущие и сегодняшние активные (не отменённые) заказы"""
    try:
        # Определяем, откуда вызвана функция
        if hasattr(update, 'message'):
            user = update.effective_user
            message = update.message
        else:
            user = update.callback_query.from_user
            message = update.callback_query.message

        user_id = user.id
        now = datetime.now(TIMEZONE)
        today_str = now.date().isoformat()

        # Получаем только будущие и сегодняшние заказы
        db.cursor.execute("""
            SELECT o.order_date, o.quantity, o.is_preliminary
            FROM orders o
            JOIN users u ON o.user_id = u.id
            WHERE u.telegram_id = ?
            AND o.is_cancelled = FALSE
            AND o.order_date >= ?
            ORDER BY o.order_date
        """, (user_id, today_str))

        active_orders = db.cursor.fetchall()

        if not active_orders:
            await message.reply_text("ℹ️ У вас нет активных заказов.")
            return await show_main_menu(message, user_id)

        # Формируем текст ответа
        response = "📦 Ваши активные заказы:\n"
        keyboard = []

        days_ru = ["Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", "Воскресенье"]

        for order in active_orders:
            order_date = datetime.strptime(order[0], "%Y-%m-%d").date()
            day_name = days_ru[order_date.weekday()]
            date_str = order_date.strftime('%d.%m')
            qty = order[1]

            status = " (предварительный)" if order[2] else ""
            response += f"📅 {day_name} ({date_str}) - {qty} порций{status}\n"
            keyboard.append([
                InlineKeyboardButton(
                    f"✕ Отменить {date_str}",
                    callback_data=f"cancel_{order_date.strftime('%Y-%m-%d')}"
                )
            ])

        keyboard.append([
            InlineKeyboardButton("✔ В главное меню", callback_data="back_to_menu")
        ])

        await message.reply_text(
            response,
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode="Markdown"
        )

    except Exception as e:
        logger.error(f"Ошибка в view_orders: {e}")
        await message.reply_text("⚠️ Ошибка загрузки заказов")
        return await show_main_menu(message, user_id)

async def order_action(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    Обработчик действий с заказами:
    - Отмена заказа (cancel_...)
    - Изменение количества порций (change_...)
    - Подтверждение заказа (confirm_...)
    """
    try:
        query = update.callback_query
        await query.answer()  # Подтверждаем нажатие кнопки

        logger.info(f"Получен callback: {query.data} от пользователя {query.from_user.id}")

        if query.data.startswith("cancel_"):
            # Извлекаем дату из callback_data
            try:
                _, date_part = query.data.split("_", 1)

                # Определяем дату
                now = datetime.now(TIMEZONE)
                if '-' in date_part:
                    order_date = datetime.strptime(date_part, "%Y-%m-%d").date()
                elif date_part.isdigit():
                    day_offset = int(date_part)
                    order_date = (now + timedelta(days=day_offset)).date()
                else:
                    raise ValueError(f"Неверный формат даты: {date_part}")

                # Проверяем возможность отмены
                if not can_modify_order(order_date):
                    await query.answer("ℹ️ Отмена невозможна после 9:30", show_alert=True)
                    return

                # Получаем ID пользователя из БД
                db.cursor.execute("SELECT id FROM users WHERE telegram_id = ?", (query.from_user.id,))
                user_record = db.cursor.fetchone()
                if not user_record:
                    await query.answer("❌ Пользователь не найден", show_alert=True)
                    return

                user_db_id = user_record[0]

                # Отменяем заказ в БД
                with db.conn:
                    db.cursor.execute("""
                        UPDATE orders 
                        SET is_cancelled = TRUE,
                            order_time = ?
                        WHERE user_id = ?
                          AND order_date = ?
                          AND is_cancelled = FALSE
                    """, (now.strftime("%H:%M:%S"), user_db_id, order_date.isoformat()))

                    if db.cursor.rowcount == 0:
                        await query.answer("❌ Заказ не найден", show_alert=True)
                        return

                # Обновляем интерфейс
                days_ru = ["Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", "Воскресенье"]
                if "Меню на" in query.message.text:
                    # Отмена из меню дня
                    day_name = days_ru[order_date.weekday()]
                    menu = MENU.get(day_name)
                    await query.edit_message_text(
                        text=f"~~{format_menu(menu, day_name)}~~\n❌ Заказ отменён",
                        reply_markup=InlineKeyboardMarkup([
                            [InlineKeyboardButton("✅ Заказать", callback_data=f"order_{order_date.isoformat()}")]
                        ]),
                        parse_mode="Markdown"
                    )
                else:
                    # Отмена из списка заказов
                    await refresh_orders_view(query, context, query.from_user.id, now, days_ru)

                await query.answer("✅ Заказ отменён")

            except Exception as e:
                logger.error(f"Ошибка при отмене заказа: {e}")
                await query.answer("⚠️ Ошибка отмены", show_alert=True)

        elif query.data.startswith("change_"):
            # Логика изменения количества порций (заглушка)
            await query.answer("🔄 Изменение количества порций временно недоступно")
            return

        elif query.data.startswith("confirm_"):
            # Логика подтверждения заказа (заглушка)
            await query.answer("✅ Заказ подтверждён")
            return

        else:
            # Неизвестное действие
            logger.warning(f"Неизвестный callback: {query.data}")
            await query.answer("⚠️ Неизвестное действие", show_alert=True)

    except Exception as e:
        logger.error(f"Критическая ошибка в order_action: {e}", exc_info=True)
        await query.answer("⚠️ Серверная ошибка", show_alert=True)

async def monthly_stats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Показывает меню выбора месяца для статистики."""
    try:
        user = update.effective_user
        reply_markup = ReplyKeyboardMarkup(
            [["Текущий месяц", "Прошлый месяц"], ["Вернуться в главное меню"]],
            resize_keyboard=True,
            one_time_keyboard=True
        )
        await update.message.reply_text(
            "📅 Выберите месяц для статистики:",
            reply_markup=reply_markup
        )
        return SELECT_MONTH_RANGE_STATS
    except Exception as e:
        logger.error(f"Ошибка при запуске monthly_stats: {e}")
        await update.message.reply_text("❌ Произошла ошибка. Попробуйте позже.")
        return await show_main_menu(update, user.id)


async def monthly_stats_selected(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка выбора месяца и вывод статистики."""
    try:
        user = update.effective_user
        text = update.message.text.strip()

        # Проверяем, хочет ли вернуться в меню
        if text == "Вернуться в главное меню":
            return await show_main_menu(update, user.id)

        # Получаем текущую дату
        now = datetime.now(TIMEZONE)
        current_year = now.year
        current_month = now.month

        if text == "Текущий месяц":
            start_date = now.replace(day=1).date()
            month_name = now.strftime("%B %Y")
        elif text == "Прошлый месяц":
            # Вычисляем последний день прошлого месяца
            first_day_current_month = now.replace(day=1)
            last_day_prev_month = first_day_current_month - timedelta(days=1)
            start_date = last_day_prev_month.replace(day=1)
            month_name = last_day_prev_month.strftime("%B %Y")
        else:
            await update.message.reply_text("❌ Неизвестный период. Пожалуйста, выберите из предложенных вариантов.")
            return SELECT_MONTH_RANGE_STATS

        # Получаем ID пользователя из базы данных
        db.cursor.execute("SELECT id FROM users WHERE telegram_id = ?", (user.id,))
        user_record = db.cursor.fetchone()
        if not user_record:
            await update.message.reply_text("❌ Пользователь не найден в системе.")
            return await show_main_menu(update, user.id)

        user_db_id = user_record[0]

        # Считаем количество порций за выбранный месяц (только неотмененные заказы)
        db.cursor.execute("""
            SELECT SUM(quantity)
            FROM orders
            WHERE user_id = ?
              AND order_date >= ?
              AND order_date <= date(?, 'start of month', '+1 month', '-1 day')
              AND is_cancelled = FALSE
        """, (user_db_id, start_date.isoformat(), start_date.isoformat()))

        result = db.cursor.fetchone()
        total_orders = result[0] or 0

        # Формируем ответ
        if total_orders == 0:
            message = f"📉 У вас пока нет заказов за {month_name}."
        else:
            message = (
                f"📊 Ваша статистика за {month_name}:\n"
                f"• Всего заказано порций: {total_orders}"
            )

        await update.message.reply_text(message)

    except Exception as e:
        logger.error(f"Ошибка при обработке выбора месяца в статистике: {e}", exc_info=True)
        await update.message.reply_text("❌ Произошла ошибка при получении статистики.")

    finally:
        return await show_main_menu(update, user.id)
    
async def handle_order_confirmation(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        text = update.message.text
        user = update.effective_user
        
        if text == "Да":
            now = datetime.now(TIMEZONE)
            target_date = now + timedelta(days=1)
            if now.weekday() == 4:  # Пятница -> понедельник
                target_date += timedelta(days=2)
            
            db.cursor.execute(
                "INSERT INTO orders (user_id, order_date, order_time, quantity, is_preliminary) "
                "SELECT id, ?, ?, 1, TRUE FROM users WHERE telegram_id = ?",
                (target_date.date().isoformat(), now.strftime("%H:%M:%S"), user.id)
            )
            db.conn.commit()
            await update.message.reply_text(f"✅ Предзаказ на {target_date.strftime('%d.%m')} оформлен!")
        else:
            await update.message.reply_text("❌ Заказ отменен.")
        
        return await show_main_menu(update, user.id)
    except Exception as e:
        logger.error(f"Ошибка в handle_order_confirmation: {e}")
        await update.message.reply_text("⚠️ Произошла ошибка. Попробуйте снова.")
        return await show_main_menu(update, user.id)
