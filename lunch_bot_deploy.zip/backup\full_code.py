﻿

# === 2admin_handlers.py ===

import logging
from telegram import Update, ReplyKeyboardMarkup
from telegram.ext import ContextTypes, ConversationHandler, MessageHandler
from config import CONFIG, CONFIG_FILE, load_config
from keyboards import create_admin_keyboard, create_month_selection_keyboard
from admin import export_accounting_report
from .states import BROADCAST_MESSAGE, SELECT_MONTH_RANGE
from db import db
import asyncio
from filelock import FileLock
import openpyxl

logger = logging.getLogger(__name__)

async def handle_admin_choice(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка выбора в админ-меню"""
    text = update.message.text.strip().lower()
    user = update.effective_user

    # Проверка прав администратора
    if user.id not in CONFIG.get('admin_ids', []) and user.id not in CONFIG.get('accounting_ids', []):
        await update.message.reply_text("❌ У вас нет прав для выполнения этой команды.")
        return ConversationHandler.END  # Заменили ADMIN_MESSAGE на завершение диалога

    if text == "📢 Сделать рассылку":
        await update.message.reply_text(
            "Введите сообщение для рассылки:",
            reply_markup=ReplyKeyboardMarkup([["Отмена"]], resize_keyboard=True)
        )
        return BROADCAST_MESSAGE

    elif text == "отмена":
        await update.message.reply_text(
            "Действие отменено",
            reply_markup=create_admin_keyboard()
        )
        return ConversationHandler.END  # Заменили ADMIN_MESSAGE

    elif text in ["📊 отчет за день", "отчет за день"]:
        if user.id in CONFIG.get('admin_ids', []) or user.id in CONFIG.get('accounting_ids', []):
            await export_accounting_report(update, context)
        else:
            await update.message.reply_text("❌ У вас нет прав для просмотра отчетов")
        return ConversationHandler.END  # Заменили ADMIN_MESSAGE

    elif text in ["📅 отчет за месяц", "отчет за месяц"]:
        if user.id in CONFIG.get('admin_ids', []) or user.id in CONFIG.get('accounting_ids', []):
            await update.message.reply_text(
                "Выберите период:",
                reply_markup=create_month_selection_keyboard()
            )
            return SELECT_MONTH_RANGE
        else:
            await update.message.reply_text("❌ У вас нет прав для просмотра отчетов")
        return ConversationHandler.END  # Заменили ADMIN_MESSAGE

    # Неизвестная команда
    await update.message.reply_text(
        "Неизвестная команда. Пожалуйста, используйте кнопки меню.",
        reply_markup=create_admin_keyboard()
    )
    return ConversationHandler.END  # Заменили ADMIN_MESSAGE

async def handle_broadcast_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка команды рассылки"""
    user = update.effective_user
    if user.id not in CONFIG['admin_ids']:
        await update.message.reply_text("❌ У вас нет прав для этой команды")
        return
    
    await update.message.reply_text(
        "Введите сообщение для рассылки:",
        reply_markup=ReplyKeyboardMarkup([["❌ Отмена"]], resize_keyboard=True)
    )
    return "BROADCAST_MESSAGE"

async def process_broadcast_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка текста рассылки"""
    text = update.message.text
    
    if text.lower() in ["отменить рассылку", "❌ отменить рассылку"]:
        await update.message.reply_text(
            "❌ Рассылка отменена",
            reply_markup=create_admin_keyboard()
        )
        return ConversationHandler.END
    
    try:
        # Получаем всех верифицированных пользователей
        db.cursor.execute("SELECT telegram_id, full_name FROM users WHERE is_verified = TRUE")
        users = db.cursor.fetchall()
        
        if not users:
            await update.message.reply_text(
                "❌ Нет пользователей для рассылки",
                reply_markup=create_admin_keyboard()
            )
            return ConversationHandler.END
        
        # Отправляем уведомление о начале рассылки
        await update.message.reply_text(f"⏳ Начинаю рассылку для {len(users)} пользователей...")
        
        success = 0
        failed = []
        
        for user_id, full_name in users:
            try:
                await context.bot.send_message(
                    chat_id=user_id,
                    text=f"📢 Сообщение от администратора:\n\n{text}"
                )
                success += 1
                await asyncio.sleep(0.1)  # Задержка между сообщениями
            except Exception as e:
                failed.append(f"{full_name} (ID: {user_id})")
                logger.error(f"Ошибка отправки {user_id}: {e}")
        
        # Формируем отчет
        report = (
            f"✅ Рассылка завершена:\n"
            f"• Всего получателей: {len(users)}\n"
            f"• Успешно: {success}\n"
            f"• Не удалось: {len(failed)}"
        )
        
        if failed:
            report += "\n\nНе удалось отправить:\n" + "\n".join(failed[:10])  # Показываем первые 10 ошибок
        
        await update.message.reply_text(
            report,
            reply_markup=create_admin_keyboard()
        )
        
    except Exception as e:
        logger.error(f"Ошибка рассылки: {e}")
        await update.message.reply_text(
            "❌ Произошла ошибка при рассылке",
            reply_markup=create_admin_keyboard()
        )
    
    return ConversationHandler.END
    

async def add_user_id(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    Добавляет ID пользователя в конфигурационный файл
    Формат команды: /add_user <admin/provider/accounting> <user_id>
    """
    user = update.effective_user
    
    # Проверка прав
    if user.id not in CONFIG['admin_ids']:
        await update.message.reply_text("❌ Только администраторы могут добавлять пользователей")
        return

    try:
        # Парсим аргументы
        args = context.args
        if len(args) != 2:
            raise ValueError(
                "Неверный формат команды.\n"
                "Используйте: /add_user <тип> <id>\n"
                "Типы: admin, provider, accounting"
            )

        user_type = args[0].lower()
        new_id = int(args[1])  # Проверка что ID - число

        # Определяем столбец в Excel
        column_map = {
            'admin': 'B',
            'provider': 'C',
            'accounting': 'D'
        }

        if user_type not in column_map:
            raise ValueError("Неверный тип пользователя. Допустимо: admin, provider, accounting")

        column = column_map[user_type]

        # Блокировка файла для безопасной записи
        with FileLock(CONFIG_FILE + ".lock"):
            # Открываем Excel-файл
            wb = openpyxl.load_workbook(CONFIG_FILE)
            ws = wb.active
            
            # Ищем первую пустую ячейку в столбце
            row = 2
            while ws[f'{column}{row}'].value is not None:
                row += 1

            # Записываем новый ID
            ws[f'{column}{row}'] = new_id
            wb.save(CONFIG_FILE)

        # Обновляем конфиг в памяти
        global CONFIG
        CONFIG = load_config()
        
        # Обновляем соответствующий список ID
        if user_type == 'admin':
            CONFIG['admin_ids'].append(new_id)
        elif user_type == 'provider':
            CONFIG['provider_ids'].append(new_id)
        elif user_type == 'accounting':
            CONFIG['accounting_ids'].append(new_id)

        await update.message.reply_text(
            f"✅ Пользователь {new_id} успешно добавлен как {user_type}!\n"
            f"Текущие {user_type} IDs: {CONFIG[user_type + '_ids']}"
        )

    except ValueError as ve:
        await update.message.reply_text(f"❌ Ошибка ввода: {str(ve)}")
    except Exception as e:
        logger.error(f"Ошибка добавления пользователя: {e}", exc_info=True)
        await update.message.reply_text("❌ Произошла ошибка при добавлении пользователя")
        
__all__ = [
    'handle_admin_choice',
    'handle_broadcast_command',
    'process_broadcast_message',
    'add_user_id'  # Добавляем новую функцию в экспорт
]



# === admin_handlers.py ===

import logging
from telegram import Update, ReplyKeyboardMarkup
from telegram.ext import ContextTypes, ConversationHandler, MessageHandler
from config import CONFIG
from keyboards import create_admin_keyboard, create_month_selection_keyboard
from admin import export_accounting_report
from .states import BROADCAST_MESSAGE, SELECT_MONTH_RANGE
from db import db
import asyncio

logger = logging.getLogger(__name__)

async def handle_admin_choice(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка выбора в админ-меню"""
    text = update.message.text.strip().lower()
    user = update.effective_user

    # Проверка прав администратора
    if user.id not in CONFIG.get('admin_ids', []) and user.id not in CONFIG.get('accounting_ids', []):
        await update.message.reply_text("❌ У вас нет прав для выполнения этой команды.")
        return ConversationHandler.END  # Заменили ADMIN_MESSAGE на завершение диалога

    if text == "📢 Сделать рассылку":
        await update.message.reply_text(
            "Введите сообщение для рассылки:",
            reply_markup=ReplyKeyboardMarkup([["Отмена"]], resize_keyboard=True)
        )
        return BROADCAST_MESSAGE

    elif text == "отмена":
        await update.message.reply_text(
            "Действие отменено",
            reply_markup=create_admin_keyboard()
        )
        return ConversationHandler.END  # Заменили ADMIN_MESSAGE

    elif text in ["📊 отчет за день", "отчет за день"]:
        if user.id in CONFIG.get('admin_ids', []) or user.id in CONFIG.get('accounting_ids', []):
            await export_accounting_report(update, context)
        else:
            await update.message.reply_text("❌ У вас нет прав для просмотра отчетов")
        return ConversationHandler.END  # Заменили ADMIN_MESSAGE

    elif text in ["📅 отчет за месяц", "отчет за месяц"]:
        if user.id in CONFIG.get('admin_ids', []) or user.id in CONFIG.get('accounting_ids', []):
            await update.message.reply_text(
                "Выберите период:",
                reply_markup=create_month_selection_keyboard()
            )
            return SELECT_MONTH_RANGE
        else:
            await update.message.reply_text("❌ У вас нет прав для просмотра отчетов")
        return ConversationHandler.END  # Заменили ADMIN_MESSAGE

    # Неизвестная команда
    await update.message.reply_text(
        "Неизвестная команда. Пожалуйста, используйте кнопки меню.",
        reply_markup=create_admin_keyboard()
    )
    return ConversationHandler.END  # Заменили ADMIN_MESSAGE


# === base_handlers.py ===

import logging
import asyncio
from telegram import Update, ReplyKeyboardRemove, KeyboardButton, ReplyKeyboardMarkup
from telegram.ext import ConversationHandler, ContextTypes
from .states import PHONE, MAIN_MENU, SELECT_MONTH_RANGE, FULL_NAME
from db import db
from config import CONFIG, ADMIN_IDS
from keyboards import create_main_menu_keyboard
from utils import check_registration, handle_unregistered
from .menu_handlers import show_today_menu, show_week_menu, view_orders, monthly_stats
from datetime import datetime, timedelta
from .common import show_main_menu
from .report_handlers import select_month_range
from admin import export_accounting_report
from .message_handlers import process_broadcast_message

logger = logging.getLogger(__name__)

__all__ = ['start', 'error_handler', 'test_connection', 'main_menu', 'handle_text_message']

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Обновляю меню...", reply_markup=ReplyKeyboardRemove())
    user = update.effective_user
    context.user_data['restored'] = True
    
    try:
        context.user_data['is_initialized'] = True
        db.cursor.execute("SELECT is_verified FROM users WHERE telegram_id = ?", (user.id,))
        user_data = db.cursor.fetchone()

        if not user_data:
            keyboard = [[KeyboardButton("📱 Отправить номер телефона", request_contact=True)]]
            reply_markup = ReplyKeyboardMarkup(keyboard, resize_keyboard=True, one_time_keyboard=True)
            await update.message.reply_text(
                "Для регистрации нам нужен ваш номер телефона:",
                reply_markup=reply_markup
            )
            return PHONE
        elif not user_data[0]:
            db.cursor.execute("DELETE FROM users WHERE telegram_id = ?", (user.id,))
            db.conn.commit()
            keyboard = [[KeyboardButton("📱 Отправить номер телефона", request_contact=True)]]
            reply_markup = ReplyKeyboardMarkup(keyboard, resize_keyboard=True, one_time_keyboard=True)
            await update.message.reply_text(
                "Пожалуйста, завершите регистрацию:",
                reply_markup=reply_markup
            )
            return PHONE
        else:
            return await show_main_menu(update, user.id)
    except Exception as e:
        logger.error(f"Ошибка в start: {e}")
        await update.message.reply_text("Произошла ошибка. Попробуйте снова.")
        return await show_main_menu(update, user.id)

async def error_handler(update: object, context: ContextTypes.DEFAULT_TYPE) -> None:
    error = str(context.error)
    logger.error(f"Ошибка: {error}", exc_info=context.error)
    
    for admin_id in ADMIN_IDS:
        try:
            await context.bot.send_message(
                chat_id=admin_id,
                text=f"⚠️ Ошибка в боте:\n\n{error}\n\n"
                     f"Update: {update if update else 'Нет данных'}"
            )
        except Exception as e:
            logger.error(f"Не удалось отправить сообщение админу {admin_id}: {e}")
    
    if update and isinstance(update, Update) and update.effective_message:
        try:
            await update.effective_message.reply_text("⚠️ Произошла ошибка. Пожалуйста, попробуйте позже.")
        except Exception as e:
            logger.error(f"Не удалось отправить сообщение пользователю: {e}")

async def test_connection(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        msg = await update.message.reply_text("🔄 Тестируем соединение...")
        bot_info = await context.bot.get_me()
        test_msg = await update.message.reply_text(
            f"✅ Соединение работает\n"
            f"🤖 Бот: @{bot_info.username}\n"
            f"🆔 ID: {bot_info.id}\n"
            f"📝 Имя: {bot_info.first_name}"
        )
        await asyncio.sleep(5)
        await msg.delete()
        await test_msg.delete()
    except Exception as e:
        logger.error(f"Ошибка соединения: {e}")
        await update.message.reply_text(
            f"❌ Ошибка соединения:\n{str(e)}\n"
            "Проверьте:\n"
            "1. Интернет-соединение\n"
            "2. Токен бота\n"
            "3. Ограничения сервера"
        )

async def handle_text_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    text = update.message.text
    logger.info(f"Получено сообщение: '{text}' от {user.id}")
    
    try:
        # 1. Обработка сообщения от незарегистрированного пользователя
        if text == "Написать администратору":
            unverified_name = context.user_data.get('unverified_name', 'не указано')
            message = (
                f"⚠️ Незарегистрированный пользователь сообщает:\n"
                f"👤 Имя: {unverified_name}\n"
                f"🆔 ID: {user.id}\n"
                f"📱 Username: @{user.username if user.username else 'нет'}\n"
                f"✉️ Сообщение: Пользователь не найден в списке сотрудников"
            )
            
            for admin_id in ADMIN_IDS:
                try:
                    await context.bot.send_message(chat_id=admin_id, text=message)
                except Exception as e:
                    logger.error(f"Ошибка отправки админу {admin_id}: {e}")
            
            await update.message.reply_text(
                "✅ Ваше сообщение отправлено администратору. Ожидайте ответа.",
                reply_markup=ReplyKeyboardMarkup([["Попробовать снова"]], resize_keyboard=True)
            )
            return FULL_NAME

        # 2. Проверка регистрации
        if not await check_registration(update, context):
            return await handle_unregistered(update, context)

        # 3. Обработка команд отчетов
        if text in ["💰 Бухгалтерский отчет", "📦 Отчет поставщика"]:
            context.user_data['report_type'] = 'accounting' if text.startswith('💰') else 'provider'
            await update.message.reply_text(
                "Выберите период:",
                reply_markup=ReplyKeyboardMarkup([
                    ["Текущий месяц", "Прошлый месяц"],
                    ["Вернуться в главное меню"]
                ], resize_keyboard=True)
            )
            return SELECT_MONTH_RANGE
        
        if text in ["Текущий месяц", "Прошлый месяц"] and context.user_data.get('report_type'):
            return await select_month_range(update, context)
        
        # 4. Все остальные команды
        return await main_menu(update, context)
        
    except Exception as e:
        logger.error(f"Ошибка в handle_text_message: {e}", exc_info=True)
        await update.message.reply_text(
            "⚠️ Произошла ошибка. Попробуйте снова или используйте /start",
            reply_markup=ReplyKeyboardRemove()
        )
        return await show_main_menu(update, user.id)

async def main_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    logger.info(f"Получена команда: '{update.message.text}' от пользователя {update.effective_user.id}")
    
    try:
        user = update.effective_user
        text = update.message.text
        
        # Проверка регистрации
        if not await check_registration(update, context):
            return await handle_unregistered(update, context)

        from keyboards import create_main_menu_keyboard  # Добавляем импорт
        
        # Основные команды меню
        if text == "Меню на сегодня":
            return await show_today_menu(update, context)
        
        elif text == "Меню на неделю":
            return await show_week_menu(update, context)
        
        elif text == "Просмотреть заказы":
            return await view_orders(update, context)
        
        elif text == "Статистика за месяц":
            return await monthly_stats(update, context)
        
        # elif text == "Написать администратору":
            # return await start_admin_message(update, context)
        
        elif text == "Вернуться в главное меню":
            return await show_main_menu(update, user.id)
        
        elif text == "Обновить меню":
            await update.message.reply_text("Обновляю меню...", reply_markup=ReplyKeyboardRemove())
            return await show_main_menu(update, user.id)

        # Обработка отчетов
        elif text == "💰 Бухгалтерский отчет":
            if user.id in CONFIG['accounting_ids']:
                context.user_data['report_type'] = 'accounting'
                logger.info(f"Установлен report_type: accounting для пользователя {user.id}")
                await update.message.reply_text(
                    "Выберите период:",
                    reply_markup=ReplyKeyboardMarkup([
                        ["Текущий месяц"],
                        ["Прошлый месяц"],
                        ["Вернуться в главное меню"]
                    ], resize_keyboard=True)
                )
                return SELECT_MONTH_RANGE
            else:
                await update.message.reply_text("❌ У вас нет прав для просмотра бухгалтерских отчетов")
                return await show_main_menu(update, user.id)

        elif text == "📦 Отчет поставщика":
            if user.id in CONFIG['provider_ids']:
                context.user_data['report_type'] = 'provider'
                logger.info(f"Установлен report_type: provider для пользователя {user.id}")
                await update.message.reply_text(
                    "Выберите период:",
                    reply_markup=ReplyKeyboardMarkup([
                        ["Текущий месяц"],
                        ["Прошлый месяц"],
                        ["Вернуться в главное меню"]
                    ], resize_keyboard=True)
                )
                return SELECT_MONTH_RANGE
            else:
                await update.message.reply_text("❌ У вас нет прав для просмотра отчетов поставщика")
                return await show_main_menu(update, user.id)

        # Для администраторов
        elif text == "📊 Отчет за день":
            if user.id in CONFIG['admin_ids']:
                context.user_data['report_type'] = 'admin'
                await export_accounting_report(update, context)
                return await show_main_menu(update, user.id)
            else:
                await update.message.reply_text("❌ Эта команда только для администраторов")
                return await show_main_menu(update, user.id)

        elif text == "📅 Отчет за месяц":
            if user.id in CONFIG['admin_ids']:
                context.user_data['report_type'] = 'admin'
                await update.message.reply_text(
                    "Выберите период:",
                    reply_markup=ReplyKeyboardMarkup([
                        ["Текущий месяц"],
                        ["Прошлый месяц"],
                        ["Вернуться в главное меню"]
                    ], resize_keyboard=True)
                )
                return SELECT_MONTH_RANGE
            else:
                await update.message.reply_text("❌ Эта команда только для администраторов")
                return await show_main_menu(update, user.id)

        # Обработка неизвестной команды
        else:
            await update.message.reply_text(
                "Неизвестная команда. Попробуйте обновить меню или используйте /start",
                reply_markup=ReplyKeyboardRemove()
            )
            return await show_main_menu(update, user.id)

    except Exception as e:
        logger.error(f"Ошибка в main_menu: {e}", exc_info=True)
        from keyboards import create_main_menu_keyboard  # Импорт в блоке except
        await update.message.reply_text(
            "⚠️ Произошла ошибка. Попробуйте снова.",
            reply_markup=create_main_menu_keyboard(user.id)
        )
    
async def handle_registered_user(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик для зарегистрированных пользователей"""
    user = update.effective_user
    
    # Проверяем регистрацию
    db.cursor.execute("SELECT is_verified FROM users WHERE telegram_id = ?", (user.id,))
    result = db.cursor.fetchone()
    
    if not result or not result[0]:
        await update.message.reply_text(
            "Пожалуйста, сначала зарегистрируйтесь через /start",
            reply_markup=ReplyKeyboardRemove()
        )
        return
    
    # Если пользователь зарегистрирован - обрабатываем команду
    text = update.message.text
    
    # Обработка отчетов
    if text == "💰 Бухгалтерский отчет":
        if user.id in CONFIG['accounting_ids']:
            context.user_data['report_type'] = 'accounting'
            await update.message.reply_text(
                "Выберите период:",
                reply_markup=ReplyKeyboardMarkup([
                    ["Текущий месяц", "Прошлый месяц"],
                    ["Вернуться в главное меню"]
                ], resize_keyboard=True)
            )
            return SELECT_MONTH_RANGE
    
    elif text == "📦 Отчет поставщика":
        if user.id in CONFIG['provider_ids']:
            context.user_data['report_type'] = 'provider'
            await update.message.reply_text(
                "Выберите период:",
                reply_markup=ReplyKeyboardMarkup([
                    ["Текущий месяц", "Прошлый месяц"],
                    ["Вернуться в главное меню"]
                ], resize_keyboard=True)
            )
            return SELECT_MONTH_RANGE
    
    # Все остальные команды обрабатываем через main_menu
    return await main_menu(update, context)



# === callback_handlers.py ===

import logging
from telegram import Update, ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardRemove
from datetime import datetime, timedelta
from config import CONFIG, LOCATIONS, TIMEZONE, MENU, ADMIN_IDS
from db import db
from telegram.ext import CommandHandler, MessageHandler, CallbackQueryHandler, ConversationHandler, filters, ContextTypes
from .states import MAIN_MENU
from .common import show_main_menu
from utils import can_modify_order, is_order_cancelled
from utils import format_menu
import sqlite3
from .menu_handlers import view_orders

logger = logging.getLogger(__name__)

async def handle_order_callback(query, now, user, context):
    """Оформление заказа с ручной проверкой дат"""
    try:
        # Парсим параметры из callback
        _, day_offset_str = query.data.split("_", 1)
        day_offset = int(day_offset_str)
        target_date = (now + timedelta(days=day_offset)).date()
        
        # Ручная проверка 1: Заказы на выходные не принимаются
        if target_date.weekday() >= 5:  # 5-6 = суббота-воскресенье
            await query.answer("ℹ️ Заказы на выходные не принимаются", show_alert=True)
            return

        # Ручная проверка 2: Предзаказы только на будущие даты
        if day_offset > 0 and target_date <= now.date():
            await query.answer("❌ Предзаказ можно сделать только на будущие даты", show_alert=True)
            return

        # Ручная проверка 3: Обычные заказы только на сегодня и до 9:30
        if day_offset == 0:
            if now.time() >= time(9, 30):
                await query.answer("ℹ️ Приём заказов на сегодня завершён в 9:30", show_alert=True)
                return

        # Получаем ID пользователя из БД
        db.cursor.execute("SELECT id FROM users WHERE telegram_id = ?", (user.id,))
        user_record = db.cursor.fetchone()
        if not user_record:
            await query.answer("❌ Пользователь не найден", show_alert=True)
            return
        user_db_id = user_record[0]

        # Проверяем существующий заказ
        db.cursor.execute("""
            SELECT quantity FROM orders 
            WHERE user_id = ? 
              AND target_date = ?
              AND is_cancelled = FALSE
        """, (user_db_id, target_date.isoformat()))
        existing_order = db.cursor.fetchone()

        if existing_order:
            await query.answer(f"ℹ️ У вас уже заказано {existing_order[0]} порций", show_alert=True)
            return

        # Создаём новый заказ
        with db.conn:
            db.cursor.execute("""
                INSERT INTO orders (
                    user_id,
                    target_date,
                    order_time,
                    quantity,
                    is_preliminary,
                    created_at
                ) VALUES (?, ?, ?, ?, ?, ?)
            """, (
                user_db_id,
                target_date.isoformat(),
                now.strftime("%H:%M:%S"),  # Только время
                1,  # Количество порций
                day_offset > 0,  # Это предзаказ?
                datetime.now().strftime("%Y-%m-%d %H:%M:%S")  # Полная дата-время
            ))

        # Обновляем интерфейс
        await refresh_day_view(query, day_offset, user_db_id, now, is_order=True)
        await query.answer("✅ Заказ успешно оформлен")

    except Exception as e:
        logger.error(f"Ошибка при оформлении заказа: {e}", exc_info=True)
        await query.answer("⚠️ Произошла ошибка. Попробуйте позже", show_alert=True)

async def handle_change_callback(query, now, user, context):
    """Обработчик изменения количества порций с сохранением меню"""
    try:
        _, day_offset_str = query.data.split("_", 1)
        day_offset = int(day_offset_str)
        target_date = (now + timedelta(days=day_offset)).date()
        days_ru = ["Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", "Воскресенье"]
        day_name = days_ru[target_date.weekday()]
        menu = MENU.get(day_name)

        # Проверка возможности изменения
        if not can_modify_order(target_date):
            await query.answer("ℹ️ Изменение невозможно после 9:30", show_alert=True)
            return await refresh_day_view(query, day_offset, context.user_data['user_db_id'], now)

        # Получаем ID пользователя
        db.cursor.execute("SELECT id FROM users WHERE telegram_id = ?", (user.id,))
        user_db_id = db.cursor.fetchone()[0]
        context.user_data['user_db_id'] = user_db_id
        context.user_data['current_day_offset'] = day_offset

        # Получаем текущее количество порций
        db.cursor.execute("""
            SELECT quantity FROM orders 
            WHERE user_id = ? AND target_date = ? AND is_cancelled = FALSE
        """, (user_db_id, target_date.isoformat()))
        current_qty = db.cursor.fetchone()[0]

        # Формируем текст сообщения
        menu_text = (
            f"🍽 Меню на {day_name} ({target_date.strftime('%d.%m')}):\n"
            f"1. 🍲 Первое: {menu['first']}\n"
            f"2. 🍛 Основное блюдо: {menu['main']}\n"
            f"3. 🥗 Салат: {menu['salad']}\n\n"
            f"🛒 Текущий заказ: {current_qty} порции"
        )

        # Создаем клавиатуру
        keyboard = [
            [
                InlineKeyboardButton("➖ Уменьшить", callback_data=f"dec_{day_offset}"),
                InlineKeyboardButton("➕ Увеличить", callback_data=f"inc_{day_offset}")
            ],
            [InlineKeyboardButton("✔️ Подтвердить", callback_data=f"confirm_{day_offset}")],
            [InlineKeyboardButton("❌ Отменить заказ", callback_data=f"cancel_{day_offset}")]
        ]

        # Обновляем сообщение
        await query.edit_message_text(
            text=menu_text,
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode="Markdown"
        )
        await query.answer()

    except Exception as e:
        logger.error(f"Ошибка в handle_change_callback: {e}", exc_info=True)
        await query.answer("⚠️ Ошибка изменения", show_alert=True)
        
async def handle_quantity_change(query, now, user, context):
    """Увеличение/уменьшение порций с проверкой времени и максимума"""
    try:
        action, day_offset_str = query.data.split("_", 1)
        day_offset = int(day_offset_str)
        target_date = (now + timedelta(days=day_offset)).date()
        max_portions = 3  # Ваша константа

        # Проверка времени (ваша существующая проверка)
        if not can_modify_order(target_date):
            await query.answer("ℹ️ Изменение невозможно после 9:30", show_alert=True)
            return

        # Получаем ID пользователя (ваш существующий код)
        db.cursor.execute("SELECT id FROM users WHERE telegram_id = ?", (user.id,))
        user_record = db.cursor.fetchone()
        if not user_record:
            await query.answer("❌ Пользователь не найден", show_alert=True)
            return
        user_db_id = user_record[0]

        # Получаем текущее количество (ваш код)
        db.cursor.execute("""
            SELECT quantity 
            FROM orders 
            WHERE user_id = ?
              AND target_date = ?
              AND is_cancelled = FALSE
        """, (user_db_id, target_date.isoformat()))
        result = db.cursor.fetchone()
        if not result:
            await query.answer("❌ Заказ не найден", show_alert=True)
            return
        current_quantity = result[0]

        # Логика изменения (основана на вашей реализации)
        if action == "increase":
            if current_quantity >= max_portions:
                await query.answer("ℹ️ Максимальное количество порций (3) достигнуто", show_alert=True)
                return
            new_quantity = current_quantity + 1
            feedback = f"✅ Увеличено до {new_quantity} порций"
            
        elif action == "decrease":
            if current_quantity <= 1:
                # Ваш код отмены заказа
                with db.conn:
                    db.cursor.execute("""
                        UPDATE orders
                        SET is_cancelled = TRUE,
                            order_time = ?
                        WHERE user_id = ?
                          AND target_date = ?
                          AND is_cancelled = FALSE
                    """, (now.strftime("%H:%M:%S"), user_db_id, target_date.isoformat()))
                
                days_ru = ["Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", "Воскресенье"]
                day_name = days_ru[target_date.weekday()]
                
                await query.edit_message_text(
                    text=f"❌ Заказ на {day_name} отменён",
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("✅ Заказать", callback_data=f"order_{day_offset}")]
                    ])
                )
                await query.answer("ℹ️ Заказ отменён")
                return
                
            new_quantity = current_quantity - 1
            feedback = f"✅ Уменьшено до {new_quantity} порций"
            
        else:
            await query.answer("⚠️ Неизвестное действие")
            return

        # Обновляем количество (ваш код)
        with db.conn:
            db.cursor.execute("""
                UPDATE orders
                SET quantity = ?,
                    order_time = ?
                WHERE user_id = ?
                  AND target_date = ?
                  AND is_cancelled = FALSE
            """, (new_quantity, now.strftime("%H:%M:%S"), user_db_id, target_date.isoformat()))

        # Используем refresh_day_view вместо прямого редактирования
        await refresh_day_view(query, day_offset, user_db_id, now)
        await query.answer(feedback)

    except Exception as e:
        logger.error(f"Ошибка изменения количества ({action}): {e}")
        await query.answer("⚠️ Ошибка изменения. Попробуйте позже", show_alert=True)

# --- Callback для отмены заказа ---
async def handle_cancel_callback(query, now, user, context):
    """Отмена заказа с улучшенной обработкой ошибок и безопасностью"""
    try:
        # Проверяем формат callback данных
        if not query.data or '_' not in query.data:
            logger.warning(f"Некорректный callback: {query.data}")
            await query.answer("⚠️ Ошибка в запросе")
            return

        # Разбираем данные callback
        _, date_part = query.data.split("_", 1)
        
        # Определяем дату заказа
        if '-' in date_part:  # Формат YYYY-MM-DD
            try:
                if len(date_part.split('-')) != 3:
                    raise ValueError
                    
                target_date = datetime.strptime(target_date_str, "%Y-%m-%d").date()
                day_offset = (target_date - now.date()).days
            except ValueError:
                logger.error(f"Неверный формат даты в callback: {date_part}")
                await query.answer("⚠️ Ошибка в дате")
                return
                
        elif date_part.isdigit():  # Смещение дней
            day_offset = int(date_part)
            target_date = (now + timedelta(days=day_offset)).date()
        else:
            logger.error(f"Неизвестный формат даты: {query.data}")
            await query.answer("⚠️ Ошибка в запросе")
            return

        # Проверяем можно ли отменять заказ
        if not can_modify_order(target_date):
            await query.answer("ℹ️ Отмена невозможна после 9:30", show_alert=True)
            return

        # Получаем ID пользователя из БД
        db.cursor.execute(
            "SELECT id FROM users WHERE telegram_id = ? AND is_verified = TRUE",
            (user.id,)
        )
        user_record = db.cursor.fetchone()
        
        if not user_record:
            await query.answer("❌ Пользователь не найден", show_alert=True)
            return
            
        user_db_id = user_record[0]

        # Выполняем отмену заказа в транзакции
        with db.conn:
            db.cursor.execute("""
                UPDATE orders
                SET is_cancelled = TRUE,
                    order_time = ?
                WHERE user_id = ?
                  AND target_date = ?
                  AND is_cancelled = FALSE
                RETURNING id
            """, (now.strftime("%H:%M:%S"), user_db_id, target_date.isoformat()))
            
            # Проверяем что заказ был найден и отменен
            if not db.cursor.fetchone():
                await query.answer("❌ Заказ не найден", show_alert=True)
                return

        # Логируем отмену
        logger.info(
            f"Пользователь {user.id} отменил заказ на {target_date}"
        )

        # Обновляем интерфейс
        try:
            await refresh_day_view(query, day_offset, user_db_id, now)
            await query.answer("✅ Заказ отменён")
        except Exception as e:
            logger.error(f"Ошибка обновления интерфейса: {e}")
            await query.answer("⚠️ Заказ отменён, но возникла ошибка отображения")

    except Exception as e:
        logger.error(f"Критическая ошибка в handle_cancel_callback: {e}", exc_info=True)
        await query.answer("⚠️ Произошла ошибка. Попробуйте снова.", show_alert=True)

async def refresh_orders_view(query, context, user_id, now, days_ru):
    """Обновляет список заказов после изменения количества"""
    try:
        db.cursor.execute("""
            SELECT o.target_date, o.quantity, o.is_preliminary
            FROM orders o
            JOIN users u ON o.user_id = u.id
            WHERE u.telegram_id = ?
              AND o.is_cancelled = FALSE
              AND o.target_date >= ?
            ORDER BY o.target_date
        """, (user_id, now.date().isoformat()))

        active_orders = db.cursor.fetchall()

        if not active_orders:
            await query.edit_message_text("ℹ️ У вас нет активных заказов.")
            return await show_main_menu(query.message, user_id)

        response = "📦 Ваши активные заказы:\n"
        keyboard = []

        for order in active_orders:
            target_date = datetime.strptime(order[0], "%Y-%m-%d").date()
            day_name = days_ru[target_date.weekday()]
            date_str = target_date.strftime('%d.%m')
            qty = order[1]
            status = " (предварительный)" if order[2] else ""

            response += f"📅 {day_name} ({date_str}) - {qty} порций{status}\n"
            keyboard.append([
                InlineKeyboardButton(f"✏️ Изменить {date_str}", callback_data=f"change_{target_date.strftime('%Y-%m-%d')}"),
                InlineKeyboardButton(f"✕ Отменить {date_str}", callback_data=f"cancel_{target_date.strftime('%Y-%m-%d')}")
            ])

        keyboard.append([InlineKeyboardButton("✔ В главное меню", callback_data="back_to_menu")])

        await query.edit_message_text(
            response,
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode="Markdown"
        )

    except Exception as e:
        logger.error(f"Ошибка обновления списка: {e}")
        await query.edit_message_text("⚠️ Ошибка загрузки заказов")

async def refresh_day_view(query, day_offset, user_db_id, now, is_order=False):
    """Обновляет меню дня с информацией о заказе"""
    try:
        days_ru = ["Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", "Воскресенье"]
        target_date = (now + timedelta(days=day_offset)).date()
        day_name = days_ru[target_date.weekday()]
        date_str = target_date.strftime("%d.%m")
        menu = MENU.get(day_name)

        # Формируем текст сообщения
        if not menu:
            response_text = f"📅 {day_name} ({date_str}) - выходной! Меню не предусмотрено."
        else:
            response_text = (
                f"🍽 Меню на {day_name} ({date_str}):\n"
                f"1. 🍲 Первое: {menu['first']}\n"
                f"2. 🍛 Основное блюдо: {menu['main']}\n"
                f"3. 🥗 Салат: {menu['salad']}"
            )

        # Проверяем заказ пользователя
        db.cursor.execute("""
            SELECT quantity, is_preliminary 
            FROM orders 
            WHERE user_id = ? 
              AND target_date = ?
              AND is_cancelled = FALSE
        """, (user_db_id, target_date.isoformat()))
        order = db.cursor.fetchone()

        # Добавляем информацию о заказе
        keyboard = []
        if order:
            qty, is_preliminary = order
            order_type = "Предзаказ" if is_preliminary else "Заказ"
            response_text += f"\n\n✅ {order_type}: {qty} порции"
            
            if can_modify_order(target_date):
                keyboard.append([InlineKeyboardButton("✏️ Изменить", callback_data=f"change_{day_offset}")])
                keyboard.append([InlineKeyboardButton("❌ Отменить", callback_data=f"cancel_{day_offset}")])
            else:
                response_text += "\n⏳ Изменение невозможно (время истекло)"
        elif can_modify_order(target_date):
            keyboard.append([InlineKeyboardButton("✅ Заказать", callback_data=f"order_{day_offset}")])
        else:
            response_text += "\n⏳ Приём заказов завершён"

        # Отправляем обновлённое сообщение
        await query.edit_message_text(
            text=response_text,
            reply_markup=InlineKeyboardMarkup(keyboard) if keyboard else None,
            parse_mode="Markdown"
        )

    except Exception as e:
        logger.error(f"Ошибка обновления дня: {e}", exc_info=True)
        await query.answer("⚠️ Ошибка обновления. Попробуйте позже", show_alert=True)

async def modify_portion_count(query, now, user, context, delta):
    """Изменение количества порций"""
    try:
        day_offset = context.user_data['current_day_offset']
        target_date = (now + timedelta(days=day_offset)).date()
        user_db_id = context.user_data['user_db_id']
        
        # Получаем текущее количество
        db.cursor.execute("""
            SELECT quantity FROM orders 
            WHERE user_id = ? AND target_date = ? AND is_cancelled = FALSE
        """, (user_db_id, target_date.isoformat()))
        current_qty = db.cursor.fetchone()[0]
        new_qty = current_qty + delta

        # Проверка границ
        if new_qty < 1:
            return await handle_cancel_callback(query, now, user, context)
        if new_qty > 3:
            await query.answer("ℹ️ Максимум 3 порции")
            return

        # Обновляем количество
        with db.conn:
            db.cursor.execute("""
                UPDATE orders SET quantity = ? 
                WHERE user_id = ? AND target_date = ? AND is_cancelled = FALSE
            """, (new_qty, user_db_id, target_date.isoformat()))

        # Обновляем интерфейс без возврата в меню
        await handle_change_callback(query, now, user, context)
        await query.answer(f"Установлено: {new_qty} порции")

    except Exception as e:
        logger.error(f"Ошибка изменения количества: {e}")
        await query.answer("⚠️ Ошибка изменения", show_alert=True)

async def handle_confirm_callback(query, now, user, context):
    """Подтверждение заказа"""
    try:
        day_offset = context.user_data['current_day_offset']
        await refresh_day_view(query, day_offset, context.user_data['user_db_id'], now)
        await query.answer("✅ Заказ подтверждён")
    except Exception as e:
        logger.error(f"Ошибка подтверждения: {e}")
        await query.answer("⚠️ Ошибка подтверждения", show_alert=True)

async def callback_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    now = datetime.now(TIMEZONE)
    user = update.effective_user
    
    try:
        if query.data.startswith("inc_"):
            await modify_portion_count(query, now, user, context, +1)
        elif query.data.startswith("dec_"):
            await modify_portion_count(query, now, user, context, -1)
        elif query.data.startswith("change_"):
            await handle_change_callback(query, now, user, context)
        elif query.data.startswith("cancel_"):
            await handle_cancel_callback(query, now, user, context)
        elif query.data.startswith("confirm_"):
            await handle_confirm_callback(query, now, user, context)
        elif query.data.startswith("order_"):
            await handle_order_callback(query, now, user, context)
        elif query.data == "back_to_menu":
            await show_main_menu(query.message, user.id)
        elif query.data == "noop":
            await query.answer()  # Пустое действие
        elif query.data == "refresh":
            pass  # Логика обновления, если нужно
        else:
            logger.warning(f"Неизвестный callback: {query.data}")
            await query.answer("⚠️ Неизвестная команда")

    except Exception as e:
        logger.error(f"Ошибка в callback_handler: {e}", exc_info=True)
        try:
            await query.answer("⚠️ Произошла ошибка. Попробуйте позже")
        except Exception as inner_e:
            logger.error(f"Ошибка при обработке callback: {inner_e}")
    
async def handle_cancel_order(query, target_date_str):
    if not can_modify_order(target_date_str):  # Используем ВАШУ проверку
        await query.answer("ℹ️ Отмена заказа невозможна после 9:30", show_alert=True)
        return
    
    """Обработка отмены заказа по конкретной дате"""
    user_id = query.from_user.id
    target_date = datetime.strptime(target_date_str, "%Y-%m-%d").date()
    now = datetime.now(TIMEZONE)
    
    if not can_modify_order(target_date):
        await query.answer("ℹ️ Отмена невозможна (после 9:30)", show_alert=True)
        return False

    db.cursor.execute(
        "DELETE FROM orders WHERE user_id = "
        "(SELECT id FROM users WHERE telegram_id = ?) AND target_date = ?",
        (user_id, target_date_str)
    )
    db.conn.commit()
    
    return db.cursor.rowcount > 0
    
async def handle_back_callback(query, now, user, context):
    """Обработчик кнопки 'Назад'"""
    try:
        _, day_offset_str = query.data.split("_", 1)
        day_offset = int(day_offset_str)
        await refresh_day_view(query, day_offset, context.user_data['user_db_id'], now)
        await query.answer("Возврат к меню")
    except Exception as e:
        logger.error(f"Ошибка в handle_back_callback: {e}")
        await query.answer("⚠️ Ошибка возврата", show_alert=True)



# === common.py ===

from telegram import Update, ReplyKeyboardMarkup
from telegram.ext import ContextTypes, ConversationHandler
import logging
from db import db
from keyboards import create_main_menu_keyboard
from .states import MAIN_MENU, FULL_NAME

logger = logging.getLogger(__name__)

async def show_main_menu(update: Update, user_id: int):
    """Общая функция для показа главного меню"""
    try:
        db.cursor.execute("SELECT is_verified FROM users WHERE telegram_id = ?", (user_id,))
        result = db.cursor.fetchone()

        if not result or not result[0]:
            # Пользователь не зарегистрирован
            reply_markup = create_unverified_user_keyboard()
        else:
            # Пользователь зарегистрирован
            reply_markup = create_main_menu_keyboard(user_id)

        if isinstance(update, Update) and update.message:
            await update.message.reply_text("Главное меню:", reply_markup=reply_markup)
        return MAIN_MENU

    except Exception as e:
        logger.error(f"Ошибка в show_main_menu: {e}", exc_info=True)
        if isinstance(update, Update) and update.message:
            await update.message.reply_text(
                "⚠️ Произошла ошибка. Попробуйте снова.",
                reply_markup=ReplyKeyboardRemove()
            )
        return ConversationHandler.END



# === menu_handlers.py ===

import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardMarkup, KeyboardButton
from telegram.ext import ContextTypes
from datetime import datetime, timedelta, date
from config import CONFIG, LOCATIONS, TIMEZONE, MENU, ADMIN_IDS
from db import db
from utils import (
    is_employee,
    get_menu_for_day,
    format_menu,
    check_registration,
    handle_unregistered,
    can_modify_order,
    is_order_time_expired,
    is_order_cancelled
)
from .states import MAIN_MENU, ORDER_ACTION, SELECT_MONTH_RANGE_STATS
from .common import show_main_menu
from keyboards import create_main_menu_keyboard, create_admin_keyboard

logger = logging.getLogger(__name__)

async def show_today_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await check_registration(update, context):
        return await handle_unregistered(update, context)
    
    user_id = update.effective_user.id
    now = datetime.now(TIMEZONE)
    days_ru = ["Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", "Воскресенье"]
    day_name = days_ru[now.weekday()]
    menu = MENU.get(day_name)
    
    if not menu:
        await update.message.reply_text(f"⏳ Сегодня ({day_name}) выходной! Меню не предусмотрено.")
        return await show_main_menu(update, user_id)
    
    message = format_menu(menu, day_name)
    
    # Проверяем есть ли активный заказ
    db.cursor.execute(
        "SELECT quantity FROM orders WHERE user_id = "
        "(SELECT id FROM users WHERE telegram_id = ?) AND target_date = ? AND is_cancelled = FALSE",
        (user_id, now.date().isoformat())
    )
    has_active_order = db.cursor.fetchone() is not None
    
    can_modify = can_modify_order(now.date())
    
    if has_active_order:
        if can_modify:
            keyboard = [
                [InlineKeyboardButton("✏️ Изменить количество", callback_data="change_0")],
                [InlineKeyboardButton("❌ Отменить заказ", callback_data="cancel_0")]
            ]
        else:
            keyboard = [
                [InlineKeyboardButton("ℹ️ Заказ оформлен (изменение невозможно)", callback_data="noop")]
            ]
    else:
        if can_modify:
            keyboard = [
                [InlineKeyboardButton("✅ Заказать", callback_data="order_0")]
            ]
        else:
            keyboard = [
                [InlineKeyboardButton("⏳ Прием заказов завершен", callback_data="info")]
            ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text(message, reply_markup=reply_markup)
    return await show_main_menu(update, user_id)

async def show_week_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        user = update.effective_user
        now = datetime.now(TIMEZONE)
        today = now.date()
        days_ru = ["Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", "Воскресенье"]
        
        sent_days = 0
        
        for day_offset in range(7):
            day_date = today + timedelta(days=day_offset)
            day_name = days_ru[day_date.weekday()]
            date_str = day_date.strftime("%d.%m")
            
            # Проверяем праздники и выходные
            holiday_name = CONFIG['holidays'].get(day_date.strftime("%Y-%m-%d"))
            if holiday_name or day_date.weekday() >= 5:
                status = holiday_name if holiday_name else "Выходной"
                await update.message.reply_text(
                    f"📅 {day_name} ({date_str}) — {status}! Меню не предусмотрено."
                )
                continue
            
            menu = MENU.get(day_name)
            if not menu:
                logger.warning(f"Меню для {day_name} не найдено")
                continue
            
            menu_text = f"🍽 Меню на {day_name} ({date_str}):\n"
            menu_text += f"1. 🍲 Первое: {menu['first']}\n"
            menu_text += f"2. 🍛 Основное блюдо: {menu['main']}\n"
            menu_text += f"3. 🥗 Салат: {menu['salad']}"
            
            # Проверка заказа пользователя (используем target_date вместо target_date)
            db.cursor.execute("""
                SELECT quantity FROM orders 
                WHERE user_id = (SELECT id FROM users WHERE telegram_id = ?)
                AND target_date = ?
                AND is_cancelled = FALSE
            """, (user.id, day_date.isoformat()))
            order = db.cursor.fetchone()
            
            keyboard = []
            if order:
                menu_text += f"\n✅ Заказ: {order[0]} порции"
                if can_modify_order(day_date):
                    keyboard.append([InlineKeyboardButton("✏️ Изменить", callback_data=f"change_{day_offset}")])
            elif can_modify_order(day_date):
                keyboard.append([InlineKeyboardButton("✅ Заказать", callback_data=f"order_{day_offset}")])
            
            await update.message.reply_text(
                menu_text,
                reply_markup=InlineKeyboardMarkup(keyboard) if keyboard else None,
                parse_mode="Markdown"
            )
            sent_days += 1
        
        if sent_days == 0:
            await update.message.reply_text("ℹ️ На эту неделю меню не загружено")
            
    except Exception as e:
        logger.error(f"Ошибка в show_week_menu: {e}", exc_info=True)
        from keyboards import create_main_menu_keyboard  # Добавляем импорт
        await update.message.reply_text(
            "⚠️ Ошибка при загрузке меню. Попробуйте позже.",
            reply_markup=create_main_menu_keyboard(user.id)
        )
async def show_day_menu(update: Update, context: ContextTypes.DEFAULT_TYPE, day_offset=0):
    """Показывает меню на указанный день с возможностью заказа"""
    try:
        user = update.effective_user
        now = datetime.now(TIMEZONE)
        days_ru = ["Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", "Воскресенье"]
        target_date = now.date() + timedelta(days=day_offset)
        day_name = days_ru[target_date.weekday()]
        is_tomorrow = day_offset == 1
        is_today = day_offset == 0
        menu = MENU.get(day_name)

        # Если выходной
        if not menu:
            await update.message.reply_text(f"⏳ На {day_name} ({target_date.strftime('%d.%m')}) выходной!")
            return

        message = format_menu(menu, day_name, is_tomorrow=is_tomorrow)

        # Получаем ID пользователя из БД
        db.cursor.execute("SELECT id FROM users WHERE telegram_id = ?", (user.id,))
        user_record = db.cursor.fetchone()
        if not user_record:
            await update.message.reply_text("❌ Пользователь не найден")
            return
        user_db_id = user_record[0]

        # Получаем текущий заказ
        db.cursor.execute("""
            SELECT quantity 
            FROM orders 
            WHERE user_id = ?
              AND target_date = ?
              AND is_cancelled = FALSE
        """, (user_db_id, target_date.isoformat()))
        order = db.cursor.fetchone()

        # Добавляем информацию о заказе
        keyboard = []

        if order:
            qty = order[0]
            message += f"\n\n✅ {'Предзаказ' if day_offset > 0 else 'Заказ'}: {qty} порции"

            can_modify = can_modify_order(target_date)
            if can_modify:
                keyboard.append([InlineKeyboardButton("✏️ Изменить количество", callback_data=f"change_{day_offset}")])
            keyboard.append([
                InlineKeyboardButton("❌ Отменить заказ", callback_data=f"cancel_{day_offset}")
            ])
        else:
            can_modify = can_modify_order(target_date)
            if can_modify:
                keyboard.append([InlineKeyboardButton("✅ Заказать", callback_data=f"order_{day_offset}")])
            else:
                keyboard.append([InlineKeyboardButton("⏳ Приём заказов завершён", callback_data="noop")])

        await update.message.reply_text(
            message,
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode="Markdown"
        )

    except Exception as e:
        logger.error(f"Ошибка в show_day_menu: {e}")
        await update.message.reply_text("⚠️ Ошибка загрузки меню")

# --- Просмотр заказов ---
async def view_orders(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Показывает только будущие и сегодняшние активные (не отменённые) заказы"""
    try:
        # Определяем, откуда вызвана функция
        if hasattr(update, 'message'):
            user = update.effective_user
            message = update.message
        else:
            user = update.callback_query.from_user
            message = update.callback_query.message

        user_id = user.id
        now = datetime.now(TIMEZONE)
        today_str = now.date().isoformat()

        # Получаем только будущие и сегодняшние заказы
        db.cursor.execute("""
            SELECT o.target_date, o.quantity, o.is_preliminary
            FROM orders o
            JOIN users u ON o.user_id = u.id
            WHERE u.telegram_id = ?
            AND o.is_cancelled = FALSE
            AND o.target_date >= ?
            ORDER BY o.target_date
        """, (user_id, today_str))

        active_orders = db.cursor.fetchall()

        if not active_orders:
            await message.reply_text("ℹ️ У вас нет активных заказов.")
            return await show_main_menu(message, user_id)

        # Формируем текст ответа
        response = "📦 Ваши активные заказы:\n"
        keyboard = []

        days_ru = ["Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", "Воскресенье"]

        for order in active_orders:
            target_date = datetime.strptime(order[0], "%Y-%m-%d").date()
            day_name = days_ru[target_date.weekday()]
            date_str = target_date.strftime('%d.%m')
            qty = order[1]

            status = " (предварительный)" if order[2] else ""
            response += f"📅 {day_name} ({date_str}) - {qty} порций{status}\n"
            keyboard.append([
                InlineKeyboardButton(
                    f"✕ Отменить {date_str}",
                    callback_data=f"cancel_{target_date.strftime('%Y-%m-%d')}"
                )
            ])

        keyboard.append([
            InlineKeyboardButton("✔ В главное меню", callback_data="back_to_menu")
        ])

        await message.reply_text(
            response,
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode="Markdown"
        )

    except Exception as e:
        logger.error(f"Ошибка в view_orders: {e}")
        await message.reply_text("⚠️ Ошибка загрузки заказов")
        return await show_main_menu(message, user_id)

async def order_action(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    Обработчик действий с заказами:
    - Отмена заказа (cancel_...)
    - Изменение количества порций (change_...)
    - Подтверждение заказа (confirm_...)
    """
    try:
        query = update.callback_query
        await query.answer()  # Подтверждаем нажатие кнопки

        logger.info(f"Получен callback: {query.data} от пользователя {query.from_user.id}")

        if query.data.startswith("cancel_"):
            # Извлекаем дату из callback_data
            try:
                _, date_part = query.data.split("_", 1)

                # Определяем дату
                now = datetime.now(TIMEZONE)
                if '-' in date_part:
                    target_date = datetime.strptime(date_part, "%Y-%m-%d").date()
                elif date_part.isdigit():
                    day_offset = int(date_part)
                    target_date = (now + timedelta(days=day_offset)).date()
                else:
                    raise ValueError(f"Неверный формат даты: {date_part}")

                # Проверяем возможность отмены
                if not can_modify_order(target_date):
                    await query.answer("ℹ️ Отмена невозможна после 9:30", show_alert=True)
                    return

                # Получаем ID пользователя из БД
                db.cursor.execute("SELECT id FROM users WHERE telegram_id = ?", (query.from_user.id,))
                user_record = db.cursor.fetchone()
                if not user_record:
                    await query.answer("❌ Пользователь не найден", show_alert=True)
                    return

                user_db_id = user_record[0]

                # Отменяем заказ в БД
                with db.conn:
                    db.cursor.execute("""
                        UPDATE orders 
                        SET is_cancelled = TRUE,
                            order_time = ?
                        WHERE user_id = ?
                          AND target_date = ?
                          AND is_cancelled = FALSE
                    """, (now.strftime("%H:%M:%S"), user_db_id, target_date.isoformat()))

                    if db.cursor.rowcount == 0:
                        await query.answer("❌ Заказ не найден", show_alert=True)
                        return

                # Обновляем интерфейс
                days_ru = ["Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", "Воскресенье"]
                if "Меню на" in query.message.text:
                    # Отмена из меню дня
                    day_name = days_ru[target_date.weekday()]
                    menu = MENU.get(day_name)
                    await query.edit_message_text(
                        text=f"~~{format_menu(menu, day_name)}~~\n❌ Заказ отменён",
                        reply_markup=InlineKeyboardMarkup([
                            [InlineKeyboardButton("✅ Заказать", callback_data=f"order_{target_date.isoformat()}")]
                        ]),
                        parse_mode="Markdown"
                    )
                else:
                    # Отмена из списка заказов
                    await refresh_orders_view(query, context, query.from_user.id, now, days_ru)

                await query.answer("✅ Заказ отменён")

            except Exception as e:
                logger.error(f"Ошибка при отмене заказа: {e}")
                await query.answer("⚠️ Ошибка отмены", show_alert=True)

        elif query.data.startswith("change_"):
            # Логика изменения количества порций (заглушка)
            await query.answer("🔄 Изменение количества порций временно недоступно")
            return

        elif query.data.startswith("confirm_"):
            # Логика подтверждения заказа (заглушка)
            await query.answer("✅ Заказ подтверждён")
            return

        else:
            # Неизвестное действие
            logger.warning(f"Неизвестный callback: {query.data}")
            await query.answer("⚠️ Неизвестное действие", show_alert=True)

    except Exception as e:
        logger.error(f"Критическая ошибка в order_action: {e}", exc_info=True)
        await query.answer("⚠️ Серверная ошибка", show_alert=True)

async def monthly_stats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Показывает меню выбора месяца для статистики."""
    try:
        user = update.effective_user
        reply_markup = ReplyKeyboardMarkup(
            [["Текущий месяц", "Прошлый месяц"], ["Вернуться в главное меню"]],
            resize_keyboard=True,
            one_time_keyboard=True
        )
        await update.message.reply_text(
            "📅 Выберите месяц для статистики:",
            reply_markup=reply_markup
        )
        return SELECT_MONTH_RANGE_STATS
    except Exception as e:
        logger.error(f"Ошибка при запуске monthly_stats: {e}")
        await update.message.reply_text("❌ Произошла ошибка. Попробуйте позже.")
        return await show_main_menu(update, user.id)


async def monthly_stats_selected(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка выбора месяца и вывод статистики."""
    try:
        user = update.effective_user
        text = update.message.text.strip()

        # Проверяем, хочет ли вернуться в меню
        if text == "Вернуться в главное меню":
            return await show_main_menu(update, user.id)

        # Получаем текущую дату
        now = datetime.now(TIMEZONE)
        current_year = now.year
        current_month = now.month

        if text == "Текущий месяц":
            start_date = now.replace(day=1).date()
            month_name = now.strftime("%B %Y")
        elif text == "Прошлый месяц":
            # Вычисляем последний день прошлого месяца
            first_day_current_month = now.replace(day=1)
            last_day_prev_month = first_day_current_month - timedelta(days=1)
            start_date = last_day_prev_month.replace(day=1)
            month_name = last_day_prev_month.strftime("%B %Y")
        else:
            await update.message.reply_text("❌ Неизвестный период. Пожалуйста, выберите из предложенных вариантов.")
            return SELECT_MONTH_RANGE_STATS

        # Получаем ID пользователя из базы данных
        db.cursor.execute("SELECT id FROM users WHERE telegram_id = ?", (user.id,))
        user_record = db.cursor.fetchone()
        if not user_record:
            await update.message.reply_text("❌ Пользователь не найден в системе.")
            return await show_main_menu(update, user.id)

        user_db_id = user_record[0]

        # Считаем количество порций за выбранный месяц (только неотмененные заказы)
        db.cursor.execute("""
            SELECT SUM(quantity)
            FROM orders
            WHERE user_id = ?
              AND target_date >= ?
              AND target_date <= date(?, 'start of month', '+1 month', '-1 day')
              AND is_cancelled = FALSE
        """, (user_db_id, start_date.isoformat(), start_date.isoformat()))

        result = db.cursor.fetchone()
        total_orders = result[0] or 0

        # Формируем ответ
        if total_orders == 0:
            message = f"📉 У вас пока нет заказов за {month_name}."
        else:
            message = (
                f"📊 Ваша статистика за {month_name}:\n"
                f"• Всего заказано порций: {total_orders}"
            )

        await update.message.reply_text(message)

    except Exception as e:
        logger.error(f"Ошибка при обработке выбора месяца в статистике: {e}", exc_info=True)
        await update.message.reply_text("❌ Произошла ошибка при получении статистики.")

    finally:
        return await show_main_menu(update, user.id)
    
async def handle_order_confirmation(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        text = update.message.text
        user = update.effective_user
        
        if text == "Да":
            now = datetime.now(TIMEZONE)
            target_date = now + timedelta(days=1)
            if now.weekday() == 4:  # Пятница -> понедельник
                target_date += timedelta(days=2)
            
            db.cursor.execute(
                "INSERT INTO orders (user_id, target_date, order_time, quantity, is_preliminary) "
                "SELECT id, ?, ?, 1, TRUE FROM users WHERE telegram_id = ?",
                (target_date.date().isoformat(), now.strftime("%H:%M:%S"), user.id)
            )
            db.conn.commit()
            await update.message.reply_text(f"✅ Предзаказ на {target_date.strftime('%d.%m')} оформлен!")
        else:
            await update.message.reply_text("❌ Заказ отменен.")
        
        return await show_main_menu(update, user.id)
    except Exception as e:
        logger.error(f"Ошибка в handle_order_confirmation: {e}")
        await update.message.reply_text("⚠️ Произошла ошибка. Попробуйте снова.")
        return await show_main_menu(update, user.id)



# === message_handlers.py ===

import logging
from telegram import Update, ReplyKeyboardMarkup, ReplyKeyboardRemove
from telegram.ext import ContextTypes, ConversationHandler, MessageHandler, filters, CommandHandler
from db import db
from config import CONFIG
from keyboards import create_main_menu_keyboard, create_admin_keyboard
import asyncio
from .states import (
    AWAIT_USER_SELECTION,
    AWAIT_MESSAGE_TEXT
)

logger = logging.getLogger(__name__)

async def start_user_to_admin_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Начало диалога пользователя с админом"""
    user = update.effective_user
    
    # Проверяем регистрацию пользователя
    db.cursor.execute(
        "SELECT full_name FROM users WHERE telegram_id = ? AND is_verified = TRUE",
        (user.id,)
    )
    user_data = db.cursor.fetchone()
    
    if not user_data:
        await update.message.reply_text(
            "❌ Вы не завершили регистрацию. Пожалуйста, используйте /start",
            reply_markup=ReplyKeyboardRemove()
        )
        return ConversationHandler.END
    
    context.user_data['user_name'] = user_data[0]
    await update.message.reply_text(
        "✍️ Введите ваше сообщение администратору:",
        reply_markup=ReplyKeyboardMarkup([["❌ Отменить"]], resize_keyboard=True)
    )
    return AWAIT_MESSAGE_TEXT

async def handle_user_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка сообщения от пользователя админам"""
    try:
        user = update.effective_user
        message_text = update.message.text
        
        if message_text.strip().lower() == "отменить":
            await update.message.reply_text(
                "❌ Отправка отменена",
                reply_markup=create_main_menu_keyboard(user.id)
            )
            return ConversationHandler.END

        # Получаем полное имя пользователя из базы данных
        db.cursor.execute(
            "SELECT full_name FROM users WHERE telegram_id = ?",
            (user.id,)
        )
        user_data = db.cursor.fetchone()
        full_name = user_data[0] if user_data else "Неизвестный пользователь"

        # Сохраняем сообщение в БД
        db.cursor.execute(
            "INSERT INTO admin_messages (user_id, message_text) "
            "VALUES ((SELECT id FROM users WHERE telegram_id = ?), ?)",
            (user.id, message_text)
        )
        db.conn.commit()

        # Формируем сообщение для админов в новом формате
        admin_message = (
            "✉️ Сообщение от пользователя:\n"
            f"👤 Имя: {full_name}\n"
            f"👤 Телеграм: @{user.username if user.username else 'нет'}\n"
            f"🆔 ID: {user.id}\n"
            f"📝 Текст: {message_text}"
        )

        # Отправляем всем админам
        sent_count = 0
        for admin_id in CONFIG['admin_ids']:
            try:
                await context.bot.send_message(
                    chat_id=admin_id,
                    text=admin_message
                )
                sent_count += 1
            except Exception as e:
                logger.error(f"Ошибка отправки админу {admin_id}: {e}")

        await update.message.reply_text(
            f"✅ Сообщение отправлено {sent_count} администраторам",
            reply_markup=create_main_menu_keyboard(user.id)
        )
        
        return ConversationHandler.END

    except Exception as e:
        logger.error(f"Ошибка обработки сообщения: {e}")
        await update.message.reply_text(
            "❌ Произошла ошибка при отправке. Попробуйте позже.",
            reply_markup=create_main_menu_keyboard(update.effective_user.id)
        )
        return ConversationHandler.END

async def start_admin_to_user_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Админ начинает диалог с пользователем"""
    if update.effective_user.id not in CONFIG['admin_ids']:
        await update.message.reply_text("❌ У вас нет прав для этой операции")
        return ConversationHandler.END

    # Очищаем предыдущие данные
    context.user_data.pop('recipient_id', None)
    context.user_data.pop('recipient_name', None)
    
    await update.message.reply_text(
        "Введите ID пользователя, @username или ФИО:\n"
        "(ФИО должно точно совпадать с указанным при регистрации)\n\n"
        "Для отмены нажмите кнопку 'Отмена'",
        reply_markup=ReplyKeyboardMarkup([["❌ Отмена"]], resize_keyboard=True)
    )
    return AWAIT_USER_SELECTION

async def handle_user_selection(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка выбора пользователя админом"""
    user_input = update.message.text.strip()
    
    # Проверка на отмену
    if user_input.lower() in ["отмена", "❌ отмена"]:
        await update.message.reply_text(
            "❌ Отправка отменена",
            reply_markup=create_admin_keyboard()
        )
        return ConversationHandler.END

    try:
        # Поиск пользователя в БД
        query = """
            SELECT telegram_id, full_name 
            FROM users 
            WHERE is_verified = TRUE AND (
                telegram_id = ? OR 
                username = ? OR 
                full_name LIKE ?
            )
        """
        
        # Подготавливаем параметры для поиска
        if user_input.isdigit():  # По ID
            params = (int(user_input), None, None)
        elif user_input.startswith('@'):  # По username
            params = (None, user_input[1:], None)
        else:  # По ФИО
            params = (None, None, f"%{user_input}%")
        
        db.cursor.execute(query, params)
        recipients = db.cursor.fetchall()

        if not recipients:
            await update.message.reply_text(
                "❌ Пользователь не найден. Проверьте ввод или нажмите 'Отмена'",
                reply_markup=ReplyKeyboardMarkup([["❌ Отмена"]], resize_keyboard=True)
            )
            return AWAIT_USER_SELECTION

        # Если нашли несколько пользователей
        if len(recipients) > 1:
            keyboard = []
            for user_id, full_name in recipients[:10]:  # Ограничим 10 результатами
                keyboard.append([f"{full_name} (ID: {user_id})"])
            
            keyboard.append(["❌ Отмена"])
            
            await update.message.reply_text(
                "Найдено несколько пользователей. Выберите одного:",
                reply_markup=ReplyKeyboardMarkup(keyboard, resize_keyboard=True)
            )
            context.user_data['found_users'] = recipients
            return AWAIT_USER_SELECTION

        # Если нашли одного пользователя
        recipient = recipients[0]
        context.user_data['recipient_id'] = recipient[0]
        context.user_data['recipient_name'] = recipient[1]
        
        await update.message.reply_text(
            f"Выбран пользователь: {recipient[1]}\n"
            "Введите сообщение или нажмите 'Отмена':",
            reply_markup=ReplyKeyboardMarkup([["❌ Отмена"]], resize_keyboard=True)
        )
        return AWAIT_MESSAGE_TEXT

    except Exception as e:
        logger.error(f"Ошибка выбора пользователя: {e}")
        await update.message.reply_text(
            "❌ Ошибка при поиске пользователя. Попробуйте снова или нажмите 'Отмена'",
            reply_markup=ReplyKeyboardMarkup([["❌ Отмена"]], resize_keyboard=True)
        )
        return AWAIT_USER_SELECTION

async def handle_admin_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Отправка сообщения от админа пользователю"""
    try:
        text = update.message.text.strip()
        
        # Проверка на отмену
        if text.lower() in ["отмена", "❌ отмена"]:
            await update.message.reply_text(
                "❌ Отправка отменена",
                reply_markup=create_admin_keyboard()
            )
            return ConversationHandler.END

        recipient_id = context.user_data.get('recipient_id')
        recipient_name = context.user_data.get('recipient_name')

        if not recipient_id:
            await update.message.reply_text(
                "❌ Получатель не выбран",
                reply_markup=create_admin_keyboard()
            )
            return ConversationHandler.END

        # Форматируем сообщение
        message = (
            "✉️ Сообщение от администратора:\n"
            f"📝 Текст: {text}\n\n"
        )

        try:
            await context.bot.send_message(
                chat_id=recipient_id,
                text=message
            )
            
            # Сохраняем в БД
            db.cursor.execute(
                "INSERT INTO admin_messages (admin_id, user_id, message_text) "
                "VALUES (?, ?, ?)",
                (update.effective_user.id, recipient_id, text)
            )
            db.conn.commit()

            await update.message.reply_text(
                f"✅ Сообщение отправлено пользователю {recipient_name}",
                reply_markup=create_admin_keyboard()
            )
        except Exception as e:
            logger.error(f"Ошибка отправки пользователю {recipient_id}: {e}")
            await update.message.reply_text(
                f"❌ Не удалось отправить сообщение пользователю {recipient_name}",
                reply_markup=create_admin_keyboard()
            )

        return ConversationHandler.END

    except Exception as e:
        logger.error(f"Ошибка отправки сообщения админа: {e}")
        await update.message.reply_text(
            "❌ Произошла ошибка при отправке",
            reply_markup=create_admin_keyboard()
        )
        return ConversationHandler.END

def setup_message_handlers(application):
    """Настройка обработчиков сообщений"""
    # Диалог пользователя с админами
    user_conv = ConversationHandler(
        entry_points=[MessageHandler(
            filters.Regex("^Написать администратору$") & filters.TEXT,
            start_user_to_admin_message
        )],
        states={
            AWAIT_MESSAGE_TEXT: [MessageHandler(filters.TEXT, handle_user_message)]
        },
        fallbacks=[
            CommandHandler('cancel', lambda u, c: ConversationHandler.END),
            MessageHandler(filters.Regex("^❌ Отменить$"), lambda u, c: ConversationHandler.END)
        ],
        allow_reentry=True
    )

    # Диалог админа с пользователем
    admin_conv = ConversationHandler(
        entry_points=[MessageHandler(
            filters.Regex("^✉️ Написать пользователю$") & filters.TEXT,
            start_admin_to_user_message
        )],
        states={
            AWAIT_USER_SELECTION: [MessageHandler(filters.TEXT, handle_user_selection)],
            AWAIT_MESSAGE_TEXT: [MessageHandler(filters.TEXT, handle_admin_message)]
        },
        fallbacks=[
            CommandHandler('cancel', lambda u, c: ConversationHandler.END),
            MessageHandler(filters.Regex("^❌ Отменить$"), lambda u, c: ConversationHandler.END)
        ],
        allow_reentry=True
    )

    application.add_handler(user_conv)
    application.add_handler(admin_conv)

async def handle_broadcast_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка команды рассылки"""
    if update.effective_user.id not in CONFIG['admin_ids']:
        logger.warning(f"Попытка рассылки от неадмина: {update.effective_user.id}")
        await update.message.reply_text("❌ У вас нет прав для этой команды")
        return ConversationHandler.END
    
    logger.info(f"Начало рассылки админом {update.effective_user.id}")
    await update.message.reply_text(
        "Введите сообщение для рассылки:",
        reply_markup=ReplyKeyboardMarkup([["❌ Отмена"]], resize_keyboard=True)
    )
    return AWAIT_MESSAGE_TEXT

async def process_broadcast_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка текста рассылки"""
    text = update.message.text
    logger.info(f"Получен текст для рассылки: {text}")
    
    if text.lower() in ["отмена", "❌ отмена"]:
        logger.info("Рассылка отменена")
        await update.message.reply_text(
            "❌ Рассылка отменена",
            reply_markup=create_admin_keyboard()
        )
        return ConversationHandler.END
    
    try:
        db.cursor.execute("SELECT telegram_id, full_name FROM users WHERE is_verified = TRUE")
        users = db.cursor.fetchall()
        
        if not users:
            logger.warning("Нет верифицированных пользователей для рассылки")
            await update.message.reply_text("❌ Нет пользователей для рассылки")
            return ConversationHandler.END
        
        logger.info(f"Начало рассылки для {len(users)} пользователей")
        msg = await update.message.reply_text(f"⏳ Рассылка для {len(users)} пользователей...")
        
        success = 0
        failed = []
        
        for user_id, full_name in users:
            try:
                await context.bot.send_message(
                    chat_id=user_id,
                    text=f"📢 Сообщение от администратора:\n\n{text}"
                )
                success += 1
                await asyncio.sleep(0.1)
            except Exception as e:
                failed.append(f"{full_name} (ID: {user_id})")
                logger.error(f"Ошибка отправки {user_id}: {e}")
        
        try:
            await msg.delete()
        except Exception as e:
            logger.error(f"Ошибка удаления сообщения: {e}")
        
        report = f"✅ Успешно: {success}/{len(users)}"
        if failed:
            report += f"\n❌ Ошибки: {len(failed)}"
        
        logger.info(f"Результат рассылки: {report}")
        await update.message.reply_text(
            report,
            reply_markup=create_admin_keyboard()
        )
        
    except Exception as e:
        logger.error(f"Ошибка рассылки: {e}", exc_info=True)
        await update.message.reply_text("❌ Ошибка при рассылке")
    
    return ConversationHandler.END


# === registration_handlers.py ===

import sqlite3
import logging
from telegram import Update, KeyboardButton, ReplyKeyboardMarkup, ReplyKeyboardRemove
from telegram.ext import ContextTypes, ConversationHandler
from db import db
from config import CONFIG, LOCATIONS, ADMIN_IDS  # Добавлен импорт LOCATIONS
from utils import is_employee
from .states import PHONE, FULL_NAME, LOCATION, MAIN_MENU
from .base_handlers import show_main_menu
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)

async def get_phone(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        if not update.message.contact:
            keyboard = [[KeyboardButton("📱 Отправить номер телефона", request_contact=True)]]
            reply_markup = ReplyKeyboardMarkup(keyboard, resize_keyboard=True)
            await update.message.reply_text(
                "Пожалуйста, используйте кнопку для отправки номера телефона:",
                reply_markup=reply_markup
            )
            return PHONE

        phone = update.message.contact.phone_number
        if not phone:
            await update.message.reply_text("Не удалось получить номер телефона. Попробуйте снова.")
            return PHONE

        db.cursor.execute("SELECT 1 FROM users WHERE phone = ?", (phone,))
        if db.cursor.fetchone():
            await update.message.reply_text("Этот номер телефона уже зарегистрирован.")
            return ConversationHandler.END

        context.user_data['phone'] = phone
        await update.message.reply_text("Отлично! Теперь введите ваше имя и фамилию одной строкой:")
        return FULL_NAME
    except Exception as e:
        logger.error(f"Ошибка при обработке номера телефона: {e}")
        await update.message.reply_text("Произошла ошибка. Попробуйте снова.")
        return PHONE

async def get_full_name(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Получает и проверяет ФИО пользователя."""
    try:
        user_input = update.message.text.strip()
        logger.info(f"Получено имя: '{user_input}' от пользователя {update.effective_user.id}")

        # Обработка специальных команд
        if user_input == "Написать администратору":
            return await handle_admin_message(update, context)

        if user_input == "Попробовать снова":
            await update.message.reply_text("Введите ваше имя и фамилию:")
            return FULL_NAME

        # Проверяем формат имени
        name_parts = user_input.split()
        if len(name_parts) < 2:
            await update.message.reply_text(
                "❌ Пожалуйста, введите имя и фамилию полностью.\nПример: Иван Иванов"
            )
            return FULL_NAME

        full_name = ' '.join(name_parts)  # Нормализуем пробелы
        context.user_data['full_name'] = full_name

        # Проверяем, есть ли в списке сотрудников
        if not is_employee(full_name):
            context.user_data['unverified_name'] = full_name
            reply_markup = ReplyKeyboardMarkup(
                [["Попробовать снова"], ["Написать администратору"]],
                resize_keyboard=True
            )
            await update.message.reply_text(
                "❌ Вас нет в списке сотрудников. Вы можете:",
                reply_markup=reply_markup
            )
            return FULL_NAME

        # Проверяем, зарегистрирован ли уже
        db.cursor.execute(
            "SELECT 1 FROM users WHERE full_name = ? LIMIT 1",
            (full_name,)
        )
        if db.cursor.fetchone():
            await update.message.reply_text("⚠️ Данный сотрудник уже зарегистрирован.")
            return ConversationHandler.END

        # Переход к выбору локации
        keyboard = [[loc] for loc in LOCATIONS]
        reply_markup = ReplyKeyboardMarkup(
            keyboard,
            one_time_keyboard=True,
            resize_keyboard=True
        )
        await update.message.reply_text(
            "Выберите ваш объект:",
            reply_markup=reply_markup
        )
        return LOCATION

    except Exception as e:
        logger.error(f"Критическая ошибка в get_full_name: {e}", exc_info=True)
        await update.message.reply_text(
            "⚠️ Произошла системная ошибка. Попробуйте позже.",
            reply_markup=ReplyKeyboardRemove()
        )
        return ConversationHandler.END

async def get_location(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        user_id = update.effective_user.id
        
        location = update.message.text
        if location not in LOCATIONS:
            await update.message.reply_text("Пожалуйста, выберите объект из списка.")
            return LOCATION
            
        user = update.effective_user
        try:
            db.cursor.execute(
                "INSERT INTO users (telegram_id, full_name, phone, location, is_verified, username) "
                "VALUES (?, ?, ?, ?, TRUE, ?)",
                (user.id, context.user_data['full_name'], context.user_data['phone'], 
                 location, user.username or "")
            )
            db.conn.commit()
            logger.info(f"Пользователь {user.id} успешно зарегистрирован")
            return await show_main_menu(update, user_id)
        except sqlite3.IntegrityError as e:
            if "UNIQUE constraint failed" in str(e):
                await update.message.reply_text("❌ Этот пользователь уже зарегистрирован")
                return ConversationHandler.END
            raise e
    except Exception as e:
        logger.error(f"Ошибка в get_location: {e}")
        await update.message.reply_text("Произошла ошибка. Попробуйте снова.")
        return LOCATION



# === report_handlers.py ===

import logging
from datetime import datetime, timedelta
from telegram import Update, ReplyKeyboardMarkup, ReplyKeyboardRemove
from telegram.ext import ContextTypes
from .common import show_main_menu
from .states import SELECT_MONTH_RANGE
from .base_handlers import show_main_menu
from admin import export_orders_for_provider, export_accounting_report
from config import TIMEZONE, CONFIG
from keyboards import create_main_menu_keyboard

logger = logging.getLogger(__name__)

async def handle_admin_report(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text
    if text == "📊 Отчет за день":
        await export_accounting_report(update, context)  # Детализированный
    elif text == "📅 Отчет за месяц":
        # Показываем клавиатуру выбора месяца
        await update.message.reply_text(
            "Выберите период:",
            reply_markup=ReplyKeyboardMarkup([
                ["Текущий месяц", "Прошлый месяц"],
                ["Отмена"]
            ], resize_keyboard=True)
        )
        return SELECT_MONTH_RANGE

async def select_month_range(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        user = update.effective_user
        user_id = user.id
        text = update.message.text
        
        # Убираем дублирующуюся проверку в начале
        if text == "Вернуться в главное меню":
            return await show_main_menu(update, user_id)

        # Исправлено: используем user_id вместо user.id
        logger.info(f"User ID: {user_id}")
        logger.info(f"Admin IDs: {CONFIG['admin_ids']}")
        logger.info(f"Provider IDs: {CONFIG['provider_ids']}")
        logger.info(f"Accounting IDs: {CONFIG['accounting_ids']}")
        logger.info(f"Обработка периода: {text}, report_type: {context.user_data.get('report_type')}")

        # Определяем клавиатуру один раз
        reply_markup = ReplyKeyboardMarkup(
            [["Текущий месяц", "Прошлый месяц"], 
             ["Вернуться в главное меню"]],
            resize_keyboard=True
        )

        # Проверяем валидность ввода
        if text not in ["Текущий месяц", "Прошлый месяц"]:
            await update.message.reply_text(
                "Пожалуйста, выберите период:",
                reply_markup=reply_markup
            )
            return SELECT_MONTH_RANGE

        # Получаем тип отчета
        report_type = context.user_data.get('report_type')
        if not report_type:
            await update.message.reply_text(
                "Ошибка: тип отчета не определен",
                reply_markup=ReplyKeyboardRemove()
            )
            return await show_main_menu(update, user_id)

        logger.info(f"Обработка выбора периода: {text}")

        # Определяем даты
        now = datetime.now(TIMEZONE)
        if text == "Текущий месяц":
            start_date = now.replace(day=1).date()
            end_date = now.date()
        elif text == "Прошлый месяц":
            first_day = now.replace(day=1)
            last_day_prev_month = first_day - timedelta(days=1)
            start_date = last_day_prev_month.replace(day=1).date()
            end_date = last_day_prev_month.date()
        else:
            # Этот else технически недостижим из-за предыдущей проверки
            await update.message.reply_text("Неизвестный период")
            return await show_main_menu(update, user_id)

        logger.info(f"Формирование отчета {report_type} за {start_date} - {end_date}")

        # Формируем отчет
        try:
            if report_type == 'provider':
                await export_orders_for_provider(update, context, start_date, end_date)
            else:
                await export_accounting_report(update, context, start_date, end_date)
        except Exception as e:
            logger.error(f"Ошибка формирования отчета: {e}")
            await update.message.reply_text(
                "❌ Не удалось сформировать отчет",
                reply_markup=ReplyKeyboardMarkup(
                    create_main_menu_keyboard(user_id),  # Используем user_id
                    resize_keyboard=True
                )
            )
            return await show_main_menu(update, user_id)  # Добавлен return

        return await show_main_menu(update, user_id)

    except Exception as e:
        logger.error(f"Критическая ошибка в select_month_range: {e}", exc_info=True)
        await update.message.reply_text("⚠️ Произошла системная ошибка")
        return await show_main_menu(update, user_id)


# === states.py ===

# Состояния диалога (для ConversationHandler)
(
    PHONE, FULL_NAME, LOCATION, MAIN_MENU,
    ORDER_ACTION, ORDER_CONFIRMATION, SELECT_MONTH_RANGE,
    BROADCAST_MESSAGE, AWAIT_MESSAGE_TEXT, AWAIT_USER_SELECTION
) = range(10)

# Константы для состояний
SELECT_MONTH_RANGE_STATS = 'select_month_range_stats'
ORDER_ACTION = "ORDER_ACTION"
BROADCAST_MESSAGE = 'broadcast_message'


# === __init__.py ===

from datetime import datetime, timedelta
from telegram import Update
from config import CONFIG
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,  # Добавлен этот импорт
    CallbackQueryHandler,
    ConversationHandler,
    filters,
    ContextTypes
)

# Импорты локальных модулей
from .common import show_main_menu
from .message_handlers import (
    setup_message_handlers,
    start_user_to_admin_message,
    process_broadcast_message,
    handle_broadcast_command,
    handle_user_message,
    handle_user_selection,
    handle_admin_message
)
from .base_handlers import (
    start,
    error_handler,
    test_connection,
    main_menu,
    handle_text_message,
    handle_registered_user
)
from .registration_handlers import (
    get_phone,
    get_full_name,
    get_location
)
from .menu_handlers import (
    show_today_menu,
    show_week_menu,
    view_orders,
    monthly_stats,
    handle_order_confirmation,
    order_action,
    monthly_stats_selected
)
from .callback_handlers import (
    callback_handler,
    handle_order_callback,
    handle_change_callback,
    handle_cancel_callback
)
from .admin_handlers import (
    handle_admin_choice
)
from .report_handlers import select_month_range

# Состояния диалога
from .states import (
    PHONE,
    FULL_NAME,
    LOCATION,
    MAIN_MENU,
    ORDER_ACTION,
    ORDER_CONFIRMATION,
    SELECT_MONTH_RANGE,
    BROADCAST_MESSAGE,
    AWAIT_MESSAGE_TEXT,
    AWAIT_USER_SELECTION
)

# Константы для новых состояний
SELECT_MONTH_RANGE_STATS = 'select_month_range_stats'
AWAIT_USER_SELECTION = 'handle_user_selection'

def setup_handlers(application):
    # 1. Обработчик рассылки (добавляется ПЕРВЫМ)
    broadcast_handler = ConversationHandler(
        entry_points=[MessageHandler(
            filters.Regex("^📢 Сделать рассылку$") & 
            filters.User(user_id=CONFIG['admin_ids']),
            handle_broadcast_command
        )],
        states={
            AWAIT_MESSAGE_TEXT: [MessageHandler(
                filters.TEXT & ~filters.COMMAND,
                process_broadcast_message
            )]
        },
        fallbacks=[
            CommandHandler('cancel', lambda u, c: show_main_menu(u, u.effective_user.id)),
            MessageHandler(filters.Regex("^(❌ Отмена|Отмена)$"), 
                        lambda u, c: show_main_menu(u, u.effective_user.id))
        ],
        allow_reentry=True
    )
    application.add_handler(broadcast_handler)

    # 2. Основные обработчики сообщений
    from handlers.message_handlers import setup_message_handlers
    setup_message_handlers(application)
    
    # 3. Основной ConversationHandler
    conv_handler = ConversationHandler(
        entry_points=[
            CommandHandler('start', start),
            MessageHandler(filters.Regex("^Статистика за месяц$"), monthly_stats),
            MessageHandler(filters.Regex("^Админ-панель$"), handle_admin_choice),
            MessageHandler(filters.Regex("^Написать администратору$"), start_user_to_admin_message),
        ],
        states={
            SELECT_MONTH_RANGE_STATS: [
                MessageHandler(
                    filters.Regex("^(Текущий месяц|Прошлый месяц|Вернуться в главное меню)$"),
                    monthly_stats_selected
                )
            ],
            PHONE: [MessageHandler(filters.CONTACT, get_phone)],
            FULL_NAME: [MessageHandler(filters.TEXT & ~filters.COMMAND, get_full_name)],
            LOCATION: [MessageHandler(filters.TEXT & ~filters.COMMAND, get_location)],
            MAIN_MENU: [MessageHandler(filters.TEXT & ~filters.COMMAND, main_menu)],
            ORDER_ACTION: [CallbackQueryHandler(callback_handler)],
            ORDER_CONFIRMATION: [MessageHandler(filters.TEXT & ~filters.COMMAND, handle_order_confirmation)],
            SELECT_MONTH_RANGE: [
                MessageHandler(filters.Regex(r'^(Текущий месяц|Прошлый месяц)$'), select_month_range),
                MessageHandler(filters.Regex(r'^Вернуться в главное меню$'), show_main_menu)
            ]
        },
        fallbacks=[
            CommandHandler('cancel', lambda u, c: show_main_menu(u, u.effective_user.id)),
            MessageHandler(filters.Regex(r'^(❌ Отмена|Отмена|Вернуться в главное меню|🏠 Главное меню)$'), 
                         lambda u, c: show_main_menu(u, u.effective_user.id))
        ],
        per_chat=True,
        per_user=True,
        allow_reentry=True
    )

    application.add_handler(conv_handler)

    # 4. Обработчик для зарегистрированных пользователей
    application.add_handler(MessageHandler(
        filters.TEXT & ~filters.COMMAND & filters.Regex(
            r'^(Меню на сегодня|Меню на неделю|Просмотреть заказы|Статистика за месяц|'
            r'💰 Бухгалтерский отчет|📦 Отчет поставщика|'
            r'📊 Отчет за день|📅 Отчет за месяц|Обновить меню|Вернуться в главное меню)$'
        ),
        handle_registered_user
    ))

    # 5. CallbackQueryHandler
    application.add_handler(CallbackQueryHandler(callback_handler))

    # 6. Обработчик всех текстовых сообщений (кроме команд)
    application.add_handler(
        MessageHandler(
            filters.TEXT & ~filters.COMMAND,
            handle_text_message
        )
    )

    # 7. Обработчик ошибок
    application.add_error_handler(error_handler)



# === 2admin_handlers.py ===

import logging
from telegram import Update, ReplyKeyboardMarkup
from telegram.ext import ContextTypes, ConversationHandler, MessageHandler
from config import CONFIG, CONFIG_FILE, load_config
from keyboards import create_admin_keyboard, create_month_selection_keyboard
from admin import export_accounting_report
from .states import BROADCAST_MESSAGE, SELECT_MONTH_RANGE
from db import db
import asyncio
from filelock import FileLock
import openpyxl

logger = logging.getLogger(__name__)

async def handle_admin_choice(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка выбора в админ-меню"""
    text = update.message.text.strip().lower()
    user = update.effective_user

    # Проверка прав администратора
    if user.id not in CONFIG.get('admin_ids', []) and user.id not in CONFIG.get('accounting_ids', []):
        await update.message.reply_text("❌ У вас нет прав для выполнения этой команды.")
        return ConversationHandler.END  # Заменили ADMIN_MESSAGE на завершение диалога

    if text == "📢 Сделать рассылку":
        await update.message.reply_text(
            "Введите сообщение для рассылки:",
            reply_markup=ReplyKeyboardMarkup([["Отмена"]], resize_keyboard=True)
        )
        return BROADCAST_MESSAGE

    elif text == "отмена":
        await update.message.reply_text(
            "Действие отменено",
            reply_markup=create_admin_keyboard()
        )
        return ConversationHandler.END  # Заменили ADMIN_MESSAGE

    elif text in ["📊 отчет за день", "отчет за день"]:
        if user.id in CONFIG.get('admin_ids', []) or user.id in CONFIG.get('accounting_ids', []):
            await export_accounting_report(update, context)
        else:
            await update.message.reply_text("❌ У вас нет прав для просмотра отчетов")
        return ConversationHandler.END  # Заменили ADMIN_MESSAGE

    elif text in ["📅 отчет за месяц", "отчет за месяц"]:
        if user.id in CONFIG.get('admin_ids', []) or user.id in CONFIG.get('accounting_ids', []):
            await update.message.reply_text(
                "Выберите период:",
                reply_markup=create_month_selection_keyboard()
            )
            return SELECT_MONTH_RANGE
        else:
            await update.message.reply_text("❌ У вас нет прав для просмотра отчетов")
        return ConversationHandler.END  # Заменили ADMIN_MESSAGE

    # Неизвестная команда
    await update.message.reply_text(
        "Неизвестная команда. Пожалуйста, используйте кнопки меню.",
        reply_markup=create_admin_keyboard()
    )
    return ConversationHandler.END  # Заменили ADMIN_MESSAGE

async def handle_broadcast_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка команды рассылки"""
    user = update.effective_user
    if user.id not in CONFIG['admin_ids']:
        await update.message.reply_text("❌ У вас нет прав для этой команды")
        return
    
    await update.message.reply_text(
        "Введите сообщение для рассылки:",
        reply_markup=ReplyKeyboardMarkup([["❌ Отмена"]], resize_keyboard=True)
    )
    return "BROADCAST_MESSAGE"

async def process_broadcast_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка текста рассылки"""
    text = update.message.text
    
    if text.lower() in ["отменить рассылку", "❌ отменить рассылку"]:
        await update.message.reply_text(
            "❌ Рассылка отменена",
            reply_markup=create_admin_keyboard()
        )
        return ConversationHandler.END
    
    try:
        # Получаем всех верифицированных пользователей
        db.cursor.execute("SELECT telegram_id, full_name FROM users WHERE is_verified = TRUE")
        users = db.cursor.fetchall()
        
        if not users:
            await update.message.reply_text(
                "❌ Нет пользователей для рассылки",
                reply_markup=create_admin_keyboard()
            )
            return ConversationHandler.END
        
        # Отправляем уведомление о начале рассылки
        await update.message.reply_text(f"⏳ Начинаю рассылку для {len(users)} пользователей...")
        
        success = 0
        failed = []
        
        for user_id, full_name in users:
            try:
                await context.bot.send_message(
                    chat_id=user_id,
                    text=f"📢 Сообщение от администратора:\n\n{text}"
                )
                success += 1
                await asyncio.sleep(0.1)  # Задержка между сообщениями
            except Exception as e:
                failed.append(f"{full_name} (ID: {user_id})")
                logger.error(f"Ошибка отправки {user_id}: {e}")
        
        # Формируем отчет
        report = (
            f"✅ Рассылка завершена:\n"
            f"• Всего получателей: {len(users)}\n"
            f"• Успешно: {success}\n"
            f"• Не удалось: {len(failed)}"
        )
        
        if failed:
            report += "\n\nНе удалось отправить:\n" + "\n".join(failed[:10])  # Показываем первые 10 ошибок
        
        await update.message.reply_text(
            report,
            reply_markup=create_admin_keyboard()
        )
        
    except Exception as e:
        logger.error(f"Ошибка рассылки: {e}")
        await update.message.reply_text(
            "❌ Произошла ошибка при рассылке",
            reply_markup=create_admin_keyboard()
        )
    
    return ConversationHandler.END
    

async def add_user_id(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    Добавляет ID пользователя в конфигурационный файл
    Формат команды: /add_user <admin/provider/accounting> <user_id>
    """
    user = update.effective_user
    
    # Проверка прав
    if user.id not in CONFIG['admin_ids']:
        await update.message.reply_text("❌ Только администраторы могут добавлять пользователей")
        return

    try:
        # Парсим аргументы
        args = context.args
        if len(args) != 2:
            raise ValueError(
                "Неверный формат команды.\n"
                "Используйте: /add_user <тип> <id>\n"
                "Типы: admin, provider, accounting"
            )

        user_type = args[0].lower()
        new_id = int(args[1])  # Проверка что ID - число

        # Определяем столбец в Excel
        column_map = {
            'admin': 'B',
            'provider': 'C',
            'accounting': 'D'
        }

        if user_type not in column_map:
            raise ValueError("Неверный тип пользователя. Допустимо: admin, provider, accounting")

        column = column_map[user_type]

        # Блокировка файла для безопасной записи
        with FileLock(CONFIG_FILE + ".lock"):
            # Открываем Excel-файл
            wb = openpyxl.load_workbook(CONFIG_FILE)
            ws = wb.active
            
            # Ищем первую пустую ячейку в столбце
            row = 2
            while ws[f'{column}{row}'].value is not None:
                row += 1

            # Записываем новый ID
            ws[f'{column}{row}'] = new_id
            wb.save(CONFIG_FILE)

        # Обновляем конфиг в памяти
        global CONFIG
        CONFIG = load_config()
        
        # Обновляем соответствующий список ID
        if user_type == 'admin':
            CONFIG['admin_ids'].append(new_id)
        elif user_type == 'provider':
            CONFIG['provider_ids'].append(new_id)
        elif user_type == 'accounting':
            CONFIG['accounting_ids'].append(new_id)

        await update.message.reply_text(
            f"✅ Пользователь {new_id} успешно добавлен как {user_type}!\n"
            f"Текущие {user_type} IDs: {CONFIG[user_type + '_ids']}"
        )

    except ValueError as ve:
        await update.message.reply_text(f"❌ Ошибка ввода: {str(ve)}")
    except Exception as e:
        logger.error(f"Ошибка добавления пользователя: {e}", exc_info=True)
        await update.message.reply_text("❌ Произошла ошибка при добавлении пользователя")
        
__all__ = [
    'handle_admin_choice',
    'handle_broadcast_command',
    'process_broadcast_message',
    'add_user_id'  # Добавляем новую функцию в экспорт
]



# === admin_handlers.py ===

import logging
from telegram import Update, ReplyKeyboardMarkup
from telegram.ext import ContextTypes, ConversationHandler, MessageHandler
from config import CONFIG
from keyboards import create_admin_keyboard, create_month_selection_keyboard
from admin import export_accounting_report
from .states import BROADCAST_MESSAGE, SELECT_MONTH_RANGE
from db import db
import asyncio

logger = logging.getLogger(__name__)

async def handle_admin_choice(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка выбора в админ-меню"""
    text = update.message.text.strip().lower()
    user = update.effective_user

    # Проверка прав администратора
    if user.id not in CONFIG.get('admin_ids', []) and user.id not in CONFIG.get('accounting_ids', []):
        await update.message.reply_text("❌ У вас нет прав для выполнения этой команды.")
        return ConversationHandler.END  # Заменили ADMIN_MESSAGE на завершение диалога

    if text == "📢 Сделать рассылку":
        await update.message.reply_text(
            "Введите сообщение для рассылки:",
            reply_markup=ReplyKeyboardMarkup([["Отмена"]], resize_keyboard=True)
        )
        return BROADCAST_MESSAGE

    elif text == "отмена":
        await update.message.reply_text(
            "Действие отменено",
            reply_markup=create_admin_keyboard()
        )
        return ConversationHandler.END  # Заменили ADMIN_MESSAGE

    elif text in ["📊 отчет за день", "отчет за день"]:
        if user.id in CONFIG.get('admin_ids', []) or user.id in CONFIG.get('accounting_ids', []):
            await export_accounting_report(update, context)
        else:
            await update.message.reply_text("❌ У вас нет прав для просмотра отчетов")
        return ConversationHandler.END  # Заменили ADMIN_MESSAGE

    elif text in ["📅 отчет за месяц", "отчет за месяц"]:
        if user.id in CONFIG.get('admin_ids', []) or user.id in CONFIG.get('accounting_ids', []):
            await update.message.reply_text(
                "Выберите период:",
                reply_markup=create_month_selection_keyboard()
            )
            return SELECT_MONTH_RANGE
        else:
            await update.message.reply_text("❌ У вас нет прав для просмотра отчетов")
        return ConversationHandler.END  # Заменили ADMIN_MESSAGE

    # Неизвестная команда
    await update.message.reply_text(
        "Неизвестная команда. Пожалуйста, используйте кнопки меню.",
        reply_markup=create_admin_keyboard()
    )
    return ConversationHandler.END  # Заменили ADMIN_MESSAGE


# === base_handlers.py ===

import logging
import asyncio
from telegram import Update, ReplyKeyboardRemove, KeyboardButton, ReplyKeyboardMarkup
from telegram.ext import ConversationHandler, ContextTypes
from .states import PHONE, MAIN_MENU, SELECT_MONTH_RANGE, FULL_NAME
from db import db
from config import CONFIG, ADMIN_IDS
from keyboards import create_main_menu_keyboard
from utils import check_registration, handle_unregistered
from .menu_handlers import show_today_menu, show_week_menu, view_orders, monthly_stats
from datetime import datetime, timedelta
from .common import show_main_menu
from .report_handlers import select_month_range
from admin import export_accounting_report
from .message_handlers import process_broadcast_message

logger = logging.getLogger(__name__)

__all__ = ['start', 'error_handler', 'test_connection', 'main_menu', 'handle_text_message']

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Обновляю меню...", reply_markup=ReplyKeyboardRemove())
    user = update.effective_user
    context.user_data['restored'] = True
    
    try:
        context.user_data['is_initialized'] = True
        db.cursor.execute("SELECT is_verified FROM users WHERE telegram_id = ?", (user.id,))
        user_data = db.cursor.fetchone()

        if not user_data:
            keyboard = [[KeyboardButton("📱 Отправить номер телефона", request_contact=True)]]
            reply_markup = ReplyKeyboardMarkup(keyboard, resize_keyboard=True, one_time_keyboard=True)
            await update.message.reply_text(
                "Для регистрации нам нужен ваш номер телефона:",
                reply_markup=reply_markup
            )
            return PHONE
        elif not user_data[0]:
            db.cursor.execute("DELETE FROM users WHERE telegram_id = ?", (user.id,))
            db.conn.commit()
            keyboard = [[KeyboardButton("📱 Отправить номер телефона", request_contact=True)]]
            reply_markup = ReplyKeyboardMarkup(keyboard, resize_keyboard=True, one_time_keyboard=True)
            await update.message.reply_text(
                "Пожалуйста, завершите регистрацию:",
                reply_markup=reply_markup
            )
            return PHONE
        else:
            return await show_main_menu(update, user.id)
    except Exception as e:
        logger.error(f"Ошибка в start: {e}")
        await update.message.reply_text("Произошла ошибка. Попробуйте снова.")
        return await show_main_menu(update, user.id)

async def error_handler(update: object, context: ContextTypes.DEFAULT_TYPE) -> None:
    error = str(context.error)
    logger.error(f"Ошибка: {error}", exc_info=context.error)
    
    for admin_id in ADMIN_IDS:
        try:
            await context.bot.send_message(
                chat_id=admin_id,
                text=f"⚠️ Ошибка в боте:\n\n{error}\n\n"
                     f"Update: {update if update else 'Нет данных'}"
            )
        except Exception as e:
            logger.error(f"Не удалось отправить сообщение админу {admin_id}: {e}")
    
    if update and isinstance(update, Update) and update.effective_message:
        try:
            await update.effective_message.reply_text("⚠️ Произошла ошибка. Пожалуйста, попробуйте позже.")
        except Exception as e:
            logger.error(f"Не удалось отправить сообщение пользователю: {e}")

async def test_connection(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        msg = await update.message.reply_text("🔄 Тестируем соединение...")
        bot_info = await context.bot.get_me()
        test_msg = await update.message.reply_text(
            f"✅ Соединение работает\n"
            f"🤖 Бот: @{bot_info.username}\n"
            f"🆔 ID: {bot_info.id}\n"
            f"📝 Имя: {bot_info.first_name}"
        )
        await asyncio.sleep(5)
        await msg.delete()
        await test_msg.delete()
    except Exception as e:
        logger.error(f"Ошибка соединения: {e}")
        await update.message.reply_text(
            f"❌ Ошибка соединения:\n{str(e)}\n"
            "Проверьте:\n"
            "1. Интернет-соединение\n"
            "2. Токен бота\n"
            "3. Ограничения сервера"
        )

async def handle_text_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    text = update.message.text
    logger.info(f"Получено сообщение: '{text}' от {user.id}")
    
    try:
        # 1. Обработка сообщения от незарегистрированного пользователя
        if text == "Написать администратору":
            unverified_name = context.user_data.get('unverified_name', 'не указано')
            message = (
                f"⚠️ Незарегистрированный пользователь сообщает:\n"
                f"👤 Имя: {unverified_name}\n"
                f"🆔 ID: {user.id}\n"
                f"📱 Username: @{user.username if user.username else 'нет'}\n"
                f"✉️ Сообщение: Пользователь не найден в списке сотрудников"
            )
            
            for admin_id in ADMIN_IDS:
                try:
                    await context.bot.send_message(chat_id=admin_id, text=message)
                except Exception as e:
                    logger.error(f"Ошибка отправки админу {admin_id}: {e}")
            
            await update.message.reply_text(
                "✅ Ваше сообщение отправлено администратору. Ожидайте ответа.",
                reply_markup=ReplyKeyboardMarkup([["Попробовать снова"]], resize_keyboard=True)
            )
            return FULL_NAME

        # 2. Проверка регистрации
        if not await check_registration(update, context):
            return await handle_unregistered(update, context)

        # 3. Обработка команд отчетов
        if text in ["💰 Бухгалтерский отчет", "📦 Отчет поставщика"]:
            context.user_data['report_type'] = 'accounting' if text.startswith('💰') else 'provider'
            await update.message.reply_text(
                "Выберите период:",
                reply_markup=ReplyKeyboardMarkup([
                    ["Текущий месяц", "Прошлый месяц"],
                    ["Вернуться в главное меню"]
                ], resize_keyboard=True)
            )
            return SELECT_MONTH_RANGE
        
        if text in ["Текущий месяц", "Прошлый месяц"] and context.user_data.get('report_type'):
            return await select_month_range(update, context)
        
        # 4. Все остальные команды
        return await main_menu(update, context)
        
    except Exception as e:
        logger.error(f"Ошибка в handle_text_message: {e}", exc_info=True)
        await update.message.reply_text(
            "⚠️ Произошла ошибка. Попробуйте снова или используйте /start",
            reply_markup=ReplyKeyboardRemove()
        )
        return await show_main_menu(update, user.id)

async def main_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    logger.info(f"Получена команда: '{update.message.text}' от пользователя {update.effective_user.id}")
    
    try:
        user = update.effective_user
        text = update.message.text
        
        # Проверка регистрации
        if not await check_registration(update, context):
            return await handle_unregistered(update, context)

        from keyboards import create_main_menu_keyboard  # Добавляем импорт
        
        # Основные команды меню
        if text == "Меню на сегодня":
            return await show_today_menu(update, context)
        
        elif text == "Меню на неделю":
            return await show_week_menu(update, context)
        
        elif text == "Просмотреть заказы":
            return await view_orders(update, context)
        
        elif text == "Статистика за месяц":
            return await monthly_stats(update, context)
        
        # elif text == "Написать администратору":
            # return await start_admin_message(update, context)
        
        elif text == "Вернуться в главное меню":
            return await show_main_menu(update, user.id)
        
        elif text == "Обновить меню":
            await update.message.reply_text("Обновляю меню...", reply_markup=ReplyKeyboardRemove())
            return await show_main_menu(update, user.id)

        # Обработка отчетов
        elif text == "💰 Бухгалтерский отчет":
            if user.id in CONFIG['accounting_ids']:
                context.user_data['report_type'] = 'accounting'
                logger.info(f"Установлен report_type: accounting для пользователя {user.id}")
                await update.message.reply_text(
                    "Выберите период:",
                    reply_markup=ReplyKeyboardMarkup([
                        ["Текущий месяц"],
                        ["Прошлый месяц"],
                        ["Вернуться в главное меню"]
                    ], resize_keyboard=True)
                )
                return SELECT_MONTH_RANGE
            else:
                await update.message.reply_text("❌ У вас нет прав для просмотра бухгалтерских отчетов")
                return await show_main_menu(update, user.id)

        elif text == "📦 Отчет поставщика":
            if user.id in CONFIG['provider_ids']:
                context.user_data['report_type'] = 'provider'
                logger.info(f"Установлен report_type: provider для пользователя {user.id}")
                await update.message.reply_text(
                    "Выберите период:",
                    reply_markup=ReplyKeyboardMarkup([
                        ["Текущий месяц"],
                        ["Прошлый месяц"],
                        ["Вернуться в главное меню"]
                    ], resize_keyboard=True)
                )
                return SELECT_MONTH_RANGE
            else:
                await update.message.reply_text("❌ У вас нет прав для просмотра отчетов поставщика")
                return await show_main_menu(update, user.id)

        # Для администраторов
        elif text == "📊 Отчет за день":
            if user.id in CONFIG['admin_ids']:
                context.user_data['report_type'] = 'admin'
                await export_accounting_report(update, context)
                return await show_main_menu(update, user.id)
            else:
                await update.message.reply_text("❌ Эта команда только для администраторов")
                return await show_main_menu(update, user.id)

        elif text == "📅 Отчет за месяц":
            if user.id in CONFIG['admin_ids']:
                context.user_data['report_type'] = 'admin'
                await update.message.reply_text(
                    "Выберите период:",
                    reply_markup=ReplyKeyboardMarkup([
                        ["Текущий месяц"],
                        ["Прошлый месяц"],
                        ["Вернуться в главное меню"]
                    ], resize_keyboard=True)
                )
                return SELECT_MONTH_RANGE
            else:
                await update.message.reply_text("❌ Эта команда только для администраторов")
                return await show_main_menu(update, user.id)

        # Обработка неизвестной команды
        else:
            await update.message.reply_text(
                "Неизвестная команда. Попробуйте обновить меню или используйте /start",
                reply_markup=ReplyKeyboardRemove()
            )
            return await show_main_menu(update, user.id)

    except Exception as e:
        logger.error(f"Ошибка в main_menu: {e}", exc_info=True)
        from keyboards import create_main_menu_keyboard  # Импорт в блоке except
        await update.message.reply_text(
            "⚠️ Произошла ошибка. Попробуйте снова.",
            reply_markup=create_main_menu_keyboard(user.id)
        )
    
async def handle_registered_user(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик для зарегистрированных пользователей"""
    user = update.effective_user
    
    # Проверяем регистрацию
    db.cursor.execute("SELECT is_verified FROM users WHERE telegram_id = ?", (user.id,))
    result = db.cursor.fetchone()
    
    if not result or not result[0]:
        await update.message.reply_text(
            "Пожалуйста, сначала зарегистрируйтесь через /start",
            reply_markup=ReplyKeyboardRemove()
        )
        return
    
    # Если пользователь зарегистрирован - обрабатываем команду
    text = update.message.text
    
    # Обработка отчетов
    if text == "💰 Бухгалтерский отчет":
        if user.id in CONFIG['accounting_ids']:
            context.user_data['report_type'] = 'accounting'
            await update.message.reply_text(
                "Выберите период:",
                reply_markup=ReplyKeyboardMarkup([
                    ["Текущий месяц", "Прошлый месяц"],
                    ["Вернуться в главное меню"]
                ], resize_keyboard=True)
            )
            return SELECT_MONTH_RANGE
    
    elif text == "📦 Отчет поставщика":
        if user.id in CONFIG['provider_ids']:
            context.user_data['report_type'] = 'provider'
            await update.message.reply_text(
                "Выберите период:",
                reply_markup=ReplyKeyboardMarkup([
                    ["Текущий месяц", "Прошлый месяц"],
                    ["Вернуться в главное меню"]
                ], resize_keyboard=True)
            )
            return SELECT_MONTH_RANGE
    
    # Все остальные команды обрабатываем через main_menu
    return await main_menu(update, context)



# === callback_handlers.py ===

import logging
from telegram import Update, ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardRemove
from datetime import datetime, timedelta
from config import CONFIG, LOCATIONS, TIMEZONE, MENU, ADMIN_IDS
from db import db
from telegram.ext import CommandHandler, MessageHandler, CallbackQueryHandler, ConversationHandler, filters, ContextTypes
from .states import MAIN_MENU
from .common import show_main_menu
from utils import can_modify_order, is_order_cancelled
from utils import format_menu
import sqlite3
from .menu_handlers import view_orders

logger = logging.getLogger(__name__)

async def handle_order_callback(query, now, user, context):
    """Оформление заказа с ручной проверкой дат"""
    try:
        # Парсим параметры из callback
        _, day_offset_str = query.data.split("_", 1)
        day_offset = int(day_offset_str)
        target_date = (now + timedelta(days=day_offset)).date()
        
        # Ручная проверка 1: Заказы на выходные не принимаются
        if target_date.weekday() >= 5:  # 5-6 = суббота-воскресенье
            await query.answer("ℹ️ Заказы на выходные не принимаются", show_alert=True)
            return

        # Ручная проверка 2: Предзаказы только на будущие даты
        if day_offset > 0 and target_date <= now.date():
            await query.answer("❌ Предзаказ можно сделать только на будущие даты", show_alert=True)
            return

        # Ручная проверка 3: Обычные заказы только на сегодня и до 9:30
        if day_offset == 0:
            if now.time() >= time(9, 30):
                await query.answer("ℹ️ Приём заказов на сегодня завершён в 9:30", show_alert=True)
                return

        # Получаем ID пользователя из БД
        db.cursor.execute("SELECT id FROM users WHERE telegram_id = ?", (user.id,))
        user_record = db.cursor.fetchone()
        if not user_record:
            await query.answer("❌ Пользователь не найден", show_alert=True)
            return
        user_db_id = user_record[0]

        # Проверяем существующий заказ
        db.cursor.execute("""
            SELECT quantity FROM orders 
            WHERE user_id = ? 
              AND target_date = ?
              AND is_cancelled = FALSE
        """, (user_db_id, target_date.isoformat()))
        existing_order = db.cursor.fetchone()

        if existing_order:
            await query.answer(f"ℹ️ У вас уже заказано {existing_order[0]} порций", show_alert=True)
            return

        # Создаём новый заказ
        with db.conn:
            db.cursor.execute("""
                INSERT INTO orders (
                    user_id,
                    target_date,
                    order_time,
                    quantity,
                    is_preliminary,
                    created_at
                ) VALUES (?, ?, ?, ?, ?, ?)
            """, (
                user_db_id,
                target_date.isoformat(),
                now.strftime("%H:%M:%S"),  # Только время
                1,  # Количество порций
                day_offset > 0,  # Это предзаказ?
                datetime.now().strftime("%Y-%m-%d %H:%M:%S")  # Полная дата-время
            ))

        # Обновляем интерфейс
        await refresh_day_view(query, day_offset, user_db_id, now, is_order=True)
        await query.answer("✅ Заказ успешно оформлен")

    except Exception as e:
        logger.error(f"Ошибка при оформлении заказа: {e}", exc_info=True)
        await query.answer("⚠️ Произошла ошибка. Попробуйте позже", show_alert=True)

async def handle_change_callback(query, now, user, context):
    """Обработчик изменения количества порций с сохранением меню"""
    try:
        _, day_offset_str = query.data.split("_", 1)
        day_offset = int(day_offset_str)
        target_date = (now + timedelta(days=day_offset)).date()
        days_ru = ["Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", "Воскресенье"]
        day_name = days_ru[target_date.weekday()]
        menu = MENU.get(day_name)

        # Проверка возможности изменения
        if not can_modify_order(target_date):
            await query.answer("ℹ️ Изменение невозможно после 9:30", show_alert=True)
            return await refresh_day_view(query, day_offset, context.user_data['user_db_id'], now)

        # Получаем ID пользователя
        db.cursor.execute("SELECT id FROM users WHERE telegram_id = ?", (user.id,))
        user_db_id = db.cursor.fetchone()[0]
        context.user_data['user_db_id'] = user_db_id
        context.user_data['current_day_offset'] = day_offset

        # Получаем текущее количество порций
        db.cursor.execute("""
            SELECT quantity FROM orders 
            WHERE user_id = ? AND target_date = ? AND is_cancelled = FALSE
        """, (user_db_id, target_date.isoformat()))
        current_qty = db.cursor.fetchone()[0]

        # Формируем текст сообщения
        menu_text = (
            f"🍽 Меню на {day_name} ({target_date.strftime('%d.%m')}):\n"
            f"1. 🍲 Первое: {menu['first']}\n"
            f"2. 🍛 Основное блюдо: {menu['main']}\n"
            f"3. 🥗 Салат: {menu['salad']}\n\n"
            f"🛒 Текущий заказ: {current_qty} порции"
        )

        # Создаем клавиатуру
        keyboard = [
            [
                InlineKeyboardButton("➖ Уменьшить", callback_data=f"dec_{day_offset}"),
                InlineKeyboardButton("➕ Увеличить", callback_data=f"inc_{day_offset}")
            ],
            [InlineKeyboardButton("✔️ Подтвердить", callback_data=f"confirm_{day_offset}")],
            [InlineKeyboardButton("❌ Отменить заказ", callback_data=f"cancel_{day_offset}")]
        ]

        # Обновляем сообщение
        await query.edit_message_text(
            text=menu_text,
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode="Markdown"
        )
        await query.answer()

    except Exception as e:
        logger.error(f"Ошибка в handle_change_callback: {e}", exc_info=True)
        await query.answer("⚠️ Ошибка изменения", show_alert=True)
        
async def handle_quantity_change(query, now, user, context):
    """Увеличение/уменьшение порций с проверкой времени и максимума"""
    try:
        action, day_offset_str = query.data.split("_", 1)
        day_offset = int(day_offset_str)
        target_date = (now + timedelta(days=day_offset)).date()
        max_portions = 3  # Ваша константа

        # Проверка времени (ваша существующая проверка)
        if not can_modify_order(target_date):
            await query.answer("ℹ️ Изменение невозможно после 9:30", show_alert=True)
            return

        # Получаем ID пользователя (ваш существующий код)
        db.cursor.execute("SELECT id FROM users WHERE telegram_id = ?", (user.id,))
        user_record = db.cursor.fetchone()
        if not user_record:
            await query.answer("❌ Пользователь не найден", show_alert=True)
            return
        user_db_id = user_record[0]

        # Получаем текущее количество (ваш код)
        db.cursor.execute("""
            SELECT quantity 
            FROM orders 
            WHERE user_id = ?
              AND target_date = ?
              AND is_cancelled = FALSE
        """, (user_db_id, target_date.isoformat()))
        result = db.cursor.fetchone()
        if not result:
            await query.answer("❌ Заказ не найден", show_alert=True)
            return
        current_quantity = result[0]

        # Логика изменения (основана на вашей реализации)
        if action == "increase":
            if current_quantity >= max_portions:
                await query.answer("ℹ️ Максимальное количество порций (3) достигнуто", show_alert=True)
                return
            new_quantity = current_quantity + 1
            feedback = f"✅ Увеличено до {new_quantity} порций"
            
        elif action == "decrease":
            if current_quantity <= 1:
                # Ваш код отмены заказа
                with db.conn:
                    db.cursor.execute("""
                        UPDATE orders
                        SET is_cancelled = TRUE,
                            order_time = ?
                        WHERE user_id = ?
                          AND target_date = ?
                          AND is_cancelled = FALSE
                    """, (now.strftime("%H:%M:%S"), user_db_id, target_date.isoformat()))
                
                days_ru = ["Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", "Воскресенье"]
                day_name = days_ru[target_date.weekday()]
                
                await query.edit_message_text(
                    text=f"❌ Заказ на {day_name} отменён",
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("✅ Заказать", callback_data=f"order_{day_offset}")]
                    ])
                )
                await query.answer("ℹ️ Заказ отменён")
                return
                
            new_quantity = current_quantity - 1
            feedback = f"✅ Уменьшено до {new_quantity} порций"
            
        else:
            await query.answer("⚠️ Неизвестное действие")
            return

        # Обновляем количество (ваш код)
        with db.conn:
            db.cursor.execute("""
                UPDATE orders
                SET quantity = ?,
                    order_time = ?
                WHERE user_id = ?
                  AND target_date = ?
                  AND is_cancelled = FALSE
            """, (new_quantity, now.strftime("%H:%M:%S"), user_db_id, target_date.isoformat()))

        # Используем refresh_day_view вместо прямого редактирования
        await refresh_day_view(query, day_offset, user_db_id, now)
        await query.answer(feedback)

    except Exception as e:
        logger.error(f"Ошибка изменения количества ({action}): {e}")
        await query.answer("⚠️ Ошибка изменения. Попробуйте позже", show_alert=True)

# --- Callback для отмены заказа ---
async def handle_cancel_callback(query, now, user, context):
    """Отмена заказа с улучшенной обработкой ошибок и безопасностью"""
    try:
        # Проверяем формат callback данных
        if not query.data or '_' not in query.data:
            logger.warning(f"Некорректный callback: {query.data}")
            await query.answer("⚠️ Ошибка в запросе")
            return

        # Разбираем данные callback
        _, date_part = query.data.split("_", 1)
        
        # Определяем дату заказа
        if '-' in date_part:  # Формат YYYY-MM-DD
            try:
                if len(date_part.split('-')) != 3:
                    raise ValueError
                    
                target_date = datetime.strptime(target_date_str, "%Y-%m-%d").date()
                day_offset = (target_date - now.date()).days
            except ValueError:
                logger.error(f"Неверный формат даты в callback: {date_part}")
                await query.answer("⚠️ Ошибка в дате")
                return
                
        elif date_part.isdigit():  # Смещение дней
            day_offset = int(date_part)
            target_date = (now + timedelta(days=day_offset)).date()
        else:
            logger.error(f"Неизвестный формат даты: {query.data}")
            await query.answer("⚠️ Ошибка в запросе")
            return

        # Проверяем можно ли отменять заказ
        if not can_modify_order(target_date):
            await query.answer("ℹ️ Отмена невозможна после 9:30", show_alert=True)
            return

        # Получаем ID пользователя из БД
        db.cursor.execute(
            "SELECT id FROM users WHERE telegram_id = ? AND is_verified = TRUE",
            (user.id,)
        )
        user_record = db.cursor.fetchone()
        
        if not user_record:
            await query.answer("❌ Пользователь не найден", show_alert=True)
            return
            
        user_db_id = user_record[0]

        # Выполняем отмену заказа в транзакции
        with db.conn:
            db.cursor.execute("""
                UPDATE orders
                SET is_cancelled = TRUE,
                    order_time = ?
                WHERE user_id = ?
                  AND target_date = ?
                  AND is_cancelled = FALSE
                RETURNING id
            """, (now.strftime("%H:%M:%S"), user_db_id, target_date.isoformat()))
            
            # Проверяем что заказ был найден и отменен
            if not db.cursor.fetchone():
                await query.answer("❌ Заказ не найден", show_alert=True)
                return

        # Логируем отмену
        logger.info(
            f"Пользователь {user.id} отменил заказ на {target_date}"
        )

        # Обновляем интерфейс
        try:
            await refresh_day_view(query, day_offset, user_db_id, now)
            await query.answer("✅ Заказ отменён")
        except Exception as e:
            logger.error(f"Ошибка обновления интерфейса: {e}")
            await query.answer("⚠️ Заказ отменён, но возникла ошибка отображения")

    except Exception as e:
        logger.error(f"Критическая ошибка в handle_cancel_callback: {e}", exc_info=True)
        await query.answer("⚠️ Произошла ошибка. Попробуйте снова.", show_alert=True)

async def refresh_orders_view(query, context, user_id, now, days_ru):
    """Обновляет список заказов после изменения количества"""
    try:
        db.cursor.execute("""
            SELECT o.target_date, o.quantity, o.is_preliminary
            FROM orders o
            JOIN users u ON o.user_id = u.id
            WHERE u.telegram_id = ?
              AND o.is_cancelled = FALSE
              AND o.target_date >= ?
            ORDER BY o.target_date
        """, (user_id, now.date().isoformat()))

        active_orders = db.cursor.fetchall()

        if not active_orders:
            await query.edit_message_text("ℹ️ У вас нет активных заказов.")
            return await show_main_menu(query.message, user_id)

        response = "📦 Ваши активные заказы:\n"
        keyboard = []

        for order in active_orders:
            target_date = datetime.strptime(order[0], "%Y-%m-%d").date()
            day_name = days_ru[target_date.weekday()]
            date_str = target_date.strftime('%d.%m')
            qty = order[1]
            status = " (предварительный)" if order[2] else ""

            response += f"📅 {day_name} ({date_str}) - {qty} порций{status}\n"
            keyboard.append([
                InlineKeyboardButton(f"✏️ Изменить {date_str}", callback_data=f"change_{target_date.strftime('%Y-%m-%d')}"),
                InlineKeyboardButton(f"✕ Отменить {date_str}", callback_data=f"cancel_{target_date.strftime('%Y-%m-%d')}")
            ])

        keyboard.append([InlineKeyboardButton("✔ В главное меню", callback_data="back_to_menu")])

        await query.edit_message_text(
            response,
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode="Markdown"
        )

    except Exception as e:
        logger.error(f"Ошибка обновления списка: {e}")
        await query.edit_message_text("⚠️ Ошибка загрузки заказов")

async def refresh_day_view(query, day_offset, user_db_id, now, is_order=False):
    """Обновляет меню дня с информацией о заказе"""
    try:
        days_ru = ["Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", "Воскресенье"]
        target_date = (now + timedelta(days=day_offset)).date()
        day_name = days_ru[target_date.weekday()]
        date_str = target_date.strftime("%d.%m")
        menu = MENU.get(day_name)

        # Формируем текст сообщения
        if not menu:
            response_text = f"📅 {day_name} ({date_str}) - выходной! Меню не предусмотрено."
        else:
            response_text = (
                f"🍽 Меню на {day_name} ({date_str}):\n"
                f"1. 🍲 Первое: {menu['first']}\n"
                f"2. 🍛 Основное блюдо: {menu['main']}\n"
                f"3. 🥗 Салат: {menu['salad']}"
            )

        # Проверяем заказ пользователя
        db.cursor.execute("""
            SELECT quantity, is_preliminary 
            FROM orders 
            WHERE user_id = ? 
              AND target_date = ?
              AND is_cancelled = FALSE
        """, (user_db_id, target_date.isoformat()))
        order = db.cursor.fetchone()

        # Добавляем информацию о заказе
        keyboard = []
        if order:
            qty, is_preliminary = order
            order_type = "Предзаказ" if is_preliminary else "Заказ"
            response_text += f"\n\n✅ {order_type}: {qty} порции"
            
            if can_modify_order(target_date):
                keyboard.append([InlineKeyboardButton("✏️ Изменить", callback_data=f"change_{day_offset}")])
                keyboard.append([InlineKeyboardButton("❌ Отменить", callback_data=f"cancel_{day_offset}")])
            else:
                response_text += "\n⏳ Изменение невозможно (время истекло)"
        elif can_modify_order(target_date):
            keyboard.append([InlineKeyboardButton("✅ Заказать", callback_data=f"order_{day_offset}")])
        else:
            response_text += "\n⏳ Приём заказов завершён"

        # Отправляем обновлённое сообщение
        await query.edit_message_text(
            text=response_text,
            reply_markup=InlineKeyboardMarkup(keyboard) if keyboard else None,
            parse_mode="Markdown"
        )

    except Exception as e:
        logger.error(f"Ошибка обновления дня: {e}", exc_info=True)
        await query.answer("⚠️ Ошибка обновления. Попробуйте позже", show_alert=True)

async def modify_portion_count(query, now, user, context, delta):
    """Изменение количества порций"""
    try:
        day_offset = context.user_data['current_day_offset']
        target_date = (now + timedelta(days=day_offset)).date()
        user_db_id = context.user_data['user_db_id']
        
        # Получаем текущее количество
        db.cursor.execute("""
            SELECT quantity FROM orders 
            WHERE user_id = ? AND target_date = ? AND is_cancelled = FALSE
        """, (user_db_id, target_date.isoformat()))
        current_qty = db.cursor.fetchone()[0]
        new_qty = current_qty + delta

        # Проверка границ
        if new_qty < 1:
            return await handle_cancel_callback(query, now, user, context)
        if new_qty > 3:
            await query.answer("ℹ️ Максимум 3 порции")
            return

        # Обновляем количество
        with db.conn:
            db.cursor.execute("""
                UPDATE orders SET quantity = ? 
                WHERE user_id = ? AND target_date = ? AND is_cancelled = FALSE
            """, (new_qty, user_db_id, target_date.isoformat()))

        # Обновляем интерфейс без возврата в меню
        await handle_change_callback(query, now, user, context)
        await query.answer(f"Установлено: {new_qty} порции")

    except Exception as e:
        logger.error(f"Ошибка изменения количества: {e}")
        await query.answer("⚠️ Ошибка изменения", show_alert=True)

async def handle_confirm_callback(query, now, user, context):
    """Подтверждение заказа"""
    try:
        day_offset = context.user_data['current_day_offset']
        await refresh_day_view(query, day_offset, context.user_data['user_db_id'], now)
        await query.answer("✅ Заказ подтверждён")
    except Exception as e:
        logger.error(f"Ошибка подтверждения: {e}")
        await query.answer("⚠️ Ошибка подтверждения", show_alert=True)

async def callback_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    now = datetime.now(TIMEZONE)
    user = update.effective_user
    
    try:
        if query.data.startswith("inc_"):
            await modify_portion_count(query, now, user, context, +1)
        elif query.data.startswith("dec_"):
            await modify_portion_count(query, now, user, context, -1)
        elif query.data.startswith("change_"):
            await handle_change_callback(query, now, user, context)
        elif query.data.startswith("cancel_"):
            await handle_cancel_callback(query, now, user, context)
        elif query.data.startswith("confirm_"):
            await handle_confirm_callback(query, now, user, context)
        elif query.data.startswith("order_"):
            await handle_order_callback(query, now, user, context)
        elif query.data == "back_to_menu":
            await show_main_menu(query.message, user.id)
        elif query.data == "noop":
            await query.answer()  # Пустое действие
        elif query.data == "refresh":
            pass  # Логика обновления, если нужно
        else:
            logger.warning(f"Неизвестный callback: {query.data}")
            await query.answer("⚠️ Неизвестная команда")

    except Exception as e:
        logger.error(f"Ошибка в callback_handler: {e}", exc_info=True)
        try:
            await query.answer("⚠️ Произошла ошибка. Попробуйте позже")
        except Exception as inner_e:
            logger.error(f"Ошибка при обработке callback: {inner_e}")
    
async def handle_cancel_order(query, target_date_str):
    if not can_modify_order(target_date_str):  # Используем ВАШУ проверку
        await query.answer("ℹ️ Отмена заказа невозможна после 9:30", show_alert=True)
        return
    
    """Обработка отмены заказа по конкретной дате"""
    user_id = query.from_user.id
    target_date = datetime.strptime(target_date_str, "%Y-%m-%d").date()
    now = datetime.now(TIMEZONE)
    
    if not can_modify_order(target_date):
        await query.answer("ℹ️ Отмена невозможна (после 9:30)", show_alert=True)
        return False

    db.cursor.execute(
        "DELETE FROM orders WHERE user_id = "
        "(SELECT id FROM users WHERE telegram_id = ?) AND target_date = ?",
        (user_id, target_date_str)
    )
    db.conn.commit()
    
    return db.cursor.rowcount > 0
    
async def handle_back_callback(query, now, user, context):
    """Обработчик кнопки 'Назад'"""
    try:
        _, day_offset_str = query.data.split("_", 1)
        day_offset = int(day_offset_str)
        await refresh_day_view(query, day_offset, context.user_data['user_db_id'], now)
        await query.answer("Возврат к меню")
    except Exception as e:
        logger.error(f"Ошибка в handle_back_callback: {e}")
        await query.answer("⚠️ Ошибка возврата", show_alert=True)



# === common.py ===

from telegram import Update, ReplyKeyboardMarkup
from telegram.ext import ContextTypes, ConversationHandler
import logging
from db import db
from keyboards import create_main_menu_keyboard
from .states import MAIN_MENU, FULL_NAME

logger = logging.getLogger(__name__)

async def show_main_menu(update: Update, user_id: int):
    """Общая функция для показа главного меню"""
    try:
        db.cursor.execute("SELECT is_verified FROM users WHERE telegram_id = ?", (user_id,))
        result = db.cursor.fetchone()

        if not result or not result[0]:
            # Пользователь не зарегистрирован
            reply_markup = create_unverified_user_keyboard()
        else:
            # Пользователь зарегистрирован
            reply_markup = create_main_menu_keyboard(user_id)

        if isinstance(update, Update) and update.message:
            await update.message.reply_text("Главное меню:", reply_markup=reply_markup)
        return MAIN_MENU

    except Exception as e:
        logger.error(f"Ошибка в show_main_menu: {e}", exc_info=True)
        if isinstance(update, Update) and update.message:
            await update.message.reply_text(
                "⚠️ Произошла ошибка. Попробуйте снова.",
                reply_markup=ReplyKeyboardRemove()
            )
        return ConversationHandler.END



# === menu_handlers.py ===

import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardMarkup, KeyboardButton
from telegram.ext import ContextTypes
from datetime import datetime, timedelta, date
from config import CONFIG, LOCATIONS, TIMEZONE, MENU, ADMIN_IDS
from db import db
from utils import (
    is_employee,
    get_menu_for_day,
    format_menu,
    check_registration,
    handle_unregistered,
    can_modify_order,
    is_order_time_expired,
    is_order_cancelled
)
from .states import MAIN_MENU, ORDER_ACTION, SELECT_MONTH_RANGE_STATS
from .common import show_main_menu
from keyboards import create_main_menu_keyboard, create_admin_keyboard

logger = logging.getLogger(__name__)

async def show_today_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await check_registration(update, context):
        return await handle_unregistered(update, context)
    
    user_id = update.effective_user.id
    now = datetime.now(TIMEZONE)
    days_ru = ["Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", "Воскресенье"]
    day_name = days_ru[now.weekday()]
    menu = MENU.get(day_name)
    
    if not menu:
        await update.message.reply_text(f"⏳ Сегодня ({day_name}) выходной! Меню не предусмотрено.")
        return await show_main_menu(update, user_id)
    
    message = format_menu(menu, day_name)
    
    # Проверяем есть ли активный заказ
    db.cursor.execute(
        "SELECT quantity FROM orders WHERE user_id = "
        "(SELECT id FROM users WHERE telegram_id = ?) AND target_date = ? AND is_cancelled = FALSE",
        (user_id, now.date().isoformat())
    )
    has_active_order = db.cursor.fetchone() is not None
    
    can_modify = can_modify_order(now.date())
    
    if has_active_order:
        if can_modify:
            keyboard = [
                [InlineKeyboardButton("✏️ Изменить количество", callback_data="change_0")],
                [InlineKeyboardButton("❌ Отменить заказ", callback_data="cancel_0")]
            ]
        else:
            keyboard = [
                [InlineKeyboardButton("ℹ️ Заказ оформлен (изменение невозможно)", callback_data="noop")]
            ]
    else:
        if can_modify:
            keyboard = [
                [InlineKeyboardButton("✅ Заказать", callback_data="order_0")]
            ]
        else:
            keyboard = [
                [InlineKeyboardButton("⏳ Прием заказов завершен", callback_data="info")]
            ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text(message, reply_markup=reply_markup)
    return await show_main_menu(update, user_id)

async def show_week_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        user = update.effective_user
        now = datetime.now(TIMEZONE)
        today = now.date()
        days_ru = ["Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", "Воскресенье"]
        
        sent_days = 0
        
        for day_offset in range(7):
            day_date = today + timedelta(days=day_offset)
            day_name = days_ru[day_date.weekday()]
            date_str = day_date.strftime("%d.%m")
            
            # Проверяем праздники и выходные
            holiday_name = CONFIG['holidays'].get(day_date.strftime("%Y-%m-%d"))
            if holiday_name or day_date.weekday() >= 5:
                status = holiday_name if holiday_name else "Выходной"
                await update.message.reply_text(
                    f"📅 {day_name} ({date_str}) — {status}! Меню не предусмотрено."
                )
                continue
            
            menu = MENU.get(day_name)
            if not menu:
                logger.warning(f"Меню для {day_name} не найдено")
                continue
            
            menu_text = f"🍽 Меню на {day_name} ({date_str}):\n"
            menu_text += f"1. 🍲 Первое: {menu['first']}\n"
            menu_text += f"2. 🍛 Основное блюдо: {menu['main']}\n"
            menu_text += f"3. 🥗 Салат: {menu['salad']}"
            
            # Проверка заказа пользователя (используем target_date вместо target_date)
            db.cursor.execute("""
                SELECT quantity FROM orders 
                WHERE user_id = (SELECT id FROM users WHERE telegram_id = ?)
                AND target_date = ?
                AND is_cancelled = FALSE
            """, (user.id, day_date.isoformat()))
            order = db.cursor.fetchone()
            
            keyboard = []
            if order:
                menu_text += f"\n✅ Заказ: {order[0]} порции"
                if can_modify_order(day_date):
                    keyboard.append([InlineKeyboardButton("✏️ Изменить", callback_data=f"change_{day_offset}")])
            elif can_modify_order(day_date):
                keyboard.append([InlineKeyboardButton("✅ Заказать", callback_data=f"order_{day_offset}")])
            
            await update.message.reply_text(
                menu_text,
                reply_markup=InlineKeyboardMarkup(keyboard) if keyboard else None,
                parse_mode="Markdown"
            )
            sent_days += 1
        
        if sent_days == 0:
            await update.message.reply_text("ℹ️ На эту неделю меню не загружено")
            
    except Exception as e:
        logger.error(f"Ошибка в show_week_menu: {e}", exc_info=True)
        from keyboards import create_main_menu_keyboard  # Добавляем импорт
        await update.message.reply_text(
            "⚠️ Ошибка при загрузке меню. Попробуйте позже.",
            reply_markup=create_main_menu_keyboard(user.id)
        )
async def show_day_menu(update: Update, context: ContextTypes.DEFAULT_TYPE, day_offset=0):
    """Показывает меню на указанный день с возможностью заказа"""
    try:
        user = update.effective_user
        now = datetime.now(TIMEZONE)
        days_ru = ["Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", "Воскресенье"]
        target_date = now.date() + timedelta(days=day_offset)
        day_name = days_ru[target_date.weekday()]
        is_tomorrow = day_offset == 1
        is_today = day_offset == 0
        menu = MENU.get(day_name)

        # Если выходной
        if not menu:
            await update.message.reply_text(f"⏳ На {day_name} ({target_date.strftime('%d.%m')}) выходной!")
            return

        message = format_menu(menu, day_name, is_tomorrow=is_tomorrow)

        # Получаем ID пользователя из БД
        db.cursor.execute("SELECT id FROM users WHERE telegram_id = ?", (user.id,))
        user_record = db.cursor.fetchone()
        if not user_record:
            await update.message.reply_text("❌ Пользователь не найден")
            return
        user_db_id = user_record[0]

        # Получаем текущий заказ
        db.cursor.execute("""
            SELECT quantity 
            FROM orders 
            WHERE user_id = ?
              AND target_date = ?
              AND is_cancelled = FALSE
        """, (user_db_id, target_date.isoformat()))
        order = db.cursor.fetchone()

        # Добавляем информацию о заказе
        keyboard = []

        if order:
            qty = order[0]
            message += f"\n\n✅ {'Предзаказ' if day_offset > 0 else 'Заказ'}: {qty} порции"

            can_modify = can_modify_order(target_date)
            if can_modify:
                keyboard.append([InlineKeyboardButton("✏️ Изменить количество", callback_data=f"change_{day_offset}")])
            keyboard.append([
                InlineKeyboardButton("❌ Отменить заказ", callback_data=f"cancel_{day_offset}")
            ])
        else:
            can_modify = can_modify_order(target_date)
            if can_modify:
                keyboard.append([InlineKeyboardButton("✅ Заказать", callback_data=f"order_{day_offset}")])
            else:
                keyboard.append([InlineKeyboardButton("⏳ Приём заказов завершён", callback_data="noop")])

        await update.message.reply_text(
            message,
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode="Markdown"
        )

    except Exception as e:
        logger.error(f"Ошибка в show_day_menu: {e}")
        await update.message.reply_text("⚠️ Ошибка загрузки меню")

# --- Просмотр заказов ---
async def view_orders(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Показывает только будущие и сегодняшние активные (не отменённые) заказы"""
    try:
        # Определяем, откуда вызвана функция
        if hasattr(update, 'message'):
            user = update.effective_user
            message = update.message
        else:
            user = update.callback_query.from_user
            message = update.callback_query.message

        user_id = user.id
        now = datetime.now(TIMEZONE)
        today_str = now.date().isoformat()

        # Получаем только будущие и сегодняшние заказы
        db.cursor.execute("""
            SELECT o.target_date, o.quantity, o.is_preliminary
            FROM orders o
            JOIN users u ON o.user_id = u.id
            WHERE u.telegram_id = ?
            AND o.is_cancelled = FALSE
            AND o.target_date >= ?
            ORDER BY o.target_date
        """, (user_id, today_str))

        active_orders = db.cursor.fetchall()

        if not active_orders:
            await message.reply_text("ℹ️ У вас нет активных заказов.")
            return await show_main_menu(message, user_id)

        # Формируем текст ответа
        response = "📦 Ваши активные заказы:\n"
        keyboard = []

        days_ru = ["Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", "Воскресенье"]

        for order in active_orders:
            target_date = datetime.strptime(order[0], "%Y-%m-%d").date()
            day_name = days_ru[target_date.weekday()]
            date_str = target_date.strftime('%d.%m')
            qty = order[1]

            status = " (предварительный)" if order[2] else ""
            response += f"📅 {day_name} ({date_str}) - {qty} порций{status}\n"
            keyboard.append([
                InlineKeyboardButton(
                    f"✕ Отменить {date_str}",
                    callback_data=f"cancel_{target_date.strftime('%Y-%m-%d')}"
                )
            ])

        keyboard.append([
            InlineKeyboardButton("✔ В главное меню", callback_data="back_to_menu")
        ])

        await message.reply_text(
            response,
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode="Markdown"
        )

    except Exception as e:
        logger.error(f"Ошибка в view_orders: {e}")
        await message.reply_text("⚠️ Ошибка загрузки заказов")
        return await show_main_menu(message, user_id)

async def order_action(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    Обработчик действий с заказами:
    - Отмена заказа (cancel_...)
    - Изменение количества порций (change_...)
    - Подтверждение заказа (confirm_...)
    """
    try:
        query = update.callback_query
        await query.answer()  # Подтверждаем нажатие кнопки

        logger.info(f"Получен callback: {query.data} от пользователя {query.from_user.id}")

        if query.data.startswith("cancel_"):
            # Извлекаем дату из callback_data
            try:
                _, date_part = query.data.split("_", 1)

                # Определяем дату
                now = datetime.now(TIMEZONE)
                if '-' in date_part:
                    target_date = datetime.strptime(date_part, "%Y-%m-%d").date()
                elif date_part.isdigit():
                    day_offset = int(date_part)
                    target_date = (now + timedelta(days=day_offset)).date()
                else:
                    raise ValueError(f"Неверный формат даты: {date_part}")

                # Проверяем возможность отмены
                if not can_modify_order(target_date):
                    await query.answer("ℹ️ Отмена невозможна после 9:30", show_alert=True)
                    return

                # Получаем ID пользователя из БД
                db.cursor.execute("SELECT id FROM users WHERE telegram_id = ?", (query.from_user.id,))
                user_record = db.cursor.fetchone()
                if not user_record:
                    await query.answer("❌ Пользователь не найден", show_alert=True)
                    return

                user_db_id = user_record[0]

                # Отменяем заказ в БД
                with db.conn:
                    db.cursor.execute("""
                        UPDATE orders 
                        SET is_cancelled = TRUE,
                            order_time = ?
                        WHERE user_id = ?
                          AND target_date = ?
                          AND is_cancelled = FALSE
                    """, (now.strftime("%H:%M:%S"), user_db_id, target_date.isoformat()))

                    if db.cursor.rowcount == 0:
                        await query.answer("❌ Заказ не найден", show_alert=True)
                        return

                # Обновляем интерфейс
                days_ru = ["Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", "Воскресенье"]
                if "Меню на" in query.message.text:
                    # Отмена из меню дня
                    day_name = days_ru[target_date.weekday()]
                    menu = MENU.get(day_name)
                    await query.edit_message_text(
                        text=f"~~{format_menu(menu, day_name)}~~\n❌ Заказ отменён",
                        reply_markup=InlineKeyboardMarkup([
                            [InlineKeyboardButton("✅ Заказать", callback_data=f"order_{target_date.isoformat()}")]
                        ]),
                        parse_mode="Markdown"
                    )
                else:
                    # Отмена из списка заказов
                    await refresh_orders_view(query, context, query.from_user.id, now, days_ru)

                await query.answer("✅ Заказ отменён")

            except Exception as e:
                logger.error(f"Ошибка при отмене заказа: {e}")
                await query.answer("⚠️ Ошибка отмены", show_alert=True)

        elif query.data.startswith("change_"):
            # Логика изменения количества порций (заглушка)
            await query.answer("🔄 Изменение количества порций временно недоступно")
            return

        elif query.data.startswith("confirm_"):
            # Логика подтверждения заказа (заглушка)
            await query.answer("✅ Заказ подтверждён")
            return

        else:
            # Неизвестное действие
            logger.warning(f"Неизвестный callback: {query.data}")
            await query.answer("⚠️ Неизвестное действие", show_alert=True)

    except Exception as e:
        logger.error(f"Критическая ошибка в order_action: {e}", exc_info=True)
        await query.answer("⚠️ Серверная ошибка", show_alert=True)

async def monthly_stats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Показывает меню выбора месяца для статистики."""
    try:
        user = update.effective_user
        reply_markup = ReplyKeyboardMarkup(
            [["Текущий месяц", "Прошлый месяц"], ["Вернуться в главное меню"]],
            resize_keyboard=True,
            one_time_keyboard=True
        )
        await update.message.reply_text(
            "📅 Выберите месяц для статистики:",
            reply_markup=reply_markup
        )
        return SELECT_MONTH_RANGE_STATS
    except Exception as e:
        logger.error(f"Ошибка при запуске monthly_stats: {e}")
        await update.message.reply_text("❌ Произошла ошибка. Попробуйте позже.")
        return await show_main_menu(update, user.id)


async def monthly_stats_selected(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка выбора месяца и вывод статистики."""
    try:
        user = update.effective_user
        text = update.message.text.strip()

        # Проверяем, хочет ли вернуться в меню
        if text == "Вернуться в главное меню":
            return await show_main_menu(update, user.id)

        # Получаем текущую дату
        now = datetime.now(TIMEZONE)
        current_year = now.year
        current_month = now.month

        if text == "Текущий месяц":
            start_date = now.replace(day=1).date()
            month_name = now.strftime("%B %Y")
        elif text == "Прошлый месяц":
            # Вычисляем последний день прошлого месяца
            first_day_current_month = now.replace(day=1)
            last_day_prev_month = first_day_current_month - timedelta(days=1)
            start_date = last_day_prev_month.replace(day=1)
            month_name = last_day_prev_month.strftime("%B %Y")
        else:
            await update.message.reply_text("❌ Неизвестный период. Пожалуйста, выберите из предложенных вариантов.")
            return SELECT_MONTH_RANGE_STATS

        # Получаем ID пользователя из базы данных
        db.cursor.execute("SELECT id FROM users WHERE telegram_id = ?", (user.id,))
        user_record = db.cursor.fetchone()
        if not user_record:
            await update.message.reply_text("❌ Пользователь не найден в системе.")
            return await show_main_menu(update, user.id)

        user_db_id = user_record[0]

        # Считаем количество порций за выбранный месяц (только неотмененные заказы)
        db.cursor.execute("""
            SELECT SUM(quantity)
            FROM orders
            WHERE user_id = ?
              AND target_date >= ?
              AND target_date <= date(?, 'start of month', '+1 month', '-1 day')
              AND is_cancelled = FALSE
        """, (user_db_id, start_date.isoformat(), start_date.isoformat()))

        result = db.cursor.fetchone()
        total_orders = result[0] or 0

        # Формируем ответ
        if total_orders == 0:
            message = f"📉 У вас пока нет заказов за {month_name}."
        else:
            message = (
                f"📊 Ваша статистика за {month_name}:\n"
                f"• Всего заказано порций: {total_orders}"
            )

        await update.message.reply_text(message)

    except Exception as e:
        logger.error(f"Ошибка при обработке выбора месяца в статистике: {e}", exc_info=True)
        await update.message.reply_text("❌ Произошла ошибка при получении статистики.")

    finally:
        return await show_main_menu(update, user.id)
    
async def handle_order_confirmation(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        text = update.message.text
        user = update.effective_user
        
        if text == "Да":
            now = datetime.now(TIMEZONE)
            target_date = now + timedelta(days=1)
            if now.weekday() == 4:  # Пятница -> понедельник
                target_date += timedelta(days=2)
            
            db.cursor.execute(
                "INSERT INTO orders (user_id, target_date, order_time, quantity, is_preliminary) "
                "SELECT id, ?, ?, 1, TRUE FROM users WHERE telegram_id = ?",
                (target_date.date().isoformat(), now.strftime("%H:%M:%S"), user.id)
            )
            db.conn.commit()
            await update.message.reply_text(f"✅ Предзаказ на {target_date.strftime('%d.%m')} оформлен!")
        else:
            await update.message.reply_text("❌ Заказ отменен.")
        
        return await show_main_menu(update, user.id)
    except Exception as e:
        logger.error(f"Ошибка в handle_order_confirmation: {e}")
        await update.message.reply_text("⚠️ Произошла ошибка. Попробуйте снова.")
        return await show_main_menu(update, user.id)



# === message_handlers.py ===

import logging
from telegram import Update, ReplyKeyboardMarkup, ReplyKeyboardRemove
from telegram.ext import ContextTypes, ConversationHandler, MessageHandler, filters, CommandHandler
from db import db
from config import CONFIG
from keyboards import create_main_menu_keyboard, create_admin_keyboard
import asyncio
from .states import (
    AWAIT_USER_SELECTION,
    AWAIT_MESSAGE_TEXT
)

logger = logging.getLogger(__name__)

async def start_user_to_admin_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Начало диалога пользователя с админом"""
    user = update.effective_user
    
    # Проверяем регистрацию пользователя
    db.cursor.execute(
        "SELECT full_name FROM users WHERE telegram_id = ? AND is_verified = TRUE",
        (user.id,)
    )
    user_data = db.cursor.fetchone()
    
    if not user_data:
        await update.message.reply_text(
            "❌ Вы не завершили регистрацию. Пожалуйста, используйте /start",
            reply_markup=ReplyKeyboardRemove()
        )
        return ConversationHandler.END
    
    context.user_data['user_name'] = user_data[0]
    await update.message.reply_text(
        "✍️ Введите ваше сообщение администратору:",
        reply_markup=ReplyKeyboardMarkup([["❌ Отменить"]], resize_keyboard=True)
    )
    return AWAIT_MESSAGE_TEXT

async def handle_user_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка сообщения от пользователя админам"""
    try:
        user = update.effective_user
        message_text = update.message.text
        
        if message_text.strip().lower() == "отменить":
            await update.message.reply_text(
                "❌ Отправка отменена",
                reply_markup=create_main_menu_keyboard(user.id)
            )
            return ConversationHandler.END

        # Получаем полное имя пользователя из базы данных
        db.cursor.execute(
            "SELECT full_name FROM users WHERE telegram_id = ?",
            (user.id,)
        )
        user_data = db.cursor.fetchone()
        full_name = user_data[0] if user_data else "Неизвестный пользователь"

        # Сохраняем сообщение в БД
        db.cursor.execute(
            "INSERT INTO admin_messages (user_id, message_text) "
            "VALUES ((SELECT id FROM users WHERE telegram_id = ?), ?)",
            (user.id, message_text)
        )
        db.conn.commit()

        # Формируем сообщение для админов в новом формате
        admin_message = (
            "✉️ Сообщение от пользователя:\n"
            f"👤 Имя: {full_name}\n"
            f"👤 Телеграм: @{user.username if user.username else 'нет'}\n"
            f"🆔 ID: {user.id}\n"
            f"📝 Текст: {message_text}"
        )

        # Отправляем всем админам
        sent_count = 0
        for admin_id in CONFIG['admin_ids']:
            try:
                await context.bot.send_message(
                    chat_id=admin_id,
                    text=admin_message
                )
                sent_count += 1
            except Exception as e:
                logger.error(f"Ошибка отправки админу {admin_id}: {e}")

        await update.message.reply_text(
            f"✅ Сообщение отправлено {sent_count} администраторам",
            reply_markup=create_main_menu_keyboard(user.id)
        )
        
        return ConversationHandler.END

    except Exception as e:
        logger.error(f"Ошибка обработки сообщения: {e}")
        await update.message.reply_text(
            "❌ Произошла ошибка при отправке. Попробуйте позже.",
            reply_markup=create_main_menu_keyboard(update.effective_user.id)
        )
        return ConversationHandler.END

async def start_admin_to_user_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Админ начинает диалог с пользователем"""
    if update.effective_user.id not in CONFIG['admin_ids']:
        await update.message.reply_text("❌ У вас нет прав для этой операции")
        return ConversationHandler.END

    # Очищаем предыдущие данные
    context.user_data.pop('recipient_id', None)
    context.user_data.pop('recipient_name', None)
    
    await update.message.reply_text(
        "Введите ID пользователя, @username или ФИО:\n"
        "(ФИО должно точно совпадать с указанным при регистрации)\n\n"
        "Для отмены нажмите кнопку 'Отмена'",
        reply_markup=ReplyKeyboardMarkup([["❌ Отмена"]], resize_keyboard=True)
    )
    return AWAIT_USER_SELECTION

async def handle_user_selection(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка выбора пользователя админом"""
    user_input = update.message.text.strip()
    
    # Проверка на отмену
    if user_input.lower() in ["отмена", "❌ отмена"]:
        await update.message.reply_text(
            "❌ Отправка отменена",
            reply_markup=create_admin_keyboard()
        )
        return ConversationHandler.END

    try:
        # Поиск пользователя в БД
        query = """
            SELECT telegram_id, full_name 
            FROM users 
            WHERE is_verified = TRUE AND (
                telegram_id = ? OR 
                username = ? OR 
                full_name LIKE ?
            )
        """
        
        # Подготавливаем параметры для поиска
        if user_input.isdigit():  # По ID
            params = (int(user_input), None, None)
        elif user_input.startswith('@'):  # По username
            params = (None, user_input[1:], None)
        else:  # По ФИО
            params = (None, None, f"%{user_input}%")
        
        db.cursor.execute(query, params)
        recipients = db.cursor.fetchall()

        if not recipients:
            await update.message.reply_text(
                "❌ Пользователь не найден. Проверьте ввод или нажмите 'Отмена'",
                reply_markup=ReplyKeyboardMarkup([["❌ Отмена"]], resize_keyboard=True)
            )
            return AWAIT_USER_SELECTION

        # Если нашли несколько пользователей
        if len(recipients) > 1:
            keyboard = []
            for user_id, full_name in recipients[:10]:  # Ограничим 10 результатами
                keyboard.append([f"{full_name} (ID: {user_id})"])
            
            keyboard.append(["❌ Отмена"])
            
            await update.message.reply_text(
                "Найдено несколько пользователей. Выберите одного:",
                reply_markup=ReplyKeyboardMarkup(keyboard, resize_keyboard=True)
            )
            context.user_data['found_users'] = recipients
            return AWAIT_USER_SELECTION

        # Если нашли одного пользователя
        recipient = recipients[0]
        context.user_data['recipient_id'] = recipient[0]
        context.user_data['recipient_name'] = recipient[1]
        
        await update.message.reply_text(
            f"Выбран пользователь: {recipient[1]}\n"
            "Введите сообщение или нажмите 'Отмена':",
            reply_markup=ReplyKeyboardMarkup([["❌ Отмена"]], resize_keyboard=True)
        )
        return AWAIT_MESSAGE_TEXT

    except Exception as e:
        logger.error(f"Ошибка выбора пользователя: {e}")
        await update.message.reply_text(
            "❌ Ошибка при поиске пользователя. Попробуйте снова или нажмите 'Отмена'",
            reply_markup=ReplyKeyboardMarkup([["❌ Отмена"]], resize_keyboard=True)
        )
        return AWAIT_USER_SELECTION

async def handle_admin_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Отправка сообщения от админа пользователю"""
    try:
        text = update.message.text.strip()
        
        # Проверка на отмену
        if text.lower() in ["отмена", "❌ отмена"]:
            await update.message.reply_text(
                "❌ Отправка отменена",
                reply_markup=create_admin_keyboard()
            )
            return ConversationHandler.END

        recipient_id = context.user_data.get('recipient_id')
        recipient_name = context.user_data.get('recipient_name')

        if not recipient_id:
            await update.message.reply_text(
                "❌ Получатель не выбран",
                reply_markup=create_admin_keyboard()
            )
            return ConversationHandler.END

        # Форматируем сообщение
        message = (
            "✉️ Сообщение от администратора:\n"
            f"📝 Текст: {text}\n\n"
        )

        try:
            await context.bot.send_message(
                chat_id=recipient_id,
                text=message
            )
            
            # Сохраняем в БД
            db.cursor.execute(
                "INSERT INTO admin_messages (admin_id, user_id, message_text) "
                "VALUES (?, ?, ?)",
                (update.effective_user.id, recipient_id, text)
            )
            db.conn.commit()

            await update.message.reply_text(
                f"✅ Сообщение отправлено пользователю {recipient_name}",
                reply_markup=create_admin_keyboard()
            )
        except Exception as e:
            logger.error(f"Ошибка отправки пользователю {recipient_id}: {e}")
            await update.message.reply_text(
                f"❌ Не удалось отправить сообщение пользователю {recipient_name}",
                reply_markup=create_admin_keyboard()
            )

        return ConversationHandler.END

    except Exception as e:
        logger.error(f"Ошибка отправки сообщения админа: {e}")
        await update.message.reply_text(
            "❌ Произошла ошибка при отправке",
            reply_markup=create_admin_keyboard()
        )
        return ConversationHandler.END

def setup_message_handlers(application):
    """Настройка обработчиков сообщений"""
    # Диалог пользователя с админами
    user_conv = ConversationHandler(
        entry_points=[MessageHandler(
            filters.Regex("^Написать администратору$") & filters.TEXT,
            start_user_to_admin_message
        )],
        states={
            AWAIT_MESSAGE_TEXT: [MessageHandler(filters.TEXT, handle_user_message)]
        },
        fallbacks=[
            CommandHandler('cancel', lambda u, c: ConversationHandler.END),
            MessageHandler(filters.Regex("^❌ Отменить$"), lambda u, c: ConversationHandler.END)
        ],
        allow_reentry=True
    )

    # Диалог админа с пользователем
    admin_conv = ConversationHandler(
        entry_points=[MessageHandler(
            filters.Regex("^✉️ Написать пользователю$") & filters.TEXT,
            start_admin_to_user_message
        )],
        states={
            AWAIT_USER_SELECTION: [MessageHandler(filters.TEXT, handle_user_selection)],
            AWAIT_MESSAGE_TEXT: [MessageHandler(filters.TEXT, handle_admin_message)]
        },
        fallbacks=[
            CommandHandler('cancel', lambda u, c: ConversationHandler.END),
            MessageHandler(filters.Regex("^❌ Отменить$"), lambda u, c: ConversationHandler.END)
        ],
        allow_reentry=True
    )

    application.add_handler(user_conv)
    application.add_handler(admin_conv)

async def handle_broadcast_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка команды рассылки"""
    if update.effective_user.id not in CONFIG['admin_ids']:
        logger.warning(f"Попытка рассылки от неадмина: {update.effective_user.id}")
        await update.message.reply_text("❌ У вас нет прав для этой команды")
        return ConversationHandler.END
    
    logger.info(f"Начало рассылки админом {update.effective_user.id}")
    await update.message.reply_text(
        "Введите сообщение для рассылки:",
        reply_markup=ReplyKeyboardMarkup([["❌ Отмена"]], resize_keyboard=True)
    )
    return AWAIT_MESSAGE_TEXT

async def process_broadcast_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка текста рассылки"""
    text = update.message.text
    logger.info(f"Получен текст для рассылки: {text}")
    
    if text.lower() in ["отмена", "❌ отмена"]:
        logger.info("Рассылка отменена")
        await update.message.reply_text(
            "❌ Рассылка отменена",
            reply_markup=create_admin_keyboard()
        )
        return ConversationHandler.END
    
    try:
        db.cursor.execute("SELECT telegram_id, full_name FROM users WHERE is_verified = TRUE")
        users = db.cursor.fetchall()
        
        if not users:
            logger.warning("Нет верифицированных пользователей для рассылки")
            await update.message.reply_text("❌ Нет пользователей для рассылки")
            return ConversationHandler.END
        
        logger.info(f"Начало рассылки для {len(users)} пользователей")
        msg = await update.message.reply_text(f"⏳ Рассылка для {len(users)} пользователей...")
        
        success = 0
        failed = []
        
        for user_id, full_name in users:
            try:
                await context.bot.send_message(
                    chat_id=user_id,
                    text=f"📢 Сообщение от администратора:\n\n{text}"
                )
                success += 1
                await asyncio.sleep(0.1)
            except Exception as e:
                failed.append(f"{full_name} (ID: {user_id})")
                logger.error(f"Ошибка отправки {user_id}: {e}")
        
        try:
            await msg.delete()
        except Exception as e:
            logger.error(f"Ошибка удаления сообщения: {e}")
        
        report = f"✅ Успешно: {success}/{len(users)}"
        if failed:
            report += f"\n❌ Ошибки: {len(failed)}"
        
        logger.info(f"Результат рассылки: {report}")
        await update.message.reply_text(
            report,
            reply_markup=create_admin_keyboard()
        )
        
    except Exception as e:
        logger.error(f"Ошибка рассылки: {e}", exc_info=True)
        await update.message.reply_text("❌ Ошибка при рассылке")
    
    return ConversationHandler.END


# === registration_handlers.py ===

import sqlite3
import logging
from telegram import Update, KeyboardButton, ReplyKeyboardMarkup, ReplyKeyboardRemove
from telegram.ext import ContextTypes, ConversationHandler
from db import db
from config import CONFIG, LOCATIONS, ADMIN_IDS  # Добавлен импорт LOCATIONS
from utils import is_employee
from .states import PHONE, FULL_NAME, LOCATION, MAIN_MENU
from .base_handlers import show_main_menu
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)

async def get_phone(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        if not update.message.contact:
            keyboard = [[KeyboardButton("📱 Отправить номер телефона", request_contact=True)]]
            reply_markup = ReplyKeyboardMarkup(keyboard, resize_keyboard=True)
            await update.message.reply_text(
                "Пожалуйста, используйте кнопку для отправки номера телефона:",
                reply_markup=reply_markup
            )
            return PHONE

        phone = update.message.contact.phone_number
        if not phone:
            await update.message.reply_text("Не удалось получить номер телефона. Попробуйте снова.")
            return PHONE

        db.cursor.execute("SELECT 1 FROM users WHERE phone = ?", (phone,))
        if db.cursor.fetchone():
            await update.message.reply_text("Этот номер телефона уже зарегистрирован.")
            return ConversationHandler.END

        context.user_data['phone'] = phone
        await update.message.reply_text("Отлично! Теперь введите ваше имя и фамилию одной строкой:")
        return FULL_NAME
    except Exception as e:
        logger.error(f"Ошибка при обработке номера телефона: {e}")
        await update.message.reply_text("Произошла ошибка. Попробуйте снова.")
        return PHONE

async def get_full_name(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Получает и проверяет ФИО пользователя."""
    try:
        user_input = update.message.text.strip()
        logger.info(f"Получено имя: '{user_input}' от пользователя {update.effective_user.id}")

        # Обработка специальных команд
        if user_input == "Написать администратору":
            return await handle_admin_message(update, context)

        if user_input == "Попробовать снова":
            await update.message.reply_text("Введите ваше имя и фамилию:")
            return FULL_NAME

        # Проверяем формат имени
        name_parts = user_input.split()
        if len(name_parts) < 2:
            await update.message.reply_text(
                "❌ Пожалуйста, введите имя и фамилию полностью.\nПример: Иван Иванов"
            )
            return FULL_NAME

        full_name = ' '.join(name_parts)  # Нормализуем пробелы
        context.user_data['full_name'] = full_name

        # Проверяем, есть ли в списке сотрудников
        if not is_employee(full_name):
            context.user_data['unverified_name'] = full_name
            reply_markup = ReplyKeyboardMarkup(
                [["Попробовать снова"], ["Написать администратору"]],
                resize_keyboard=True
            )
            await update.message.reply_text(
                "❌ Вас нет в списке сотрудников. Вы можете:",
                reply_markup=reply_markup
            )
            return FULL_NAME

        # Проверяем, зарегистрирован ли уже
        db.cursor.execute(
            "SELECT 1 FROM users WHERE full_name = ? LIMIT 1",
            (full_name,)
        )
        if db.cursor.fetchone():
            await update.message.reply_text("⚠️ Данный сотрудник уже зарегистрирован.")
            return ConversationHandler.END

        # Переход к выбору локации
        keyboard = [[loc] for loc in LOCATIONS]
        reply_markup = ReplyKeyboardMarkup(
            keyboard,
            one_time_keyboard=True,
            resize_keyboard=True
        )
        await update.message.reply_text(
            "Выберите ваш объект:",
            reply_markup=reply_markup
        )
        return LOCATION

    except Exception as e:
        logger.error(f"Критическая ошибка в get_full_name: {e}", exc_info=True)
        await update.message.reply_text(
            "⚠️ Произошла системная ошибка. Попробуйте позже.",
            reply_markup=ReplyKeyboardRemove()
        )
        return ConversationHandler.END

async def get_location(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        user_id = update.effective_user.id
        
        location = update.message.text
        if location not in LOCATIONS:
            await update.message.reply_text("Пожалуйста, выберите объект из списка.")
            return LOCATION
            
        user = update.effective_user
        try:
            db.cursor.execute(
                "INSERT INTO users (telegram_id, full_name, phone, location, is_verified, username) "
                "VALUES (?, ?, ?, ?, TRUE, ?)",
                (user.id, context.user_data['full_name'], context.user_data['phone'], 
                 location, user.username or "")
            )
            db.conn.commit()
            logger.info(f"Пользователь {user.id} успешно зарегистрирован")
            return await show_main_menu(update, user_id)
        except sqlite3.IntegrityError as e:
            if "UNIQUE constraint failed" in str(e):
                await update.message.reply_text("❌ Этот пользователь уже зарегистрирован")
                return ConversationHandler.END
            raise e
    except Exception as e:
        logger.error(f"Ошибка в get_location: {e}")
        await update.message.reply_text("Произошла ошибка. Попробуйте снова.")
        return LOCATION



# === report_handlers.py ===

import logging
from datetime import datetime, timedelta
from telegram import Update, ReplyKeyboardMarkup, ReplyKeyboardRemove
from telegram.ext import ContextTypes
from .common import show_main_menu
from .states import SELECT_MONTH_RANGE
from .base_handlers import show_main_menu
from admin import export_orders_for_provider, export_accounting_report
from config import TIMEZONE, CONFIG
from keyboards import create_main_menu_keyboard

logger = logging.getLogger(__name__)

async def handle_admin_report(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text
    if text == "📊 Отчет за день":
        await export_accounting_report(update, context)  # Детализированный
    elif text == "📅 Отчет за месяц":
        # Показываем клавиатуру выбора месяца
        await update.message.reply_text(
            "Выберите период:",
            reply_markup=ReplyKeyboardMarkup([
                ["Текущий месяц", "Прошлый месяц"],
                ["Отмена"]
            ], resize_keyboard=True)
        )
        return SELECT_MONTH_RANGE

async def select_month_range(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        user = update.effective_user
        user_id = user.id
        text = update.message.text
        
        # Убираем дублирующуюся проверку в начале
        if text == "Вернуться в главное меню":
            return await show_main_menu(update, user_id)

        # Исправлено: используем user_id вместо user.id
        logger.info(f"User ID: {user_id}")
        logger.info(f"Admin IDs: {CONFIG['admin_ids']}")
        logger.info(f"Provider IDs: {CONFIG['provider_ids']}")
        logger.info(f"Accounting IDs: {CONFIG['accounting_ids']}")
        logger.info(f"Обработка периода: {text}, report_type: {context.user_data.get('report_type')}")

        # Определяем клавиатуру один раз
        reply_markup = ReplyKeyboardMarkup(
            [["Текущий месяц", "Прошлый месяц"], 
             ["Вернуться в главное меню"]],
            resize_keyboard=True
        )

        # Проверяем валидность ввода
        if text not in ["Текущий месяц", "Прошлый месяц"]:
            await update.message.reply_text(
                "Пожалуйста, выберите период:",
                reply_markup=reply_markup
            )
            return SELECT_MONTH_RANGE

        # Получаем тип отчета
        report_type = context.user_data.get('report_type')
        if not report_type:
            await update.message.reply_text(
                "Ошибка: тип отчета не определен",
                reply_markup=ReplyKeyboardRemove()
            )
            return await show_main_menu(update, user_id)

        logger.info(f"Обработка выбора периода: {text}")

        # Определяем даты
        now = datetime.now(TIMEZONE)
        if text == "Текущий месяц":
            start_date = now.replace(day=1).date()
            end_date = now.date()
        elif text == "Прошлый месяц":
            first_day = now.replace(day=1)
            last_day_prev_month = first_day - timedelta(days=1)
            start_date = last_day_prev_month.replace(day=1).date()
            end_date = last_day_prev_month.date()
        else:
            # Этот else технически недостижим из-за предыдущей проверки
            await update.message.reply_text("Неизвестный период")
            return await show_main_menu(update, user_id)

        logger.info(f"Формирование отчета {report_type} за {start_date} - {end_date}")

        # Формируем отчет
        try:
            if report_type == 'provider':
                await export_orders_for_provider(update, context, start_date, end_date)
            else:
                await export_accounting_report(update, context, start_date, end_date)
        except Exception as e:
            logger.error(f"Ошибка формирования отчета: {e}")
            await update.message.reply_text(
                "❌ Не удалось сформировать отчет",
                reply_markup=ReplyKeyboardMarkup(
                    create_main_menu_keyboard(user_id),  # Используем user_id
                    resize_keyboard=True
                )
            )
            return await show_main_menu(update, user_id)  # Добавлен return

        return await show_main_menu(update, user_id)

    except Exception as e:
        logger.error(f"Критическая ошибка в select_month_range: {e}", exc_info=True)
        await update.message.reply_text("⚠️ Произошла системная ошибка")
        return await show_main_menu(update, user_id)


# === states.py ===

# Состояния диалога (для ConversationHandler)
(
    PHONE, FULL_NAME, LOCATION, MAIN_MENU,
    ORDER_ACTION, ORDER_CONFIRMATION, SELECT_MONTH_RANGE,
    BROADCAST_MESSAGE, AWAIT_MESSAGE_TEXT, AWAIT_USER_SELECTION
) = range(10)

# Константы для состояний
SELECT_MONTH_RANGE_STATS = 'select_month_range_stats'
ORDER_ACTION = "ORDER_ACTION"
BROADCAST_MESSAGE = 'broadcast_message'


# === __init__.py ===

from datetime import datetime, timedelta
from telegram import Update
from config import CONFIG
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,  # Добавлен этот импорт
    CallbackQueryHandler,
    ConversationHandler,
    filters,
    ContextTypes
)

# Импорты локальных модулей
from .common import show_main_menu
from .message_handlers import (
    setup_message_handlers,
    start_user_to_admin_message,
    process_broadcast_message,
    handle_broadcast_command,
    handle_user_message,
    handle_user_selection,
    handle_admin_message
)
from .base_handlers import (
    start,
    error_handler,
    test_connection,
    main_menu,
    handle_text_message,
    handle_registered_user
)
from .registration_handlers import (
    get_phone,
    get_full_name,
    get_location
)
from .menu_handlers import (
    show_today_menu,
    show_week_menu,
    view_orders,
    monthly_stats,
    handle_order_confirmation,
    order_action,
    monthly_stats_selected
)
from .callback_handlers import (
    callback_handler,
    handle_order_callback,
    handle_change_callback,
    handle_cancel_callback
)
from .admin_handlers import (
    handle_admin_choice
)
from .report_handlers import select_month_range

# Состояния диалога
from .states import (
    PHONE,
    FULL_NAME,
    LOCATION,
    MAIN_MENU,
    ORDER_ACTION,
    ORDER_CONFIRMATION,
    SELECT_MONTH_RANGE,
    BROADCAST_MESSAGE,
    AWAIT_MESSAGE_TEXT,
    AWAIT_USER_SELECTION
)

# Константы для новых состояний
SELECT_MONTH_RANGE_STATS = 'select_month_range_stats'
AWAIT_USER_SELECTION = 'handle_user_selection'

def setup_handlers(application):
    # 1. Обработчик рассылки (добавляется ПЕРВЫМ)
    broadcast_handler = ConversationHandler(
        entry_points=[MessageHandler(
            filters.Regex("^📢 Сделать рассылку$") & 
            filters.User(user_id=CONFIG['admin_ids']),
            handle_broadcast_command
        )],
        states={
            AWAIT_MESSAGE_TEXT: [MessageHandler(
                filters.TEXT & ~filters.COMMAND,
                process_broadcast_message
            )]
        },
        fallbacks=[
            CommandHandler('cancel', lambda u, c: show_main_menu(u, u.effective_user.id)),
            MessageHandler(filters.Regex("^(❌ Отмена|Отмена)$"), 
                        lambda u, c: show_main_menu(u, u.effective_user.id))
        ],
        allow_reentry=True
    )
    application.add_handler(broadcast_handler)

    # 2. Основные обработчики сообщений
    from handlers.message_handlers import setup_message_handlers
    setup_message_handlers(application)
    
    # 3. Основной ConversationHandler
    conv_handler = ConversationHandler(
        entry_points=[
            CommandHandler('start', start),
            MessageHandler(filters.Regex("^Статистика за месяц$"), monthly_stats),
            MessageHandler(filters.Regex("^Админ-панель$"), handle_admin_choice),
            MessageHandler(filters.Regex("^Написать администратору$"), start_user_to_admin_message),
        ],
        states={
            SELECT_MONTH_RANGE_STATS: [
                MessageHandler(
                    filters.Regex("^(Текущий месяц|Прошлый месяц|Вернуться в главное меню)$"),
                    monthly_stats_selected
                )
            ],
            PHONE: [MessageHandler(filters.CONTACT, get_phone)],
            FULL_NAME: [MessageHandler(filters.TEXT & ~filters.COMMAND, get_full_name)],
            LOCATION: [MessageHandler(filters.TEXT & ~filters.COMMAND, get_location)],
            MAIN_MENU: [MessageHandler(filters.TEXT & ~filters.COMMAND, main_menu)],
            ORDER_ACTION: [CallbackQueryHandler(callback_handler)],
            ORDER_CONFIRMATION: [MessageHandler(filters.TEXT & ~filters.COMMAND, handle_order_confirmation)],
            SELECT_MONTH_RANGE: [
                MessageHandler(filters.Regex(r'^(Текущий месяц|Прошлый месяц)$'), select_month_range),
                MessageHandler(filters.Regex(r'^Вернуться в главное меню$'), show_main_menu)
            ]
        },
        fallbacks=[
            CommandHandler('cancel', lambda u, c: show_main_menu(u, u.effective_user.id)),
            MessageHandler(filters.Regex(r'^(❌ Отмена|Отмена|Вернуться в главное меню|🏠 Главное меню)$'), 
                         lambda u, c: show_main_menu(u, u.effective_user.id))
        ],
        per_chat=True,
        per_user=True,
        allow_reentry=True
    )

    application.add_handler(conv_handler)

    # 4. Обработчик для зарегистрированных пользователей
    application.add_handler(MessageHandler(
        filters.TEXT & ~filters.COMMAND & filters.Regex(
            r'^(Меню на сегодня|Меню на неделю|Просмотреть заказы|Статистика за месяц|'
            r'💰 Бухгалтерский отчет|📦 Отчет поставщика|'
            r'📊 Отчет за день|📅 Отчет за месяц|Обновить меню|Вернуться в главное меню)$'
        ),
        handle_registered_user
    ))

    # 5. CallbackQueryHandler
    application.add_handler(CallbackQueryHandler(callback_handler))

    # 6. Обработчик всех текстовых сообщений (кроме команд)
    application.add_handler(
        MessageHandler(
            filters.TEXT & ~filters.COMMAND,
            handle_text_message
        )
    )

    # 7. Обработчик ошибок
    application.add_error_handler(error_handler)



# === admin.py ===

import openpyxl
from datetime import datetime, date, timedelta
from telegram import Update, ReplyKeyboardMarkup
from telegram.ext import ContextTypes
from config import CONFIG, TIMEZONE
from db import db
import logging
from keyboards import create_main_menu_keyboard
from openpyxl.styles import Font
import sqlite3
from handlers.states import MAIN_MENU
from handlers.report_handlers import SELECT_MONTH_RANGE
from handlers.common import show_main_menu
from typing import Optional, Union, List, Dict, Any, Tuple, Callable
import os
from openpyxl import Workbook
from openpyxl.styles import Font
import logging

import logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    filename='bot.log'
)
logger = logging.getLogger(__name__)

async def export_orders_for_provider(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
    start_date: Optional[date] = None,
    end_date: Optional[date] = None
):
    """
    Формирует Excel-файл с отчётом для поставщиков.
    Включает детализацию по дням и объектам.
    Учитываются только неотменённые заказы.
    """

    try:
        user = update.effective_user

        # Если даты не заданы — используем сегодняшнюю
        if not start_date or not end_date:
            today = datetime.now(TIMEZONE).date()
            start_date = end_date = today
        else:
            start_date = start_date if isinstance(start_date, date) else start_date.date()
            end_date = end_date if isinstance(end_date, date) else end_date.date()

        wb = openpyxl.Workbook()

        # 1. Лист "Заказы"
        ws_orders = wb.active
        ws_orders.title = "Заказы"
        orders_headers = ["Дата", "Локация", "Количество порций"]
        ws_orders.append(orders_headers)
        ws_orders.auto_filter.ref = "A1:C1"

        total_portions = 0

        # SQL-запрос: заказы по дням и локациям
        db.cursor.execute('''
            SELECT 
                o.target_date,
                u.location,
                SUM(o.quantity)
            FROM orders o
            JOIN users u ON o.user_id = u.id
            WHERE o.target_date BETWEEN ? AND ?
              AND o.is_cancelled = FALSE
            GROUP BY o.target_date, u.location
            ORDER BY o.target_date, u.location
        ''', (start_date.isoformat(), end_date.isoformat()))

        for row in db.cursor.fetchall():
            formatted_date = datetime.strptime(row[0], "%Y-%m-%d").strftime("%d.%m.%Y")
            ws_orders.append([formatted_date, row[1], row[2]])
            total_portions += row[2]

        # 2. Лист "Сводка по объектам"
        valid_locations = {"Офис", "ПЦ 1", "ПЦ 2", "Склад"}
        ws_summary = wb.create_sheet("Сводка по объектам")
        summary_headers = ["Объект", "Количество порций"]
        ws_summary.append(summary_headers)
        ws_summary.auto_filter.ref = "A1:B1"

        # Получаем данные по локациям
        db.cursor.execute('''
            SELECT u.location, SUM(o.quantity)
            FROM orders o
            JOIN users u ON o.user_id = u.id
            WHERE o.target_date BETWEEN ? AND ?
              AND o.is_cancelled = FALSE
            GROUP BY u.location
        ''', (start_date.isoformat(), end_date.isoformat()))

        location_data = dict(db.cursor.fetchall())

        for loc in sorted(valid_locations):
            portions = location_data.get(loc, 0)
            ws_summary.append([loc, portions])

        # 3. Лист "Итоги"
        ws_stats = wb.create_sheet("Итоги")
        stats_headers = ["Показатель", "Значение"]
        ws_stats.append(stats_headers)

        # Подсчёт уникальных локаций с заказами
        db.cursor.execute('''
            SELECT DISTINCT u.location
            FROM orders o
            JOIN users u ON o.user_id = u.id
            WHERE o.target_date BETWEEN ? AND ?
              AND o.is_cancelled = FALSE
        ''', (start_date.isoformat(), end_date.isoformat()))
        unique_locations = [row[0] for row in db.cursor.fetchall() if row[0] in valid_locations]
        locations_count = len(unique_locations)

        stats_data = [
            ["Период", f"{start_date.strftime('%d.%m.%Y')} — {end_date.strftime('%d.%m.%Y')}"],
            ["Всего порций", total_portions],
            ["Уникальных локаций", locations_count],
            ["Дата формирования", datetime.now(TIMEZONE).strftime("%d.%m.%Y %H:%M")]
        ]
        for row in stats_data:
            ws_stats.append(row)

        # Форматирование
        bold_font = Font(bold=True)
        for sheet in wb.worksheets:
            for row in sheet.iter_rows(min_row=1, max_row=1):
                for cell in row:
                    cell.font = bold_font
            for column in sheet.columns:
                max_length = max((len(str(cell.value)) if cell.value else 0 for cell in column), default=0)
                adjusted_width = (max_length + 2) * 1.2
                sheet.column_dimensions[column[0].column_letter].width = adjusted_width

        # Сохраняем файл
        file_path = f"provider_report_{start_date.strftime('%Y%m%d')}"
        if start_date != end_date:
            file_path += f"_to_{end_date.strftime('%Y%m%d')}"
        file_path += ".xlsx"
        wb.save(file_path)

        # Отправляем файл
        caption = (
            f"🍽 Заказы на {start_date.strftime('%d.%m.%Y')}"
            f"{f' — {end_date.strftime('%d.%m.%Y')}' if start_date != end_date else ''}\n"
            f"📍 Локаций: {locations_count} | 🍛 Всего: {total_portions} порций\n"
            "📋 Детализация в приложенном файле"
        )

        with open(file_path, 'rb') as file:
            await context.bot.send_document(
                chat_id=update.effective_chat.id,
                document=file,
                caption=caption
            )

        return file_path

    except Exception as e:
        logger.error(f"Ошибка при создании отчета для поставщика: {e}", exc_info=True)
        await update.message.reply_text("❌ Ошибка при формировании отчёта.")
        raise

async def export_accounting_report(update: Update, context: ContextTypes.DEFAULT_TYPE, 
                                 start_date=None, end_date=None):
    """Генерация отчёта с правильными датами"""
    try:
        now = datetime.now(TIMEZONE)
        
        # Если даты не указаны - отчёт за сегодня
        if not start_date or not end_date:
            start_date = now.date()
            end_date = now.date()

        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "Заказы"
        
        # Заголовки
        headers = [
            "ФИО", "Объект", 
            "Дата заказа", "Время заказа",  # Когда сделан заказ
            "Дата обеда",                   # На какую дату заказ
            "Количество", "Тип заказа", 
            "Статус"
        ]
        ws.append(headers)

        # Получаем данные
        db.cursor.execute('''
            SELECT 
                u.full_name,
                u.location,
                date(o.created_at) as target_date,
                time(o.created_at) as order_time,
                o.target_date,
                o.quantity,
                CASE WHEN o.is_preliminary THEN 'Предзаказ' ELSE 'Обычный' END,
                CASE WHEN o.is_cancelled THEN 'Отменён' ELSE 'Активен' END
            FROM orders o
            JOIN users u ON o.user_id = u.id
            WHERE date(o.created_at) BETWEEN ? AND ?
            ORDER BY o.target_date, u.full_name
        ''', (start_date.isoformat(), end_date.isoformat()))

        for row in db.cursor.fetchall():
            # Форматируем даты для отчёта
            formatted_row = list(row)
            formatted_row[2] = datetime.strptime(row[2], "%Y-%m-%d").strftime("%d.%m.%Y")  # Дата заказа
            formatted_row[4] = datetime.strptime(row[4], "%Y-%m-%d").strftime("%d.%m.%Y")  # Дата обеда
            ws.append(formatted_row)

        # Сохраняем и отправляем файл
        file_path = f"report_{now.strftime('%Y%m%d_%H%M')}.xlsx"
        wb.save(file_path)
        
        with open(file_path, 'rb') as file:
            await update.message.reply_document(
                document=file,
                caption=f"Отчёт за период: {start_date.strftime('%d.%m.%Y')} - {end_date.strftime('%d.%m.%Y')}"
            )
            
    except Exception as e:
        logger.error(f"Ошибка формирования отчёта: {e}")
        await update.message.reply_text("❌ Ошибка при формировании отчёта")
        
# Добавьте эту новую функцию
async def export_orders_for_month(
    update: Update = None, 
    context: ContextTypes.DEFAULT_TYPE = None,
    start_date: date = None,
    end_date: date = None,
    month_offset: int = 0,
    send_to_providers: bool = False
):
    """
    Генерация отчета за месяц/период
    :param update: Объект Update (опционально)
    :param context: Контекст (опционально)
    :param start_date: Начальная дата (если None - будет месяц)
    :param end_date: Конечная дата (если None - будет месяц)
    :param month_offset: Смещение месяца (0 - текущий, -1 - предыдущий)
    :param send_to_providers: Отправлять ли отчет поставщикам
    :return: Путь к файлу или None при ошибке
    """
    try:
        now = datetime.now(TIMEZONE)
        
        # Определяем период
        if start_date is None or end_date is None:
            if month_offset == -1:  # Предыдущий месяц
                first_day = now.replace(day=1)
                start_date = (first_day - timedelta(days=1)).replace(day=1)
                end_date = first_day - timedelta(days=1)
            else:  # Текущий месяц
                start_date = now.replace(day=1)
                end_date = now
        
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "Заказы"
        
        # Заголовки
        headers = ["Объект", "Количество порций"]
        ws.append(headers)
        
        # Получаем данные
        db.cursor.execute('''
            SELECT u.location, SUM(o.quantity) AS portions
            FROM orders o
            JOIN users u ON o.user_id = u.id
            WHERE o.target_date BETWEEN ? AND ?
            GROUP BY u.location
            ORDER BY portions DESC
        ''', (start_date.isoformat(), end_date.isoformat()))
        
        total = 0
        for location, portions in db.cursor.fetchall():
            ws.append([location, portions])
            total += portions
        
        ws.append(["ИТОГО", total])
        
        # Автоподбор ширины столбцов
        for col in ws.columns:
            max_len = max(len(str(cell.value)) for cell in col)
            ws.column_dimensions[col[0].column_letter].width = (max_len + 2) * 1.2
        
        # Сохраняем файл
        if month_offset != 0:
            file_path = f"orders_report_{start_date.strftime('%Y-%m')}.xlsx"
        else:
            file_path = f"orders_report_{start_date.strftime('%Y-%m-%d')}_to_{end_date.strftime('%Y-%m-%d')}.xlsx"
        wb.save(file_path)
        
        # Если вызывается из обработчика - отправляем отчет
        if update and context:
            if send_to_providers:
                success = 0
                with open(file_path, 'rb') as file:
                    for provider_id in CONFIG['provider_ids']:
                        try:
                            await context.bot.send_document(
                                chat_id=provider_id,
                                document=file,
                                caption=(
                                    f"🍽 Заказы за период {start_date.strftime('%d.%m.%Y')} - {end_date.strftime('%d.%m.%Y')}\n"
                                    f"📍 Локации | 🍛 Всего: {total} порций"
                                )
                            )
                            success += 1
                            file.seek(0)
                        except Exception as e:
                            logger.error(f"Ошибка отправки поставщику {provider_id}: {e}")
                
                await update.message.reply_text(
                    f"✅ Отчёт готов\n"
                    f"• Период: {start_date.strftime('%d.%m.%Y')} - {end_date.strftime('%d.%m.%Y')}\n"
                    f"• Порций: {total}\n"
                    f"• Отправлено: {success}/{len(CONFIG['provider_ids'])}"
                )
            else:
                with open(file_path, 'rb') as file:
                    await update.message.reply_document(
                        document=file,
                        caption=f"Отчет за период {start_date.strftime('%d.%m.%Y')} - {end_date.strftime('%d.%m.%Y')}"
                    )
            
            return await show_main_menu(update, update.effective_user.id)
        
        return file_path
        
    except Exception as e:
        logger.error(f"Ошибка формирования отчёта: {e}")
        if update:
            await update.message.reply_text("❌ Ошибка при создании отчёта")
            return await show_main_menu(update, update.effective_user.id)
        raise

async def export_monthly_report(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        if update.effective_user.id not in CONFIG['admin_ids']:
            await update.message.reply_text("❌ У вас нет прав для выполнения этой команды.")
            return

        wb = openpyxl.Workbook()
        
        ws_detailed = wb.active
        ws_detailed.title = "Детализация"
        ws_detailed.append(["ФИО", "Локация", "Дата", "Порции", "Тип"])
        
        ws_summary = wb.create_sheet("Итоги")
        ws_summary.append(["Локация", "Порции"])
        
        month_start = datetime.now(TIMEZONE).replace(day=1).date()
        
        db.cursor.execute('''
            SELECT u.full_name, u.location, o.target_date, o.quantity, 
                   CASE WHEN o.is_preliminary THEN 'Предзаказ' ELSE 'Обычный' END
            FROM orders o
            JOIN users u ON o.user_id = u.id
            WHERE o.target_date BETWEEN ? AND date('now')
            ORDER BY o.target_date, u.location
        ''', (month_start.isoformat(),))
        
        for row in db.cursor.fetchall():
            ws_detailed.append(row)
        
        db.cursor.execute('''
            SELECT u.location, SUM(o.quantity)
            FROM orders o
            JOIN users u ON o.user_id = u.id
            WHERE o.target_date BETWEEN ? AND date('now')
            GROUP BY u.location
        ''', (month_start.isoformat(),))
        
        total = 0
        for location, portions in db.cursor.fetchall():
            ws_summary.append([location, portions])
            total += portions
        
        ws_summary.append(["ВСЕГО", total])
        
        for sheet in wb.worksheets:
            for col in sheet.columns:
                sheet.column_dimensions[col[0].column_letter].width = max(
                    len(str(cell.value)) * 1.2 for cell in col
                )

        file_path = f"monthly_report_{datetime.now(TIMEZONE).strftime('%Y-%m')}.xlsx"
        wb.save(file_path)
        
        with open(file_path, 'rb') as file:
            await context.bot.send_document(
                chat_id=update.effective_chat.id,
                document=file,
                caption=f"📅 Отчёт за {month_start.strftime('%B %Y')}\n"
                       f"🍽 Всего порций: {total}"
            )

    except Exception as e:
        logger.error(f"Ошибка месячного отчёта: {e}")
        await update.message.reply_text("❌ Ошибка формирования отчёта")

async def message_history(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Показ истории сообщений админам"""
    user = update.effective_user
    if user.id not in CONFIG.get('admin_ids', []):
        await update.message.reply_text("❌ У вас нет прав для просмотра истории сообщений.")
        return ADMIN_MESSAGE

    try:
        db.cursor.execute("""
            SELECT m.sent_at, u1.full_name AS admin, u2.full_name AS user, m.message_text
            FROM admin_messages m
            JOIN users u1 ON m.admin_id = u1.telegram_id
            LEFT JOIN users u2 ON m.user_id = u2.telegram_id
            ORDER BY m.sent_at DESC LIMIT 20
        """)
        messages = db.cursor.fetchall()

        if not messages:
            await update.message.reply_text("📜 История сообщений пуста")
            return ADMIN_MESSAGE

        response = "📜 Последние сообщения:\n\n"
        for msg in messages:
            sent_at, admin, user_name, message, *rest = msg
            user_part = f"👤 {user_name}" if user_name else "👥 Всем"
            response += f"🕒 {sent_at}\n🧑‍💼 Админ: {admin}\n{user_part}\n📝 Текст: {message}\n\n"

        await update.message.reply_text(response[:4096])
    except Exception as e:
        logger.error(f"Ошибка при выводе истории: {e}")
        await update.message.reply_text("❌ Не удалось загрузить историю сообщений")
    return ADMIN_MESSAGE

async def handle_export_orders_for_month(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка нажатия кнопки 'Выгрузить заказы за месяц'"""
    if update.effective_user.id not in CONFIG['provider_ids']:
        await update.message.reply_text("❌ У вас нет прав для выполнения этой команды.")
        return MAIN_MENU

    keyboard = [["Текущий месяц"], ["Прошлый месяц"], ["Вернуться в главное меню"]]
    reply_markup = ReplyKeyboardMarkup(keyboard, resize_keyboard=True)
    await update.message.reply_text("Выберите период для выгрузки:", reply_markup=reply_markup)
    return SELECT_MONTH_RANGE



# === bot_core.py ===

from telegram.ext import ApplicationBuilder, PicklePersistence
from handlers import setup_handlers
from config import CONFIG
from cron_jobs import setup_cron_jobs
import logging
import asyncio

logger = logging.getLogger(__name__)

class LunchBot:
    def __init__(self):
        self._running = False
        self.persistence = PicklePersistence(filepath='bot_persistence.pickle')
        self.application = (
            ApplicationBuilder()
            .token(CONFIG['token'])
            .persistence(persistence=self.persistence)
            .read_timeout(30)
            .write_timeout(30)
            .connect_timeout(30)
            .pool_timeout(30)
            .get_updates_read_timeout(30)
            .http_version('1.1')
            .build()
        )
        setup_handlers(self.application)
        self.updater = None

    async def run(self):
        self._running = True
        try:
            await self.application.initialize()
            await self.application.start()
            
            # Запускаем long polling
            self.updater = self.application.updater
            if self.updater:
                await self.updater.start_polling()
            
            await setup_cron_jobs(self.application)
            logger.info("Бот запущен и готов к работе")
            
            # Бесконечный цикл обработки
            while self._running:
                await asyncio.sleep(0.1)
                
        except Exception as e:
            logger.error(f"Ошибка в работе бота: {e}")
            raise
        finally:
            await self.stop()

    async def stop(self):
        if not self._running:
            return
            
        self._running = False
        try:
            if self.updater and self.updater.running:
                await self.updater.stop()
            
            await self.application.stop()
            await self.application.shutdown()
            logger.info("Бот корректно остановлен")
            
        except Exception as e:
            logger.error(f"Ошибка при остановке: {e}")
            raise



# === config.py ===

import os
import openpyxl
import pytz
import logging
import json
from datetime import datetime

logger = logging.getLogger(__name__)

# Общие настройки
TIMEZONE = pytz.timezone('Europe/Moscow')
CONFIG_FILE = "config.xlsx"
LOCATIONS = ["Офис", "ПЦ 1", "ПЦ 2", "Склад"]

def load_config():
    try:
        if not os.path.exists(CONFIG_FILE):
            raise FileNotFoundError(f"Файл конфигурации {CONFIG_FILE} не найден")
        
        wb = openpyxl.load_workbook(CONFIG_FILE)
        ws = wb.active
        
        # Основные настройки (токен, ID)
        token = ws['A2'].value
        if not token:
            raise ValueError("Токен бота не указан в ячейке A2")
        
        admin_ids = [int(cell.value) for cell in ws['B'][1:] if cell.value is not None]
        provider_ids = [int(cell.value) for cell in ws['C'][1:] if cell.value is not None]
        accounting_ids = [int(cell.value) for cell in ws['D'][1:] if cell.value is not None]
        
        # Сотрудники (столбец G)
        staff_names = set()
        for row in ws.iter_rows(min_row=2, max_col=7, values_only=True):
            if row[6]:  # столбец G (индекс 6)
                name = ' '.join(str(row[6]).strip().split()).lower()
                staff_names.add(name)
                
                parts = name.split()
                if len(parts) >= 2:
                    reversed_name = f"{parts[1]} {parts[0]}"
                    if len(parts) > 2:
                        reversed_name += " " + " ".join(parts[2:])
                    staff_names.add(reversed_name)
        
        # Праздники (столбцы K и L)
        holidays = {}
        for row in ws.iter_rows(min_row=2, values_only=True):
            if row[10] and row[11]:  # столбцы K (индекс 10) и L (индекс 11)
                try:
                    date_str = str(row[10]).strip()
                    try:
                        date_obj = datetime.strptime(date_str, "%Y-%m-%d").date()
                    except ValueError:
                        date_obj = datetime.strptime(date_str, "%d.%m.%Y").date()
                    holidays[date_obj.strftime("%Y-%m-%d")] = str(row[11]).strip()
                except Exception as e:
                    logger.warning(f"Не удалось обработать дату праздника: {row[10]}. Ошибка: {e}")
        
        # Меню (столбец I)
        menu = {}
        current_day = None
        dish_counter = 0
        
        # Начинаем с I2 (пропускаем заголовок)
        for row in range(2, ws.max_row + 1):
            cell_value = ws[f'I{row}'].value
            
            # Пропускаем пустые ячейки
            if cell_value is None:
                continue
                
            cell_value = str(cell_value).strip()
            
            # Определяем день недели
            if cell_value in ["Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", "Воскресенье"]:
                current_day = cell_value
                menu[current_day] = {
                    "first": "",
                    "main": "",
                    "salad": ""
                }
                dish_counter = 0
                continue
                
            # Заполняем блюда для текущего дня
            if current_day:
                if dish_counter == 0:
                    menu[current_day]["first"] = cell_value
                elif dish_counter == 1:
                    menu[current_day]["main"] = cell_value
                elif dish_counter == 2:
                    menu[current_day]["salad"] = cell_value
                
                dish_counter += 1

        # Добавляем отсутствующие дни как None
        all_days = ["Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", "Воскресенье"]
        for day in all_days:
            if day not in menu:
                menu[day] = None

        logger.info(f"Загруженное меню:\n{json.dumps(menu, indent=2, ensure_ascii=False)}")
        
        return {
            'token': token,
            'admin_ids': admin_ids,
            'provider_ids': provider_ids,
            'accounting_ids': accounting_ids,
            'staff_names': staff_names,
            'holidays': holidays,
            'menu': menu
        }
    except Exception as e:
        logger.error(f"Критическая ошибка загрузки конфигурации: {e}", exc_info=True)
        raise

def parse_menu_text(menu_text):
    """Парсит текстовое меню в структуру MENU"""
    menu = {}
    current_day = None
    dish_type = 0  # 0=first, 1=main, 2=salad
    
    for line in menu_text.split('\n'):
        line = line.strip()
        if not line:
            continue
            
        if line in ["Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", "Воскресенье"]:
            current_day = line
            menu[current_day] = {"first": "", "main": "", "salad": ""}
            dish_type = 0
        elif current_day:
            if dish_type == 0:
                menu[current_day]["first"] = line
                dish_type += 1
            elif dish_type == 1:
                menu[current_day]["main"] = line
                dish_type += 1
            elif dish_type == 2:
                menu[current_day]["salad"] = line
                dish_type = 0
    
    # Добавляем отсутствующие дни как None
    all_days = ["Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", "Воскресенье"]
    for day in all_days:
        if day not in menu:
            menu[day] = None
            
    return menu

# Загружаем конфигурацию при старте
try:
    CONFIG = load_config()
    TOKEN = CONFIG['token']
    ADMIN_IDS = CONFIG['admin_ids']
    PROVIDER_IDS = CONFIG['provider_ids']
    ACCOUNTING_IDS = CONFIG['accounting_ids']
    STAFF_NAMES = CONFIG['staff_names']
    HOLIDAYS = CONFIG.get('holidays', {})
    MENU = CONFIG['menu']
except Exception as e:
    logger.error(f"Не удалось загрузить конфигурацию: {e}")
    exit(1)



# === cron_jobs.py ===

import aiocron
from config import TIMEZONE, CONFIG
from datetime import datetime, timedelta
import logging
from db import db
from admin import export_accounting_report
from telegram.ext import ContextTypes
import openpyxl

logger = logging.getLogger(__name__)

async def send_reminder_to_users(application):
    try:
        now = datetime.now(TIMEZONE)
        
        if now.weekday() < 5:  # Пн-Пт
            logger.info(f"Запуск напоминаний в {now}")
            
            db.cursor.execute("""
                SELECT telegram_id 
                FROM users 
                WHERE is_verified = TRUE 
                AND telegram_id NOT IN (
                    SELECT u.telegram_id 
                    FROM users u 
                    JOIN orders o ON u.id = o.user_id 
                    WHERE o.order_date = ? AND o.is_preliminary = FALSE
                )
            """, (now.date().isoformat(),))
            
            users = db.cursor.fetchall()
            logger.info(f"Найдено {len(users)} пользователей без заказов")
            
            for user in users:
                user_id = user[0]
                try:
                    await application.bot.send_message(
                        chat_id=user_id,
                        text="⏰ *Не забудьте заказать обед!* 🍽\n\n"
                             "Прием заказов открыт до 9:30.\n\n"
                             "Заказы принимаются через *БИТРИКС*, бот в тестовом режиме!",
                        parse_mode="Markdown"
                    )
                except Exception as e:
                    logger.error(f"Ошибка при отправке напоминания пользователю {user_id}: {e}")
                    
    except Exception as e:
        logger.error(f"Ошибка в send_reminder_to_users: {e}")

async def send_provider_report(application):
    """Отправка ежедневного отчёта поставщикам (в 9:30 по будням)"""
    try:
        logger.info("Запуск отправки отчета поставщикам")

        now = datetime.now(TIMEZONE)
        today = now.date().isoformat()

        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "Заказы на сегодня"
        ws.append(["Объект", "Количество порций"])

        # SQL-запрос: уникальные локации с заказами за сегодня
        db.cursor.execute('''
            SELECT u.location, SUM(o.quantity)
            FROM orders o
            JOIN users u ON o.user_id = u.id
            WHERE o.order_date = ?
              AND o.is_cancelled = FALSE
            GROUP BY u.location
            ORDER BY u.location
        ''', (today,))

        locations_with_orders = []
        total = 0

        for row in db.cursor.fetchall():
            ws.append([row[0], row[1]])
            locations_with_orders.append(row[0])
            total += row[1]

        unique_locations_count = len(locations_with_orders)

        # Автоподбор ширины столбцов
        for col in ws.columns:
            max_length = max((len(str(cell.value)) if cell.value else 0 for cell in col), default=0)
            ws.column_dimensions[col[0].column_letter].width = (max_length + 2) * 1.2

        # Сохраняем файл
        file_path = f"provider_report_{today.replace('-', '')}.xlsx"
        wb.save(file_path)

        # Рассылаем всем поставщикам
        success = 0
        with open(file_path, 'rb') as file:
            for provider_id in CONFIG.get('provider_ids', []):
                try:
                    await application.bot.send_document(
                        chat_id=provider_id,
                        document=file,
                        caption=(
                            f"🍽 Заказы на {now.strftime('%d.%m.%Y')}\n"
                            f"📍 Локаций: {unique_locations_count} | 🍛 Всего: {total} порций\n"
                            "📋 Детализация в приложенном файле"
                        )
                    )
                    success += 1
                    file.seek(0)  # Сброс позиции файла для следующего получателя
                except Exception as e:
                    logger.error(f"Ошибка отправки поставщику {provider_id}: {e}")

        logger.info(f"Отправлено {success}/{len(CONFIG.get('provider_ids', []))} поставщикам")

    except Exception as e:
        logger.error(f"Ошибка отправки отчета поставщикам: {e}")

async def send_accounting_report(application):
    """Отправка ежемесячного отчёта бухгалтерии (в 11:00 последнего дня месяца)"""
    try:
        logger.info("Запуск отправки отчета бухгалтерии")

        now = datetime.now(TIMEZONE)
        today = now.date()

        # Определяем начало и конец месяца
        if today.day == 1:
            # Сегодня первое число — отправляем за предыдущий месяц
            first_day_current_month = now.replace(day=1)
            last_day_prev_month = first_day_current_month - timedelta(days=1)
            start_date = last_day_prev_month.replace(day=1).date()
            end_date = last_day_prev_month.date()
        else:
            # Иначе отправляем за текущий месяц до сегодняшнего числа
            start_date = now.replace(day=1).date()
            end_date = today

        wb = openpyxl.Workbook()

        # 1. Лист "Детализация"
        ws_detailed = wb.active
        ws_detailed.title = "Детализация"
        detailed_headers = ["ФИО", "Объект", "Дата", "Количество", "Тип заказа"]
        ws_detailed.append(detailed_headers)
        ws_detailed.auto_filter.ref = "A1:E1"

        total_portions = 0

        db.cursor.execute('''
            SELECT 
                u.full_name,
                u.location,
                o.order_date,
                o.quantity,
                CASE WHEN o.is_preliminary THEN 'Предзаказ' ELSE 'Обычный' END
            FROM orders o
            JOIN users u ON o.user_id = u.id
            WHERE o.order_date BETWEEN ? AND ?
              AND o.is_cancelled = FALSE
            ORDER BY o.order_date, u.full_name
        ''', (start_date.isoformat(), end_date.isoformat()))

        for row in db.cursor.fetchall():
            formatted_date = datetime.strptime(row[2], "%Y-%m-%d").strftime("%d.%m.%Y")
            ws_detailed.append([
                row[0],  # ФИО
                row[1],  # Объект
                formatted_date,  # Дата
                row[3],  # Количество
                row[4]   # Тип
            ])
            total_portions += row[3]

        # 2. Лист "Сводка по сотрудникам"
        ws_summary_users = wb.create_sheet("Сводка по сотрудникам")
        summary_users_headers = ["ФИО", "Объект", "Всего порций"]
        ws_summary_users.append(summary_users_headers)
        ws_summary_users.auto_filter.ref = "A1:C1"

        db.cursor.execute('''
            SELECT 
                u.full_name,
                u.location,
                SUM(o.quantity)
            FROM orders o
            JOIN users u ON o.user_id = u.id
            WHERE o.order_date BETWEEN ? AND ?
              AND o.is_cancelled = FALSE
            GROUP BY u.full_name, u.location
            ORDER BY SUM(o.quantity) DESC
        ''', (start_date.isoformat(), end_date.isoformat()))

        for row in db.cursor.fetchall():
            ws_summary_users.append(row)

        # 3. Лист "Сводка по объектам"
        ws_summary_locations = wb.create_sheet("Сводка по объектам")
        ws_summary_locations.append(["Объект", "Порции"])
        ws_summary_locations.auto_filter.ref = "A1:B1"

        db.cursor.execute('''
            SELECT u.location, SUM(o.quantity)
            FROM orders o
            JOIN users u ON o.user_id = u.id
            WHERE o.order_date BETWEEN ? AND ?
              AND o.is_cancelled = FALSE
            GROUP BY u.location
            ORDER BY SUM(o.quantity) DESC
        ''', (start_date.isoformat(), end_date.isoformat()))

        for location, portions in db.cursor.fetchall():
            ws_summary_locations.append([location, portions])

        ws_summary_locations.append(["ВСЕГО", total_portions])

        # 4. Лист "Итоги"
        ws_stats = wb.create_sheet("Итоги")
        stats_headers = ["Показатель", "Значение"]
        ws_stats.append(stats_headers)

        stats_data = [
            ["Период", f"{start_date.strftime('%d.%m.%Y')} — {end_date.strftime('%d.%m.%Y')}"],
            ["Всего порций", total_portions],
            ["Уникальных сотрудников", ws_summary_users.max_row - 1],
            ["Дата формирования", datetime.now(TIMEZONE).strftime("%d.%m.%Y %H:%M")]
        ]
        for row in stats_data:
            ws_stats.append(row)

        # Форматирование
        from openpyxl.styles import Font
        bold_font = Font(bold=True)

        for sheet in wb.worksheets:
            # Жирные заголовки
            for row in sheet.iter_rows(min_row=1, max_row=1):
                for cell in row:
                    cell.font = bold_font

            # Автоподбор ширины
            for column in sheet.columns:
                max_length = max((len(str(cell.value)) if cell.value else 0 for cell in column), default=0)
                adjusted_width = (max_length + 2) * 1.2
                sheet.column_dimensions[column[0].column_letter].width = adjusted_width

        # Сохраняем файл
        file_path = f"accounting_report_{start_date.strftime('%Y%m%d')}"
        if start_date != end_date:
            file_path += f"_to_{end_date.strftime('%Y%m%d')}"
        file_path += ".xlsx"
        wb.save(file_path)

        # Отправляем каждому бухгалтеру
        success = 0
        with open(file_path, 'rb') as file:
            for accounting_id in CONFIG.get('accounting_ids', []):
                try:
                    await application.bot.send_document(
                        chat_id=accounting_id,
                        document=file,
                        caption=(
                            f"📊 Бухгалтерский отчет\n"
                            f"📅 Период: {start_date.strftime('%d.%m.%Y')} — {end_date.strftime('%d.%m.%Y')}\n"
                            f"🍽 Всего порций: {total_portions}"
                        )
                    )
                    success += 1
                    file.seek(0)  # Сбрасываем позицию файла для следующего получателя
                except Exception as e:
                    logger.error(f"Ошибка отправки бухгалтеру {accounting_id}: {e}")

        logger.info(f"Отправлено {success}/{len(CONFIG.get('accounting_ids', []))} бухгалтерам")

    except Exception as e:
        logger.error(f"Ошибка при отправке отчета бухгалтерии: {e}", exc_info=True)

async def setup_cron_jobs(application):
    # Напоминание пользователям в 9:00 по будням
    # @aiocron.crontab('* * * * *', tz=TIMEZONE)
    @aiocron.crontab('0 9 * * 1-5', tz=TIMEZONE)
    async def morning_reminder():
        await send_reminder_to_users(application)

    # Отчет поставщикам в 9:30 по рабочим дням
    # @aiocron.crontab('* * * * *', tz=TIMEZONE)
    @aiocron.crontab('30 9 * * 1-5', tz=TIMEZONE)
    async def provider_report():
        await send_provider_report(application)
    
    # Отчет бухгалтерии в 11:00 последнего дня месяца
    # @aiocron.crontab('* * * * *', tz=TIMEZONE)
    @aiocron.crontab('0 11 L * *', tz=TIMEZONE)
    async def accounting_report():
        await send_accounting_report(application)



# === db.py ===

import sqlite3
import logging
from config import CONFIG, TIMEZONE
from datetime import datetime

logger = logging.getLogger(__name__)


class Database:
    def __init__(self):
        self.conn = sqlite3.connect('lunch_bot.db', check_same_thread=False, isolation_level=None)
        self.cursor = self.conn.cursor()
        self._init_db()

    def execute(self, query, params=()):
        """Безопасное выполнение запроса с обработкой транзакций"""
        try:
            self.cursor.execute("BEGIN")
            if not isinstance(params, (tuple, list, dict)):
                raise ValueError("Параметры должны быть кортежем, списком или словарём")
                
            self.cursor.execute(query, params)
            result = self.cursor.fetchall()
            self.conn.commit()
            return result
        except sqlite3.Error as e:
            self.conn.rollback()
            logger.error(f"Ошибка выполнения SQL: {e} | Query: {query} | Params: {params}")
            raise

    def _init_db(self):
        """Создание таблиц и индексов при первом запуске"""
        try:
            # Настройки SQLite
            self.conn.execute("PRAGMA journal_mode=WAL")
            self.conn.execute("PRAGMA synchronous=NORMAL")
            self.conn.execute("PRAGMA busy_timeout=5000")

            # Таблица пользователей
            self.cursor.execute('''
                CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    telegram_id INTEGER UNIQUE NOT NULL,
                    full_name TEXT NOT NULL,
                    phone TEXT NOT NULL,
                    location TEXT NOT NULL,
                    is_verified BOOLEAN DEFAULT FALSE,
                    username TEXT,
                    is_deleted BOOLEAN DEFAULT FALSE,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    updated_at TEXT DEFAULT CURRENT_TIMESTAMP
                )
            ''')

            # Таблица заказов (обновлённая структура)
            self.cursor.execute('''
                CREATE TABLE IF NOT EXISTS orders (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL,
                    target_date TEXT NOT NULL,
                    order_time TEXT NOT NULL,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    quantity INTEGER NOT NULL CHECK(quantity BETWEEN 1 AND 3),
                    is_preliminary BOOLEAN DEFAULT FALSE,
                    is_cancelled BOOLEAN DEFAULT FALSE,
                    FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
                    /* Убрали CHECK с date() */
                )
            ''')

            # Таблица сообщений
            self.cursor.execute('''
                CREATE TABLE IF NOT EXISTS admin_messages (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    sent_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    admin_id INTEGER,
                    user_id INTEGER,
                    message_text TEXT NOT NULL,
                    is_broadcast BOOLEAN DEFAULT FALSE,
                    FOREIGN KEY(admin_id) REFERENCES users(telegram_id),
                    FOREIGN KEY(user_id) REFERENCES users(telegram_id)
                )
            ''')
            
            # Таблица отзывов поставщикам (добавлены NOT NULL constraints)
            self.cursor.execute('''
                CREATE TABLE IF NOT EXISTS feedback_messages (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL,
                    provider_id INTEGER NOT NULL,
                    message_text TEXT NOT NULL,
                    sent_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    is_processed BOOLEAN DEFAULT FALSE,
                    FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
                    FOREIGN KEY(provider_id) REFERENCES users(id) ON DELETE CASCADE
                )
            ''')

            # Создаем индексы (обновлённые)
            with self.conn:
                # Индексы для таблицы users
                self.cursor.execute("CREATE INDEX IF NOT EXISTS idx_users_telegram_id ON users(telegram_id)")
                self.cursor.execute("CREATE INDEX IF NOT EXISTS idx_users_verified ON users(is_verified)")
                
                # Индексы для таблицы orders
                self.cursor.execute("CREATE INDEX IF NOT EXISTS idx_orders_user_id ON orders(user_id)")
                self.cursor.execute("CREATE INDEX IF NOT EXISTS idx_orders_target_date ON orders(target_date)")
                self.cursor.execute("CREATE INDEX IF NOT EXISTS idx_orders_created_at ON orders(created_at)")
                self.cursor.execute("CREATE INDEX IF NOT EXISTS idx_orders_cancelled ON orders(is_cancelled)")
                
                # Индексы для таблицы feedback_messages
                self.cursor.execute("CREATE INDEX IF NOT EXISTS idx_feedback_user_id ON feedback_messages(user_id)")
                self.cursor.execute("CREATE INDEX IF NOT EXISTS idx_feedback_provider_id ON feedback_messages(provider_id)")
                self.cursor.execute("CREATE INDEX IF NOT EXISTS idx_feedback_processed ON feedback_messages(is_processed)")

            logger.info("✅ Все таблицы и индексы созданы корректно")

        except sqlite3.OperationalError as e:
            logger.error(f"❌ Ошибка создания таблиц: {e}")
            raise
        except Exception as e:
            logger.critical(f"⚠️ Критическая ошибка при инициализации БД: {e}")
            raise
            
# Глобальный экземпляр базы данных
db = Database()



# === keyboards.py ===

from telegram import ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardButton, InlineKeyboardMarkup
from config import CONFIG, LOCATIONS

def create_unverified_user_keyboard():
    return ReplyKeyboardMarkup([
        ["Попробовать снова"],
        ["Написать администратору"]
    ], resize_keyboard=True)

def create_main_menu_keyboard(user_id=None):
    menu = [
        ["Меню на сегодня", "Меню на неделю"],
        ["Просмотреть заказы", "Статистика за месяц"],
        ["Написать администратору"]
    ]
    
    if user_id in CONFIG.get('admin_ids', []):
        menu.insert(0, ["📊 Отчет за день", "📅 Отчет за месяц"])
        menu.insert(0, ["✉️ Написать пользователю", "📢 Сделать рассылку"])
    
    if user_id in CONFIG.get('provider_ids', []):
        menu.append(["📦 Отчет поставщика"])
    
    if user_id in CONFIG.get('accounting_ids', []):
        menu.append(["💰 Бухгалтерский отчет"])

    menu.append(["Обновить меню"])

    return ReplyKeyboardMarkup(menu, resize_keyboard=True)

def create_month_selection_keyboard():
    return ReplyKeyboardMarkup([
        ["Текущий месяц"],
        ["Прошлый месяц"],
        ["Вернуться в главное меню"]
    ], resize_keyboard=True)

def create_order_keyboard(has_order):
    if has_order:
        return [
            [InlineKeyboardButton("✏️ Изменить количество", callback_data="change")],
            [InlineKeyboardButton("❌ Отменить заказ", callback_data="cancel")]
        ]
    return [[InlineKeyboardButton("✅ Заказать", callback_data="order")]]

def create_admin_keyboard():
    return ReplyKeyboardMarkup([
        ["📊 Отчет за день", "📅 Отчет за месяц"],
        ["✉️ Написать пользователю", "📢 Сделать рассылку"],
        ["📜 История сообщений"],
        ["🏠 Главное меню"]
    ], resize_keyboard=True)



# === main.py ===

import asyncio
import signal
import platform
from bot_core import LunchBot
import logging
import os
from bot_core import LunchBot
from handlers import setup_handlers  # Импорт из handlers/__init__.py
from telegram.ext import MessageHandler
from config import CONFIG

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    filename='bot.log'
)
import logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    filename='bot.log',
    filemode='a'  # Режим добавления в файл
)
logger = logging.getLogger(__name__)

async def shutdown(bot):
    print("\n🛑 Завершение работы бота...")
    await bot.stop()

async def main():
    # Добавьте для теста
    print("Проверка конфига:")
    print("Admin IDs:", CONFIG['admin_ids'])
    print("Token:", CONFIG['token'][:5] + "...")
    
    bot = LunchBot()
    setup_handlers(bot.application)  # Настройка обработчиков
    await bot.run()
    
    # Настройка обработки Ctrl+C для всех ОС
    if platform.system() == 'Windows':
        # Для Windows используем простой обработчик KeyboardInterrupt
        try:
            task = asyncio.create_task(bot.run())
            await task
        except asyncio.CancelledError:
            await shutdown(bot)
    else:
        # Для Linux/Unix настраиваем обработчики сигналов
        loop = asyncio.get_running_loop()
        for sig in (signal.SIGTERM, signal.SIGINT):
            loop.add_signal_handler(
                sig,
                lambda s=sig: asyncio.create_task(shutdown(bot))
            )
        try:
            await bot.run()
        except asyncio.CancelledError:
            pass  # Обработка уже выполнена в shutdown

    print("✅ Работа бота завершена")

if __name__ == "__main__":
    try:
        if platform.system() == 'Windows':
            # Специальная обработка для Windows
            async def windows_main():
                try:
                    await main()
                except KeyboardInterrupt:
                    print("\n🛑 Принудительное завершение")
            
            asyncio.run(windows_main())
        else:
            asyncio.run(main())
    except KeyboardInterrupt:
        print("\n🛑 Принудительное завершение")
    except Exception as e:
        print(f"❌ Критическая ошибка: {str(e)}")



# === migrate_db.py ===

from db import db

def add_cancelled_column():
    try:
        # Проверяем существование колонки
        db.cursor.execute("PRAGMA table_info(orders)")
        columns = [col[1] for col in db.cursor.fetchall()]
        
        if 'is_cancelled' not in columns:
            db.cursor.execute("ALTER TABLE orders ADD COLUMN is_cancelled BOOLEAN DEFAULT FALSE")
            db.conn.commit()
            print("✅ Колонка is_cancelled успешно добавлена")
        else:
            print("ℹ️ Колонка is_cancelled уже существует")
    except Exception as e:
        print(f"❌ Ошибка миграции: {e}")

if __name__ == "__main__":
    print("Запуск миграции БД...")
    add_cancelled_column()
    print("Миграция завершена")


# === utils.py ===

from telegram import Update, KeyboardButton, ReplyKeyboardMarkup
from telegram.ext import ContextTypes
from config import CONFIG, TIMEZONE, MENU
from db import db
import logging
from datetime import datetime, timedelta, date, time
import pytz

logger = logging.getLogger(__name__)

# Состояния диалога (для handle_unregistered)
PHONE = 0

def is_weekday(date=None):
    if date is None:
        date = datetime.now(TIMEZONE)
    return date.weekday() < 5  # 0-4 = пн-пт

def get_next_workday(date=None):
    if date is None:
        date = datetime.now(TIMEZONE)
    
    days_to_add = 1
    if date.weekday() == 4:  # Пятница
        days_to_add = 3  # Понедельник
    elif date.weekday() == 5:  # Суббота
        days_to_add = 2  # Понедельник
    
    return date + timedelta(days=days_to_add)

def can_modify_order(target_date):
    """Проверяет, можно ли изменять заказ на указанную дату"""
    now = datetime.now(TIMEZONE)
    
    # Если target_date - строка, преобразуем в дату
    if isinstance(target_date, str):
        try:
            target_date = datetime.strptime(target_date, "%Y-%m-%d").date()
        except ValueError:
            logger.error(f"Неверный формат даты: {target_date}")
            return False
    
    # Заказы на выходные невозможны
    if target_date.weekday() >= 5:  # 5-6 = суббота-воскресенье
        return False
    
    # Заказы на будущие дни (предзаказы) можно менять в любое время
    if target_date > now.date():
        return True
    
    # Заказы на сегодня можно менять только до 9:30
    if target_date == now.date():
        return now.time() < time(9, 30)
    
    # Заказы на прошедшие дни нельзя менять
    return False

def is_order_time_expired():
    """Старая функция, оставляем для совместимости, но теперь она использует новую функцию"""
    return not can_modify_order(datetime.now(TIMEZONE).date())

def get_order_time_restriction():
    now = datetime.now(TIMEZONE)
    current_hour = now.hour
    
    if not is_weekday(now):
        next_workday = get_next_workday(now)
        return f"⏳ Сегодня выходной. Вы можете оформить предварительный заказ на {next_workday.strftime('%d.%m')} (понедельник)"
    
    if current_hour >= 10:
        next_workday = get_next_workday(now)
        return f"⏳ Прием заказов на сегодня завершен в 10:00. Вы можете оформить предварительный заказ на {next_workday.strftime('%d.%m')}"
    
    return None

def is_employee(full_name):
    normalized_input = ' '.join(full_name.strip().split()).lower()
    return normalized_input in CONFIG['staff_names']

def get_menu_for_day(day_offset=0):
    now = datetime.now(TIMEZONE)
    days = ["Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", "Воскресенье"]
    target_date = (now + timedelta(days=day_offset)).date()
    day_name = days[target_date.weekday()]
    
    # Проверяем, является ли день праздником
    if target_date.strftime("%Y-%m-%d") in CONFIG.get('holidays', {}):
        return None, day_name
    
    return MENU.get(day_name), day_name

def format_menu(menu, day_name, is_tomorrow=False):
    if not menu:
        return f"На {day_name} выходной! Меню не предусмотрено."
    
    # Получаем текущую дату и вычисляем дату для отображения
    now = datetime.now(TIMEZONE)
    days_ru = ["Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", "Воскресенье"]
    
    # Находим индекс текущего дня и вычисляем дату
    current_day_index = now.weekday()
    target_day_index = days_ru.index(day_name)
    
    # Если день в будущем (например, среда при текущем понедельнике)
    if target_day_index > current_day_index:
        days_diff = target_day_index - current_day_index
    # Если день в прошлом (например, понедельник при текущей среде)
    else:
        days_diff = 7 - (current_day_index - target_day_index)
    
    target_date = (now + timedelta(days=days_diff)).date()
    date_str = target_date.strftime("%d.%m")
    
    return (
        f"🍽 Меню на {day_name} ({date_str}):\n"
        f"1. 🍲 Первое: {menu['first']}\n"
        f"2. 🍛 Основное блюдо: {menu['main']}\n"
        f"3. 🥗 Салат: {menu['salad']}"
    )

async def check_registration(update: Update, context: ContextTypes.DEFAULT_TYPE) -> bool:
    user = update.effective_user
    db.cursor.execute("SELECT is_verified FROM users WHERE telegram_id = ?", (user.id,))
    result = db.cursor.fetchone()
    
    if result:
        logger.info(f"Пользователь {user.id} статус верификации: {result[0]}")
        return bool(result[0])
    
    logger.info(f"Пользователь {user.id} не найден в базе")
    return False

async def handle_unregistered(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    logger.info(f"Незарегистрированный пользователь {user.id} пытается взаимодействовать с ботом")
    
    for admin_id in CONFIG['admin_ids']:
        try:
            await context.bot.send_message(
                chat_id=admin_id,
                text=f"⚠️ Незарегистрированный пользователь пытается использовать бота:\n"
                     f"🆔 ID: {user.id}\n"
                     f"👤 Username: @{user.username if user.username else 'нет'}"
            )
        except Exception as e:
            logger.error(f"Ошибка отправки админу {admin_id}: {e}")
    
    keyboard = [[KeyboardButton("📱 Отправить номер телефона", request_contact=True)]]
    reply_markup = ReplyKeyboardMarkup(keyboard, resize_keyboard=True)
    
    await update.message.reply_text(
        "Вы не завершили регистрацию. Пожалуйста, нажмите кнопку ниже, чтобы отправить номер телефона:",
        reply_markup=reply_markup
    )
    return PHONE

def is_order_cancelled(user_id: int, target_date_str: str, context=None) -> bool:
    """Проверяет, отменён ли заказ (из БД или временного хранилища)"""
    try:
        # Проверка из базы данных
        db.cursor.execute("""
            SELECT is_cancelled FROM orders 
            WHERE user_id = (SELECT id FROM users WHERE telegram_id = ?)
            AND target_date = ?
        """, (user_id, target_date_str))
        
        result = db.cursor.fetchone()
        if result and result[0]:
            return True
            
        # Резервная проверка из контекста
        if context and context.user_data.get('cancelled_orders'):
            return target_date_str in context.user_data['cancelled_orders']
            
        return False
        
    except Exception as e:
        logger.error(f"Ошибка проверки статуса отмены: {e}")
        return False



# === admin.py ===

import openpyxl
from datetime import datetime, date, timedelta
from telegram import Update, ReplyKeyboardMarkup
from telegram.ext import ContextTypes
from config import CONFIG, TIMEZONE
from db import db
import logging
from keyboards import create_main_menu_keyboard
from openpyxl.styles import Font
import sqlite3
from handlers.states import MAIN_MENU
from handlers.report_handlers import SELECT_MONTH_RANGE
from handlers.common import show_main_menu
from typing import Optional, Union, List, Dict, Any, Tuple, Callable
import os
from openpyxl import Workbook
from openpyxl.styles import Font
import logging

import logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    filename='bot.log'
)
logger = logging.getLogger(__name__)

async def export_orders_for_provider(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
    start_date: Optional[date] = None,
    end_date: Optional[date] = None
):
    """
    Формирует Excel-файл с отчётом для поставщиков.
    Включает детализацию по дням и объектам.
    Учитываются только неотменённые заказы.
    """

    try:
        user = update.effective_user

        # Если даты не заданы — используем сегодняшнюю
        if not start_date or not end_date:
            today = datetime.now(TIMEZONE).date()
            start_date = end_date = today
        else:
            start_date = start_date if isinstance(start_date, date) else start_date.date()
            end_date = end_date if isinstance(end_date, date) else end_date.date()

        wb = openpyxl.Workbook()

        # 1. Лист "Заказы"
        ws_orders = wb.active
        ws_orders.title = "Заказы"
        orders_headers = ["Дата", "Локация", "Количество порций"]
        ws_orders.append(orders_headers)
        ws_orders.auto_filter.ref = "A1:C1"

        total_portions = 0

        # SQL-запрос: заказы по дням и локациям
        db.cursor.execute('''
            SELECT 
                o.target_date,
                u.location,
                SUM(o.quantity)
            FROM orders o
            JOIN users u ON o.user_id = u.id
            WHERE o.target_date BETWEEN ? AND ?
              AND o.is_cancelled = FALSE
            GROUP BY o.target_date, u.location
            ORDER BY o.target_date, u.location
        ''', (start_date.isoformat(), end_date.isoformat()))

        for row in db.cursor.fetchall():
            formatted_date = datetime.strptime(row[0], "%Y-%m-%d").strftime("%d.%m.%Y")
            ws_orders.append([formatted_date, row[1], row[2]])
            total_portions += row[2]

        # 2. Лист "Сводка по объектам"
        valid_locations = {"Офис", "ПЦ 1", "ПЦ 2", "Склад"}
        ws_summary = wb.create_sheet("Сводка по объектам")
        summary_headers = ["Объект", "Количество порций"]
        ws_summary.append(summary_headers)
        ws_summary.auto_filter.ref = "A1:B1"

        # Получаем данные по локациям
        db.cursor.execute('''
            SELECT u.location, SUM(o.quantity)
            FROM orders o
            JOIN users u ON o.user_id = u.id
            WHERE o.target_date BETWEEN ? AND ?
              AND o.is_cancelled = FALSE
            GROUP BY u.location
        ''', (start_date.isoformat(), end_date.isoformat()))

        location_data = dict(db.cursor.fetchall())

        for loc in sorted(valid_locations):
            portions = location_data.get(loc, 0)
            ws_summary.append([loc, portions])

        # 3. Лист "Итоги"
        ws_stats = wb.create_sheet("Итоги")
        stats_headers = ["Показатель", "Значение"]
        ws_stats.append(stats_headers)

        # Подсчёт уникальных локаций с заказами
        db.cursor.execute('''
            SELECT DISTINCT u.location
            FROM orders o
            JOIN users u ON o.user_id = u.id
            WHERE o.target_date BETWEEN ? AND ?
              AND o.is_cancelled = FALSE
        ''', (start_date.isoformat(), end_date.isoformat()))
        unique_locations = [row[0] for row in db.cursor.fetchall() if row[0] in valid_locations]
        locations_count = len(unique_locations)

        stats_data = [
            ["Период", f"{start_date.strftime('%d.%m.%Y')} — {end_date.strftime('%d.%m.%Y')}"],
            ["Всего порций", total_portions],
            ["Уникальных локаций", locations_count],
            ["Дата формирования", datetime.now(TIMEZONE).strftime("%d.%m.%Y %H:%M")]
        ]
        for row in stats_data:
            ws_stats.append(row)

        # Форматирование
        bold_font = Font(bold=True)
        for sheet in wb.worksheets:
            for row in sheet.iter_rows(min_row=1, max_row=1):
                for cell in row:
                    cell.font = bold_font
            for column in sheet.columns:
                max_length = max((len(str(cell.value)) if cell.value else 0 for cell in column), default=0)
                adjusted_width = (max_length + 2) * 1.2
                sheet.column_dimensions[column[0].column_letter].width = adjusted_width

        # Сохраняем файл
        file_path = f"provider_report_{start_date.strftime('%Y%m%d')}"
        if start_date != end_date:
            file_path += f"_to_{end_date.strftime('%Y%m%d')}"
        file_path += ".xlsx"
        wb.save(file_path)

        # Отправляем файл
        caption = (
            f"🍽 Заказы на {start_date.strftime('%d.%m.%Y')}"
            f"{f' — {end_date.strftime('%d.%m.%Y')}' if start_date != end_date else ''}\n"
            f"📍 Локаций: {locations_count} | 🍛 Всего: {total_portions} порций\n"
            "📋 Детализация в приложенном файле"
        )

        with open(file_path, 'rb') as file:
            await context.bot.send_document(
                chat_id=update.effective_chat.id,
                document=file,
                caption=caption
            )

        return file_path

    except Exception as e:
        logger.error(f"Ошибка при создании отчета для поставщика: {e}", exc_info=True)
        await update.message.reply_text("❌ Ошибка при формировании отчёта.")
        raise

async def export_accounting_report(update: Update, context: ContextTypes.DEFAULT_TYPE, 
                                 start_date=None, end_date=None):
    """Генерация отчёта с правильными датами"""
    try:
        now = datetime.now(TIMEZONE)
        
        # Если даты не указаны - отчёт за сегодня
        if not start_date or not end_date:
            start_date = now.date()
            end_date = now.date()

        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "Заказы"
        
        # Заголовки
        headers = [
            "ФИО", "Объект", 
            "Дата заказа", "Время заказа",  # Когда сделан заказ
            "Дата обеда",                   # На какую дату заказ
            "Количество", "Тип заказа", 
            "Статус"
        ]
        ws.append(headers)

        # Получаем данные
        db.cursor.execute('''
            SELECT 
                u.full_name,
                u.location,
                date(o.created_at) as target_date,
                time(o.created_at) as order_time,
                o.target_date,
                o.quantity,
                CASE WHEN o.is_preliminary THEN 'Предзаказ' ELSE 'Обычный' END,
                CASE WHEN o.is_cancelled THEN 'Отменён' ELSE 'Активен' END
            FROM orders o
            JOIN users u ON o.user_id = u.id
            WHERE date(o.created_at) BETWEEN ? AND ?
            ORDER BY o.target_date, u.full_name
        ''', (start_date.isoformat(), end_date.isoformat()))

        for row in db.cursor.fetchall():
            # Форматируем даты для отчёта
            formatted_row = list(row)
            formatted_row[2] = datetime.strptime(row[2], "%Y-%m-%d").strftime("%d.%m.%Y")  # Дата заказа
            formatted_row[4] = datetime.strptime(row[4], "%Y-%m-%d").strftime("%d.%m.%Y")  # Дата обеда
            ws.append(formatted_row)

        # Сохраняем и отправляем файл
        file_path = f"report_{now.strftime('%Y%m%d_%H%M')}.xlsx"
        wb.save(file_path)
        
        with open(file_path, 'rb') as file:
            await update.message.reply_document(
                document=file,
                caption=f"Отчёт за период: {start_date.strftime('%d.%m.%Y')} - {end_date.strftime('%d.%m.%Y')}"
            )
            
    except Exception as e:
        logger.error(f"Ошибка формирования отчёта: {e}")
        await update.message.reply_text("❌ Ошибка при формировании отчёта")
        
# Добавьте эту новую функцию
async def export_orders_for_month(
    update: Update = None, 
    context: ContextTypes.DEFAULT_TYPE = None,
    start_date: date = None,
    end_date: date = None,
    month_offset: int = 0,
    send_to_providers: bool = False
):
    """
    Генерация отчета за месяц/период
    :param update: Объект Update (опционально)
    :param context: Контекст (опционально)
    :param start_date: Начальная дата (если None - будет месяц)
    :param end_date: Конечная дата (если None - будет месяц)
    :param month_offset: Смещение месяца (0 - текущий, -1 - предыдущий)
    :param send_to_providers: Отправлять ли отчет поставщикам
    :return: Путь к файлу или None при ошибке
    """
    try:
        now = datetime.now(TIMEZONE)
        
        # Определяем период
        if start_date is None or end_date is None:
            if month_offset == -1:  # Предыдущий месяц
                first_day = now.replace(day=1)
                start_date = (first_day - timedelta(days=1)).replace(day=1)
                end_date = first_day - timedelta(days=1)
            else:  # Текущий месяц
                start_date = now.replace(day=1)
                end_date = now
        
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "Заказы"
        
        # Заголовки
        headers = ["Объект", "Количество порций"]
        ws.append(headers)
        
        # Получаем данные
        db.cursor.execute('''
            SELECT u.location, SUM(o.quantity) AS portions
            FROM orders o
            JOIN users u ON o.user_id = u.id
            WHERE o.target_date BETWEEN ? AND ?
            GROUP BY u.location
            ORDER BY portions DESC
        ''', (start_date.isoformat(), end_date.isoformat()))
        
        total = 0
        for location, portions in db.cursor.fetchall():
            ws.append([location, portions])
            total += portions
        
        ws.append(["ИТОГО", total])
        
        # Автоподбор ширины столбцов
        for col in ws.columns:
            max_len = max(len(str(cell.value)) for cell in col)
            ws.column_dimensions[col[0].column_letter].width = (max_len + 2) * 1.2
        
        # Сохраняем файл
        if month_offset != 0:
            file_path = f"orders_report_{start_date.strftime('%Y-%m')}.xlsx"
        else:
            file_path = f"orders_report_{start_date.strftime('%Y-%m-%d')}_to_{end_date.strftime('%Y-%m-%d')}.xlsx"
        wb.save(file_path)
        
        # Если вызывается из обработчика - отправляем отчет
        if update and context:
            if send_to_providers:
                success = 0
                with open(file_path, 'rb') as file:
                    for provider_id in CONFIG['provider_ids']:
                        try:
                            await context.bot.send_document(
                                chat_id=provider_id,
                                document=file,
                                caption=(
                                    f"🍽 Заказы за период {start_date.strftime('%d.%m.%Y')} - {end_date.strftime('%d.%m.%Y')}\n"
                                    f"📍 Локации | 🍛 Всего: {total} порций"
                                )
                            )
                            success += 1
                            file.seek(0)
                        except Exception as e:
                            logger.error(f"Ошибка отправки поставщику {provider_id}: {e}")
                
                await update.message.reply_text(
                    f"✅ Отчёт готов\n"
                    f"• Период: {start_date.strftime('%d.%m.%Y')} - {end_date.strftime('%d.%m.%Y')}\n"
                    f"• Порций: {total}\n"
                    f"• Отправлено: {success}/{len(CONFIG['provider_ids'])}"
                )
            else:
                with open(file_path, 'rb') as file:
                    await update.message.reply_document(
                        document=file,
                        caption=f"Отчет за период {start_date.strftime('%d.%m.%Y')} - {end_date.strftime('%d.%m.%Y')}"
                    )
            
            return await show_main_menu(update, update.effective_user.id)
        
        return file_path
        
    except Exception as e:
        logger.error(f"Ошибка формирования отчёта: {e}")
        if update:
            await update.message.reply_text("❌ Ошибка при создании отчёта")
            return await show_main_menu(update, update.effective_user.id)
        raise

async def export_monthly_report(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        if update.effective_user.id not in CONFIG['admin_ids']:
            await update.message.reply_text("❌ У вас нет прав для выполнения этой команды.")
            return

        wb = openpyxl.Workbook()
        
        ws_detailed = wb.active
        ws_detailed.title = "Детализация"
        ws_detailed.append(["ФИО", "Локация", "Дата", "Порции", "Тип"])
        
        ws_summary = wb.create_sheet("Итоги")
        ws_summary.append(["Локация", "Порции"])
        
        month_start = datetime.now(TIMEZONE).replace(day=1).date()
        
        db.cursor.execute('''
            SELECT u.full_name, u.location, o.target_date, o.quantity, 
                   CASE WHEN o.is_preliminary THEN 'Предзаказ' ELSE 'Обычный' END
            FROM orders o
            JOIN users u ON o.user_id = u.id
            WHERE o.target_date BETWEEN ? AND date('now')
            ORDER BY o.target_date, u.location
        ''', (month_start.isoformat(),))
        
        for row in db.cursor.fetchall():
            ws_detailed.append(row)
        
        db.cursor.execute('''
            SELECT u.location, SUM(o.quantity)
            FROM orders o
            JOIN users u ON o.user_id = u.id
            WHERE o.target_date BETWEEN ? AND date('now')
            GROUP BY u.location
        ''', (month_start.isoformat(),))
        
        total = 0
        for location, portions in db.cursor.fetchall():
            ws_summary.append([location, portions])
            total += portions
        
        ws_summary.append(["ВСЕГО", total])
        
        for sheet in wb.worksheets:
            for col in sheet.columns:
                sheet.column_dimensions[col[0].column_letter].width = max(
                    len(str(cell.value)) * 1.2 for cell in col
                )

        file_path = f"monthly_report_{datetime.now(TIMEZONE).strftime('%Y-%m')}.xlsx"
        wb.save(file_path)
        
        with open(file_path, 'rb') as file:
            await context.bot.send_document(
                chat_id=update.effective_chat.id,
                document=file,
                caption=f"📅 Отчёт за {month_start.strftime('%B %Y')}\n"
                       f"🍽 Всего порций: {total}"
            )

    except Exception as e:
        logger.error(f"Ошибка месячного отчёта: {e}")
        await update.message.reply_text("❌ Ошибка формирования отчёта")

async def message_history(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Показ истории сообщений админам"""
    user = update.effective_user
    if user.id not in CONFIG.get('admin_ids', []):
        await update.message.reply_text("❌ У вас нет прав для просмотра истории сообщений.")
        return ADMIN_MESSAGE

    try:
        db.cursor.execute("""
            SELECT m.sent_at, u1.full_name AS admin, u2.full_name AS user, m.message_text
            FROM admin_messages m
            JOIN users u1 ON m.admin_id = u1.telegram_id
            LEFT JOIN users u2 ON m.user_id = u2.telegram_id
            ORDER BY m.sent_at DESC LIMIT 20
        """)
        messages = db.cursor.fetchall()

        if not messages:
            await update.message.reply_text("📜 История сообщений пуста")
            return ADMIN_MESSAGE

        response = "📜 Последние сообщения:\n\n"
        for msg in messages:
            sent_at, admin, user_name, message, *rest = msg
            user_part = f"👤 {user_name}" if user_name else "👥 Всем"
            response += f"🕒 {sent_at}\n🧑‍💼 Админ: {admin}\n{user_part}\n📝 Текст: {message}\n\n"

        await update.message.reply_text(response[:4096])
    except Exception as e:
        logger.error(f"Ошибка при выводе истории: {e}")
        await update.message.reply_text("❌ Не удалось загрузить историю сообщений")
    return ADMIN_MESSAGE

async def handle_export_orders_for_month(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка нажатия кнопки 'Выгрузить заказы за месяц'"""
    if update.effective_user.id not in CONFIG['provider_ids']:
        await update.message.reply_text("❌ У вас нет прав для выполнения этой команды.")
        return MAIN_MENU

    keyboard = [["Текущий месяц"], ["Прошлый месяц"], ["Вернуться в главное меню"]]
    reply_markup = ReplyKeyboardMarkup(keyboard, resize_keyboard=True)
    await update.message.reply_text("Выберите период для выгрузки:", reply_markup=reply_markup)
    return SELECT_MONTH_RANGE



# === bot_core.py ===

from telegram.ext import ApplicationBuilder, PicklePersistence
from handlers import setup_handlers
from config import CONFIG
from cron_jobs import setup_cron_jobs
import logging
import asyncio

logger = logging.getLogger(__name__)

class LunchBot:
    def __init__(self):
        self._running = False
        self.persistence = PicklePersistence(filepath='bot_persistence.pickle')
        self.application = (
            ApplicationBuilder()
            .token(CONFIG['token'])
            .persistence(persistence=self.persistence)
            .read_timeout(30)
            .write_timeout(30)
            .connect_timeout(30)
            .pool_timeout(30)
            .get_updates_read_timeout(30)
            .http_version('1.1')
            .build()
        )
        setup_handlers(self.application)
        self.updater = None

    async def run(self):
        self._running = True
        try:
            await self.application.initialize()
            await self.application.start()
            
            # Запускаем long polling
            self.updater = self.application.updater
            if self.updater:
                await self.updater.start_polling()
            
            await setup_cron_jobs(self.application)
            logger.info("Бот запущен и готов к работе")
            
            # Бесконечный цикл обработки
            while self._running:
                await asyncio.sleep(0.1)
                
        except Exception as e:
            logger.error(f"Ошибка в работе бота: {e}")
            raise
        finally:
            await self.stop()

    async def stop(self):
        if not self._running:
            return
            
        self._running = False
        try:
            if self.updater and self.updater.running:
                await self.updater.stop()
            
            await self.application.stop()
            await self.application.shutdown()
            logger.info("Бот корректно остановлен")
            
        except Exception as e:
            logger.error(f"Ошибка при остановке: {e}")
            raise



# === config.py ===

import os
import openpyxl
import pytz
import logging
import json
from datetime import datetime

logger = logging.getLogger(__name__)

# Общие настройки
TIMEZONE = pytz.timezone('Europe/Moscow')
CONFIG_FILE = "config.xlsx"
LOCATIONS = ["Офис", "ПЦ 1", "ПЦ 2", "Склад"]

def load_config():
    try:
        if not os.path.exists(CONFIG_FILE):
            raise FileNotFoundError(f"Файл конфигурации {CONFIG_FILE} не найден")
        
        wb = openpyxl.load_workbook(CONFIG_FILE)
        ws = wb.active
        
        # Основные настройки (токен, ID)
        token = ws['A2'].value
        if not token:
            raise ValueError("Токен бота не указан в ячейке A2")
        
        admin_ids = [int(cell.value) for cell in ws['B'][1:] if cell.value is not None]
        provider_ids = [int(cell.value) for cell in ws['C'][1:] if cell.value is not None]
        accounting_ids = [int(cell.value) for cell in ws['D'][1:] if cell.value is not None]
        
        # Сотрудники (столбец G)
        staff_names = set()
        for row in ws.iter_rows(min_row=2, max_col=7, values_only=True):
            if row[6]:  # столбец G (индекс 6)
                name = ' '.join(str(row[6]).strip().split()).lower()
                staff_names.add(name)
                
                parts = name.split()
                if len(parts) >= 2:
                    reversed_name = f"{parts[1]} {parts[0]}"
                    if len(parts) > 2:
                        reversed_name += " " + " ".join(parts[2:])
                    staff_names.add(reversed_name)
        
        # Праздники (столбцы K и L)
        holidays = {}
        for row in ws.iter_rows(min_row=2, values_only=True):
            if row[10] and row[11]:  # столбцы K (индекс 10) и L (индекс 11)
                try:
                    date_str = str(row[10]).strip()
                    try:
                        date_obj = datetime.strptime(date_str, "%Y-%m-%d").date()
                    except ValueError:
                        date_obj = datetime.strptime(date_str, "%d.%m.%Y").date()
                    holidays[date_obj.strftime("%Y-%m-%d")] = str(row[11]).strip()
                except Exception as e:
                    logger.warning(f"Не удалось обработать дату праздника: {row[10]}. Ошибка: {e}")
        
        # Меню (столбец I)
        menu = {}
        current_day = None
        dish_counter = 0
        
        # Начинаем с I2 (пропускаем заголовок)
        for row in range(2, ws.max_row + 1):
            cell_value = ws[f'I{row}'].value
            
            # Пропускаем пустые ячейки
            if cell_value is None:
                continue
                
            cell_value = str(cell_value).strip()
            
            # Определяем день недели
            if cell_value in ["Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", "Воскресенье"]:
                current_day = cell_value
                menu[current_day] = {
                    "first": "",
                    "main": "",
                    "salad": ""
                }
                dish_counter = 0
                continue
                
            # Заполняем блюда для текущего дня
            if current_day:
                if dish_counter == 0:
                    menu[current_day]["first"] = cell_value
                elif dish_counter == 1:
                    menu[current_day]["main"] = cell_value
                elif dish_counter == 2:
                    menu[current_day]["salad"] = cell_value
                
                dish_counter += 1

        # Добавляем отсутствующие дни как None
        all_days = ["Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", "Воскресенье"]
        for day in all_days:
            if day not in menu:
                menu[day] = None

        logger.info(f"Загруженное меню:\n{json.dumps(menu, indent=2, ensure_ascii=False)}")
        
        return {
            'token': token,
            'admin_ids': admin_ids,
            'provider_ids': provider_ids,
            'accounting_ids': accounting_ids,
            'staff_names': staff_names,
            'holidays': holidays,
            'menu': menu
        }
    except Exception as e:
        logger.error(f"Критическая ошибка загрузки конфигурации: {e}", exc_info=True)
        raise

def parse_menu_text(menu_text):
    """Парсит текстовое меню в структуру MENU"""
    menu = {}
    current_day = None
    dish_type = 0  # 0=first, 1=main, 2=salad
    
    for line in menu_text.split('\n'):
        line = line.strip()
        if not line:
            continue
            
        if line in ["Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", "Воскресенье"]:
            current_day = line
            menu[current_day] = {"first": "", "main": "", "salad": ""}
            dish_type = 0
        elif current_day:
            if dish_type == 0:
                menu[current_day]["first"] = line
                dish_type += 1
            elif dish_type == 1:
                menu[current_day]["main"] = line
                dish_type += 1
            elif dish_type == 2:
                menu[current_day]["salad"] = line
                dish_type = 0
    
    # Добавляем отсутствующие дни как None
    all_days = ["Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", "Воскресенье"]
    for day in all_days:
        if day not in menu:
            menu[day] = None
            
    return menu

# Загружаем конфигурацию при старте
try:
    CONFIG = load_config()
    TOKEN = CONFIG['token']
    ADMIN_IDS = CONFIG['admin_ids']
    PROVIDER_IDS = CONFIG['provider_ids']
    ACCOUNTING_IDS = CONFIG['accounting_ids']
    STAFF_NAMES = CONFIG['staff_names']
    HOLIDAYS = CONFIG.get('holidays', {})
    MENU = CONFIG['menu']
except Exception as e:
    logger.error(f"Не удалось загрузить конфигурацию: {e}")
    exit(1)



# === cron_jobs.py ===

import aiocron
from config import TIMEZONE, CONFIG
from datetime import datetime, timedelta
import logging
from db import db
from admin import export_accounting_report
from telegram.ext import ContextTypes
import openpyxl

logger = logging.getLogger(__name__)

async def send_reminder_to_users(application):
    try:
        now = datetime.now(TIMEZONE)
        
        if now.weekday() < 5:  # Пн-Пт
            logger.info(f"Запуск напоминаний в {now}")
            
            db.cursor.execute("""
                SELECT telegram_id 
                FROM users 
                WHERE is_verified = TRUE 
                AND telegram_id NOT IN (
                    SELECT u.telegram_id 
                    FROM users u 
                    JOIN orders o ON u.id = o.user_id 
                    WHERE o.order_date = ? AND o.is_preliminary = FALSE
                )
            """, (now.date().isoformat(),))
            
            users = db.cursor.fetchall()
            logger.info(f"Найдено {len(users)} пользователей без заказов")
            
            for user in users:
                user_id = user[0]
                try:
                    await application.bot.send_message(
                        chat_id=user_id,
                        text="⏰ *Не забудьте заказать обед!* 🍽\n\n"
                             "Прием заказов открыт до 9:30.\n\n"
                             "Заказы принимаются через *БИТРИКС*, бот в тестовом режиме!",
                        parse_mode="Markdown"
                    )
                except Exception as e:
                    logger.error(f"Ошибка при отправке напоминания пользователю {user_id}: {e}")
                    
    except Exception as e:
        logger.error(f"Ошибка в send_reminder_to_users: {e}")

async def send_provider_report(application):
    """Отправка ежедневного отчёта поставщикам (в 9:30 по будням)"""
    try:
        logger.info("Запуск отправки отчета поставщикам")

        now = datetime.now(TIMEZONE)
        today = now.date().isoformat()

        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "Заказы на сегодня"
        ws.append(["Объект", "Количество порций"])

        # SQL-запрос: уникальные локации с заказами за сегодня
        db.cursor.execute('''
            SELECT u.location, SUM(o.quantity)
            FROM orders o
            JOIN users u ON o.user_id = u.id
            WHERE o.order_date = ?
              AND o.is_cancelled = FALSE
            GROUP BY u.location
            ORDER BY u.location
        ''', (today,))

        locations_with_orders = []
        total = 0

        for row in db.cursor.fetchall():
            ws.append([row[0], row[1]])
            locations_with_orders.append(row[0])
            total += row[1]

        unique_locations_count = len(locations_with_orders)

        # Автоподбор ширины столбцов
        for col in ws.columns:
            max_length = max((len(str(cell.value)) if cell.value else 0 for cell in col), default=0)
            ws.column_dimensions[col[0].column_letter].width = (max_length + 2) * 1.2

        # Сохраняем файл
        file_path = f"provider_report_{today.replace('-', '')}.xlsx"
        wb.save(file_path)

        # Рассылаем всем поставщикам
        success = 0
        with open(file_path, 'rb') as file:
            for provider_id in CONFIG.get('provider_ids', []):
                try:
                    await application.bot.send_document(
                        chat_id=provider_id,
                        document=file,
                        caption=(
                            f"🍽 Заказы на {now.strftime('%d.%m.%Y')}\n"
                            f"📍 Локаций: {unique_locations_count} | 🍛 Всего: {total} порций\n"
                            "📋 Детализация в приложенном файле"
                        )
                    )
                    success += 1
                    file.seek(0)  # Сброс позиции файла для следующего получателя
                except Exception as e:
                    logger.error(f"Ошибка отправки поставщику {provider_id}: {e}")

        logger.info(f"Отправлено {success}/{len(CONFIG.get('provider_ids', []))} поставщикам")

    except Exception as e:
        logger.error(f"Ошибка отправки отчета поставщикам: {e}")

async def send_accounting_report(application):
    """Отправка ежемесячного отчёта бухгалтерии (в 11:00 последнего дня месяца)"""
    try:
        logger.info("Запуск отправки отчета бухгалтерии")

        now = datetime.now(TIMEZONE)
        today = now.date()

        # Определяем начало и конец месяца
        if today.day == 1:
            # Сегодня первое число — отправляем за предыдущий месяц
            first_day_current_month = now.replace(day=1)
            last_day_prev_month = first_day_current_month - timedelta(days=1)
            start_date = last_day_prev_month.replace(day=1).date()
            end_date = last_day_prev_month.date()
        else:
            # Иначе отправляем за текущий месяц до сегодняшнего числа
            start_date = now.replace(day=1).date()
            end_date = today

        wb = openpyxl.Workbook()

        # 1. Лист "Детализация"
        ws_detailed = wb.active
        ws_detailed.title = "Детализация"
        detailed_headers = ["ФИО", "Объект", "Дата", "Количество", "Тип заказа"]
        ws_detailed.append(detailed_headers)
        ws_detailed.auto_filter.ref = "A1:E1"

        total_portions = 0

        db.cursor.execute('''
            SELECT 
                u.full_name,
                u.location,
                o.order_date,
                o.quantity,
                CASE WHEN o.is_preliminary THEN 'Предзаказ' ELSE 'Обычный' END
            FROM orders o
            JOIN users u ON o.user_id = u.id
            WHERE o.order_date BETWEEN ? AND ?
              AND o.is_cancelled = FALSE
            ORDER BY o.order_date, u.full_name
        ''', (start_date.isoformat(), end_date.isoformat()))

        for row in db.cursor.fetchall():
            formatted_date = datetime.strptime(row[2], "%Y-%m-%d").strftime("%d.%m.%Y")
            ws_detailed.append([
                row[0],  # ФИО
                row[1],  # Объект
                formatted_date,  # Дата
                row[3],  # Количество
                row[4]   # Тип
            ])
            total_portions += row[3]

        # 2. Лист "Сводка по сотрудникам"
        ws_summary_users = wb.create_sheet("Сводка по сотрудникам")
        summary_users_headers = ["ФИО", "Объект", "Всего порций"]
        ws_summary_users.append(summary_users_headers)
        ws_summary_users.auto_filter.ref = "A1:C1"

        db.cursor.execute('''
            SELECT 
                u.full_name,
                u.location,
                SUM(o.quantity)
            FROM orders o
            JOIN users u ON o.user_id = u.id
            WHERE o.order_date BETWEEN ? AND ?
              AND o.is_cancelled = FALSE
            GROUP BY u.full_name, u.location
            ORDER BY SUM(o.quantity) DESC
        ''', (start_date.isoformat(), end_date.isoformat()))

        for row in db.cursor.fetchall():
            ws_summary_users.append(row)

        # 3. Лист "Сводка по объектам"
        ws_summary_locations = wb.create_sheet("Сводка по объектам")
        ws_summary_locations.append(["Объект", "Порции"])
        ws_summary_locations.auto_filter.ref = "A1:B1"

        db.cursor.execute('''
            SELECT u.location, SUM(o.quantity)
            FROM orders o
            JOIN users u ON o.user_id = u.id
            WHERE o.order_date BETWEEN ? AND ?
              AND o.is_cancelled = FALSE
            GROUP BY u.location
            ORDER BY SUM(o.quantity) DESC
        ''', (start_date.isoformat(), end_date.isoformat()))

        for location, portions in db.cursor.fetchall():
            ws_summary_locations.append([location, portions])

        ws_summary_locations.append(["ВСЕГО", total_portions])

        # 4. Лист "Итоги"
        ws_stats = wb.create_sheet("Итоги")
        stats_headers = ["Показатель", "Значение"]
        ws_stats.append(stats_headers)

        stats_data = [
            ["Период", f"{start_date.strftime('%d.%m.%Y')} — {end_date.strftime('%d.%m.%Y')}"],
            ["Всего порций", total_portions],
            ["Уникальных сотрудников", ws_summary_users.max_row - 1],
            ["Дата формирования", datetime.now(TIMEZONE).strftime("%d.%m.%Y %H:%M")]
        ]
        for row in stats_data:
            ws_stats.append(row)

        # Форматирование
        from openpyxl.styles import Font
        bold_font = Font(bold=True)

        for sheet in wb.worksheets:
            # Жирные заголовки
            for row in sheet.iter_rows(min_row=1, max_row=1):
                for cell in row:
                    cell.font = bold_font

            # Автоподбор ширины
            for column in sheet.columns:
                max_length = max((len(str(cell.value)) if cell.value else 0 for cell in column), default=0)
                adjusted_width = (max_length + 2) * 1.2
                sheet.column_dimensions[column[0].column_letter].width = adjusted_width

        # Сохраняем файл
        file_path = f"accounting_report_{start_date.strftime('%Y%m%d')}"
        if start_date != end_date:
            file_path += f"_to_{end_date.strftime('%Y%m%d')}"
        file_path += ".xlsx"
        wb.save(file_path)

        # Отправляем каждому бухгалтеру
        success = 0
        with open(file_path, 'rb') as file:
            for accounting_id in CONFIG.get('accounting_ids', []):
                try:
                    await application.bot.send_document(
                        chat_id=accounting_id,
                        document=file,
                        caption=(
                            f"📊 Бухгалтерский отчет\n"
                            f"📅 Период: {start_date.strftime('%d.%m.%Y')} — {end_date.strftime('%d.%m.%Y')}\n"
                            f"🍽 Всего порций: {total_portions}"
                        )
                    )
                    success += 1
                    file.seek(0)  # Сбрасываем позицию файла для следующего получателя
                except Exception as e:
                    logger.error(f"Ошибка отправки бухгалтеру {accounting_id}: {e}")

        logger.info(f"Отправлено {success}/{len(CONFIG.get('accounting_ids', []))} бухгалтерам")

    except Exception as e:
        logger.error(f"Ошибка при отправке отчета бухгалтерии: {e}", exc_info=True)

async def setup_cron_jobs(application):
    # Напоминание пользователям в 9:00 по будням
    # @aiocron.crontab('* * * * *', tz=TIMEZONE)
    @aiocron.crontab('0 9 * * 1-5', tz=TIMEZONE)
    async def morning_reminder():
        await send_reminder_to_users(application)

    # Отчет поставщикам в 9:30 по рабочим дням
    # @aiocron.crontab('* * * * *', tz=TIMEZONE)
    @aiocron.crontab('30 9 * * 1-5', tz=TIMEZONE)
    async def provider_report():
        await send_provider_report(application)
    
    # Отчет бухгалтерии в 11:00 последнего дня месяца
    # @aiocron.crontab('* * * * *', tz=TIMEZONE)
    @aiocron.crontab('0 11 L * *', tz=TIMEZONE)
    async def accounting_report():
        await send_accounting_report(application)



# === db.py ===

import sqlite3
import logging
from config import CONFIG, TIMEZONE
from datetime import datetime

logger = logging.getLogger(__name__)


class Database:
    def __init__(self):
        self.conn = sqlite3.connect('lunch_bot.db', check_same_thread=False, isolation_level=None)
        self.cursor = self.conn.cursor()
        self._init_db()

    def execute(self, query, params=()):
        """Безопасное выполнение запроса с обработкой транзакций"""
        try:
            self.cursor.execute("BEGIN")
            if not isinstance(params, (tuple, list, dict)):
                raise ValueError("Параметры должны быть кортежем, списком или словарём")
                
            self.cursor.execute(query, params)
            result = self.cursor.fetchall()
            self.conn.commit()
            return result
        except sqlite3.Error as e:
            self.conn.rollback()
            logger.error(f"Ошибка выполнения SQL: {e} | Query: {query} | Params: {params}")
            raise

    def _init_db(self):
        """Создание таблиц и индексов при первом запуске"""
        try:
            # Настройки SQLite
            self.conn.execute("PRAGMA journal_mode=WAL")
            self.conn.execute("PRAGMA synchronous=NORMAL")
            self.conn.execute("PRAGMA busy_timeout=5000")

            # Таблица пользователей
            self.cursor.execute('''
                CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    telegram_id INTEGER UNIQUE NOT NULL,
                    full_name TEXT NOT NULL,
                    phone TEXT NOT NULL,
                    location TEXT NOT NULL,
                    is_verified BOOLEAN DEFAULT FALSE,
                    username TEXT,
                    is_deleted BOOLEAN DEFAULT FALSE,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    updated_at TEXT DEFAULT CURRENT_TIMESTAMP
                )
            ''')

            # Таблица заказов (обновлённая структура)
            self.cursor.execute('''
                CREATE TABLE IF NOT EXISTS orders (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL,
                    target_date TEXT NOT NULL,
                    order_time TEXT NOT NULL,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    quantity INTEGER NOT NULL CHECK(quantity BETWEEN 1 AND 3),
                    is_preliminary BOOLEAN DEFAULT FALSE,
                    is_cancelled BOOLEAN DEFAULT FALSE,
                    FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
                    /* Убрали CHECK с date() */
                )
            ''')

            # Таблица сообщений
            self.cursor.execute('''
                CREATE TABLE IF NOT EXISTS admin_messages (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    sent_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    admin_id INTEGER,
                    user_id INTEGER,
                    message_text TEXT NOT NULL,
                    is_broadcast BOOLEAN DEFAULT FALSE,
                    FOREIGN KEY(admin_id) REFERENCES users(telegram_id),
                    FOREIGN KEY(user_id) REFERENCES users(telegram_id)
                )
            ''')
            
            # Таблица отзывов поставщикам (добавлены NOT NULL constraints)
            self.cursor.execute('''
                CREATE TABLE IF NOT EXISTS feedback_messages (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL,
                    provider_id INTEGER NOT NULL,
                    message_text TEXT NOT NULL,
                    sent_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    is_processed BOOLEAN DEFAULT FALSE,
                    FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
                    FOREIGN KEY(provider_id) REFERENCES users(id) ON DELETE CASCADE
                )
            ''')

            # Создаем индексы (обновлённые)
            with self.conn:
                # Индексы для таблицы users
                self.cursor.execute("CREATE INDEX IF NOT EXISTS idx_users_telegram_id ON users(telegram_id)")
                self.cursor.execute("CREATE INDEX IF NOT EXISTS idx_users_verified ON users(is_verified)")
                
                # Индексы для таблицы orders
                self.cursor.execute("CREATE INDEX IF NOT EXISTS idx_orders_user_id ON orders(user_id)")
                self.cursor.execute("CREATE INDEX IF NOT EXISTS idx_orders_target_date ON orders(target_date)")
                self.cursor.execute("CREATE INDEX IF NOT EXISTS idx_orders_created_at ON orders(created_at)")
                self.cursor.execute("CREATE INDEX IF NOT EXISTS idx_orders_cancelled ON orders(is_cancelled)")
                
                # Индексы для таблицы feedback_messages
                self.cursor.execute("CREATE INDEX IF NOT EXISTS idx_feedback_user_id ON feedback_messages(user_id)")
                self.cursor.execute("CREATE INDEX IF NOT EXISTS idx_feedback_provider_id ON feedback_messages(provider_id)")
                self.cursor.execute("CREATE INDEX IF NOT EXISTS idx_feedback_processed ON feedback_messages(is_processed)")

            logger.info("✅ Все таблицы и индексы созданы корректно")

        except sqlite3.OperationalError as e:
            logger.error(f"❌ Ошибка создания таблиц: {e}")
            raise
        except Exception as e:
            logger.critical(f"⚠️ Критическая ошибка при инициализации БД: {e}")
            raise
            
# Глобальный экземпляр базы данных
db = Database()



# === full_code.py ===




# === keyboards.py ===

from telegram import ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardButton, InlineKeyboardMarkup
from config import CONFIG, LOCATIONS

def create_unverified_user_keyboard():
    return ReplyKeyboardMarkup([
        ["Попробовать снова"],
        ["Написать администратору"]
    ], resize_keyboard=True)

def create_main_menu_keyboard(user_id=None):
    menu = [
        ["Меню на сегодня", "Меню на неделю"],
        ["Просмотреть заказы", "Статистика за месяц"],
        ["Написать администратору"]
    ]
    
    if user_id in CONFIG.get('admin_ids', []):
        menu.insert(0, ["📊 Отчет за день", "📅 Отчет за месяц"])
        menu.insert(0, ["✉️ Написать пользователю", "📢 Сделать рассылку"])
    
    if user_id in CONFIG.get('provider_ids', []):
        menu.append(["📦 Отчет поставщика"])
    
    if user_id in CONFIG.get('accounting_ids', []):
        menu.append(["💰 Бухгалтерский отчет"])

    menu.append(["Обновить меню"])

    return ReplyKeyboardMarkup(menu, resize_keyboard=True)

def create_month_selection_keyboard():
    return ReplyKeyboardMarkup([
        ["Текущий месяц"],
        ["Прошлый месяц"],
        ["Вернуться в главное меню"]
    ], resize_keyboard=True)

def create_order_keyboard(has_order):
    if has_order:
        return [
            [InlineKeyboardButton("✏️ Изменить количество", callback_data="change")],
            [InlineKeyboardButton("❌ Отменить заказ", callback_data="cancel")]
        ]
    return [[InlineKeyboardButton("✅ Заказать", callback_data="order")]]

def create_admin_keyboard():
    return ReplyKeyboardMarkup([
        ["📊 Отчет за день", "📅 Отчет за месяц"],
        ["✉️ Написать пользователю", "📢 Сделать рассылку"],
        ["📜 История сообщений"],
        ["🏠 Главное меню"]
    ], resize_keyboard=True)



# === main.py ===

import asyncio
import signal
import platform
from bot_core import LunchBot
import logging
import os
from bot_core import LunchBot
from handlers import setup_handlers  # Импорт из handlers/__init__.py
from telegram.ext import MessageHandler
from config import CONFIG

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    filename='bot.log'
)
import logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    filename='bot.log',
    filemode='a'  # Режим добавления в файл
)
logger = logging.getLogger(__name__)

async def shutdown(bot):
    print("\n🛑 Завершение работы бота...")
    await bot.stop()

async def main():
    # Добавьте для теста
    print("Проверка конфига:")
    print("Admin IDs:", CONFIG['admin_ids'])
    print("Token:", CONFIG['token'][:5] + "...")
    
    bot = LunchBot()
    setup_handlers(bot.application)  # Настройка обработчиков
    await bot.run()
    
    # Настройка обработки Ctrl+C для всех ОС
    if platform.system() == 'Windows':
        # Для Windows используем простой обработчик KeyboardInterrupt
        try:
            task = asyncio.create_task(bot.run())
            await task
        except asyncio.CancelledError:
            await shutdown(bot)
    else:
        # Для Linux/Unix настраиваем обработчики сигналов
        loop = asyncio.get_running_loop()
        for sig in (signal.SIGTERM, signal.SIGINT):
            loop.add_signal_handler(
                sig,
                lambda s=sig: asyncio.create_task(shutdown(bot))
            )
        try:
            await bot.run()
        except asyncio.CancelledError:
            pass  # Обработка уже выполнена в shutdown

    print("✅ Работа бота завершена")

if __name__ == "__main__":
    try:
        if platform.system() == 'Windows':
            # Специальная обработка для Windows
            async def windows_main():
                try:
                    await main()
                except KeyboardInterrupt:
                    print("\n🛑 Принудительное завершение")
            
            asyncio.run(windows_main())
        else:
            asyncio.run(main())
    except KeyboardInterrupt:
        print("\n🛑 Принудительное завершение")
    except Exception as e:
        print(f"❌ Критическая ошибка: {str(e)}")



# === migrate_db.py ===

from db import db

def add_cancelled_column():
    try:
        # Проверяем существование колонки
        db.cursor.execute("PRAGMA table_info(orders)")
        columns = [col[1] for col in db.cursor.fetchall()]
        
        if 'is_cancelled' not in columns:
            db.cursor.execute("ALTER TABLE orders ADD COLUMN is_cancelled BOOLEAN DEFAULT FALSE")
            db.conn.commit()
            print("✅ Колонка is_cancelled успешно добавлена")
        else:
            print("ℹ️ Колонка is_cancelled уже существует")
    except Exception as e:
        print(f"❌ Ошибка миграции: {e}")

if __name__ == "__main__":
    print("Запуск миграции БД...")
    add_cancelled_column()
    print("Миграция завершена")


# === utils.py ===

from telegram import Update, KeyboardButton, ReplyKeyboardMarkup
from telegram.ext import ContextTypes
from config import CONFIG, TIMEZONE, MENU
from db import db
import logging
from datetime import datetime, timedelta, date, time
import pytz

logger = logging.getLogger(__name__)

# Состояния диалога (для handle_unregistered)
PHONE = 0

def is_weekday(date=None):
    if date is None:
        date = datetime.now(TIMEZONE)
    return date.weekday() < 5  # 0-4 = пн-пт

def get_next_workday(date=None):
    if date is None:
        date = datetime.now(TIMEZONE)
    
    days_to_add = 1
    if date.weekday() == 4:  # Пятница
        days_to_add = 3  # Понедельник
    elif date.weekday() == 5:  # Суббота
        days_to_add = 2  # Понедельник
    
    return date + timedelta(days=days_to_add)

def can_modify_order(target_date):
    """Проверяет, можно ли изменять заказ на указанную дату"""
    now = datetime.now(TIMEZONE)
    
    # Если target_date - строка, преобразуем в дату
    if isinstance(target_date, str):
        try:
            target_date = datetime.strptime(target_date, "%Y-%m-%d").date()
        except ValueError:
            logger.error(f"Неверный формат даты: {target_date}")
            return False
    
    # Заказы на выходные невозможны
    if target_date.weekday() >= 5:  # 5-6 = суббота-воскресенье
        return False
    
    # Заказы на будущие дни (предзаказы) можно менять в любое время
    if target_date > now.date():
        return True
    
    # Заказы на сегодня можно менять только до 9:30
    if target_date == now.date():
        return now.time() < time(9, 30)
    
    # Заказы на прошедшие дни нельзя менять
    return False

def is_order_time_expired():
    """Старая функция, оставляем для совместимости, но теперь она использует новую функцию"""
    return not can_modify_order(datetime.now(TIMEZONE).date())

def get_order_time_restriction():
    now = datetime.now(TIMEZONE)
    current_hour = now.hour
    
    if not is_weekday(now):
        next_workday = get_next_workday(now)
        return f"⏳ Сегодня выходной. Вы можете оформить предварительный заказ на {next_workday.strftime('%d.%m')} (понедельник)"
    
    if current_hour >= 10:
        next_workday = get_next_workday(now)
        return f"⏳ Прием заказов на сегодня завершен в 10:00. Вы можете оформить предварительный заказ на {next_workday.strftime('%d.%m')}"
    
    return None

def is_employee(full_name):
    normalized_input = ' '.join(full_name.strip().split()).lower()
    return normalized_input in CONFIG['staff_names']

def get_menu_for_day(day_offset=0):
    now = datetime.now(TIMEZONE)
    days = ["Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", "Воскресенье"]
    target_date = (now + timedelta(days=day_offset)).date()
    day_name = days[target_date.weekday()]
    
    # Проверяем, является ли день праздником
    if target_date.strftime("%Y-%m-%d") in CONFIG.get('holidays', {}):
        return None, day_name
    
    return MENU.get(day_name), day_name

def format_menu(menu, day_name, is_tomorrow=False):
    if not menu:
        return f"На {day_name} выходной! Меню не предусмотрено."
    
    # Получаем текущую дату и вычисляем дату для отображения
    now = datetime.now(TIMEZONE)
    days_ru = ["Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", "Воскресенье"]
    
    # Находим индекс текущего дня и вычисляем дату
    current_day_index = now.weekday()
    target_day_index = days_ru.index(day_name)
    
    # Если день в будущем (например, среда при текущем понедельнике)
    if target_day_index > current_day_index:
        days_diff = target_day_index - current_day_index
    # Если день в прошлом (например, понедельник при текущей среде)
    else:
        days_diff = 7 - (current_day_index - target_day_index)
    
    target_date = (now + timedelta(days=days_diff)).date()
    date_str = target_date.strftime("%d.%m")
    
    return (
        f"🍽 Меню на {day_name} ({date_str}):\n"
        f"1. 🍲 Первое: {menu['first']}\n"
        f"2. 🍛 Основное блюдо: {menu['main']}\n"
        f"3. 🥗 Салат: {menu['salad']}"
    )

async def check_registration(update: Update, context: ContextTypes.DEFAULT_TYPE) -> bool:
    user = update.effective_user
    db.cursor.execute("SELECT is_verified FROM users WHERE telegram_id = ?", (user.id,))
    result = db.cursor.fetchone()
    
    if result:
        logger.info(f"Пользователь {user.id} статус верификации: {result[0]}")
        return bool(result[0])
    
    logger.info(f"Пользователь {user.id} не найден в базе")
    return False

async def handle_unregistered(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    logger.info(f"Незарегистрированный пользователь {user.id} пытается взаимодействовать с ботом")
    
    for admin_id in CONFIG['admin_ids']:
        try:
            await context.bot.send_message(
                chat_id=admin_id,
                text=f"⚠️ Незарегистрированный пользователь пытается использовать бота:\n"
                     f"🆔 ID: {user.id}\n"
                     f"👤 Username: @{user.username if user.username else 'нет'}"
            )
        except Exception as e:
            logger.error(f"Ошибка отправки админу {admin_id}: {e}")
    
    keyboard = [[KeyboardButton("📱 Отправить номер телефона", request_contact=True)]]
    reply_markup = ReplyKeyboardMarkup(keyboard, resize_keyboard=True)
    
    await update.message.reply_text(
        "Вы не завершили регистрацию. Пожалуйста, нажмите кнопку ниже, чтобы отправить номер телефона:",
        reply_markup=reply_markup
    )
    return PHONE

def is_order_cancelled(user_id: int, target_date_str: str, context=None) -> bool:
    """Проверяет, отменён ли заказ (из БД или временного хранилища)"""
    try:
        # Проверка из базы данных
        db.cursor.execute("""
            SELECT is_cancelled FROM orders 
            WHERE user_id = (SELECT id FROM users WHERE telegram_id = ?)
            AND target_date = ?
        """, (user_id, target_date_str))
        
        result = db.cursor.fetchone()
        if result and result[0]:
            return True
            
        # Резервная проверка из контекста
        if context and context.user_data.get('cancelled_orders'):
            return target_date_str in context.user_data['cancelled_orders']
            
        return False
        
    except Exception as e:
        logger.error(f"Ошибка проверки статуса отмены: {e}")
        return False

